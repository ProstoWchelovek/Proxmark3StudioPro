# tests/__init__.py
"""
Тесты для Proxmark3 Studio Pro
"""

# Экспортируем основные классы для удобного импорта
from .test_pm3_client import TestPM3Client, TestCommandExecutor, TestOutputParser
from .test_attacks import TestNestedAttack, TestHardnestedAttack, TestLFAttacks
from .test_decoders import TestEM4100Decoder, TestHIDDecoder, TestMifareDecoder, TestISO14443Decoder

__all__ = [
    'TestPM3Client',
    'TestCommandExecutor', 
    'TestOutputParser',
    'TestNestedAttack',
    'TestHardnestedAttack',
    'TestLFAttacks',
    'TestEM4100Decoder',
    'TestHIDDecoder',
    'TestMifareDecoder',
    'TestISO14443Decoder'
]