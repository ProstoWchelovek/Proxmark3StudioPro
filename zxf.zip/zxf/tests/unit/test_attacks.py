# tests/test_attacks.py
"""
Тесты для системы атак
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from attacks_lib.mf_nested import NestedAttack, NestedAttackThread, KeyType
from attacks_lib.mf_hardnested import HardnestedAttack, HardnestedAttackThread, HardnestedConfig
from attacks_lib.lf_attacks import LFAttacks, LFBruteforceConfig, LFBruteforceThread


class TestNestedAttack(unittest.TestCase):
    """Тесты для Nested атаки"""
    
    def setUp(self):
        self.mock_pm3 = Mock()
        self.attack = NestedAttack(self.mock_pm3)
    
    def test_parse_nested_output_valid(self):
        """Тест парсинга валидного вывода Nested атаки"""
        output = """
| Sector 00 | Key A: FFFFFFFFFFFF | Key B: 000000000000 |
| Sector 01 | Key A: A0A1A2A3A4A5 | Key B: ???????????? |
| Sector 02 | Key A: B0B1B2B3B4B5 | Key B: C0C1C2C3C4C5 |
"""
        result = self.attack.parse_nested_output(output)
        
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['key_a'], "FFFFFFFFFFF")
        self.assertEqual(result[1]['key_a'], "A0A1A2A3A4A5")
        self.assertEqual(result[2]['key_b'], "C0C1C2C3C4C5")
    
    def test_parse_nested_output_alternative(self):
        """Тест парсинга альтернативного формата вывода"""
        output = """
Found key for sector 01: AAAAAAAAAAAA
Found key for sector 05: BBBBBBBBBBBB
"""
        result = self.attack.parse_nested_output(output)
        
        self.assertIn(1, result)
        self.assertEqual(result[1]['key_a'], "AAAAAAAAAAAA")
    
    def test_parse_nested_output_empty(self):
        """Тест парсинга пустого вывода"""
        result = self.attack.parse_nested_output("No keys found")
        
        self.assertEqual(len(result), 0)
    
    def test_run_command_format(self):
        """Тест форматирования команды"""
        self.attack.run(known_key="FFFFFFFFFFFF", known_sector=0, 
                       known_key_type=KeyType.KEY_A, target_sectors=[1, 2, 3])
        
        self.mock_pm3.run_command.assert_called_once()
        cmd = self.mock_pm3.run_command.call_args[0][0]
        
        self.assertIn("hf mf nested", cmd)
        self.assertIn("FFFFFFFFFFFF", cmd)
        self.assertIn("0", cmd)
        self.assertIn("A", cmd)
    
    def test_recover_all_keys(self):
        """Тест рекурсивного восстановления ключей"""
        # Мокаем последовательные вызовы
        self.attack.run = Mock()
        
        # Первый вызов возвращает ключи для секторов 1-3
        self.attack.run.side_effect = [
            {1: {'key_a': '111111111111', 'key_b': '????????????'}},
            {2: {'key_a': '222222222222', 'key_b': '????????????'}},
            {},
        ]
        
        result = self.attack.recover_all_keys("FFFFFFFFFFFF", 0, KeyType.KEY_A)
        
        self.assertGreaterEqual(len(result), 2)


class TestHardnestedAttack(unittest.TestCase):
    """Тесты для Hardnested атаки"""
    
    def setUp(self):
        self.mock_pm3 = Mock()
        self.attack = HardnestedAttack(self.mock_pm3)
    
    def test_config_defaults(self):
        """Тест настроек по умолчанию"""
        config = HardnestedConfig()
        
        self.assertEqual(config.known_key, "FFFFFFFFFFFF")
        self.assertEqual(config.threads, 4)
        self.assertEqual(config.timeout, 300)
    
    def test_build_command(self):
        """Тест построения команды"""
        config = HardnestedConfig(
            known_key="A0A1A2A3A4A5",
            known_sector=5,
            known_key_type="B",
            target_sector=10,
            threads=8,
            timeout=600
        )
        
        self.attack.run(config)
        
        cmd = self.mock_pm3.run_command.call_args[0][0]
        
        self.assertIn("A0A1A2A3A4A5", cmd)
        self.assertIn("--sector 5", cmd)
        self.assertIn("--keytype B", cmd)
        self.assertIn("--targsec 10", cmd)
        self.assertIn("--threads 8", cmd)
    
    def test_parse_hardnested_output(self):
        """Тест парсинга вывода Hardnested атаки"""
        output = """
Starting hardnested attack...
Key found: sector 00, key A: FFFFFFFFFFFF
Key found: sector 01, key B: 111111111111
Found key: 222222222222
"""
        result = self.attack.parse_output(output)
        
        self.assertIn(0, result)
        self.assertEqual(result[0]['key_a'], "FFFFFFFFFFF")
    
    def test_run_with_progress(self):
        """Тест выполнения с прогрессом"""
        progress_callback = Mock()
        
        config = HardnestedConfig()
        
        # Мокаем run
        self.attack.run = Mock(return_value={0: {'key_a': 'FFFFFFFFFFFF', 'key_b': '????????????'}})
        
        result = self.attack.run_with_progress(config, progress_callback)
        
        # Проверяем, что прогресс вызывался
        progress_callback.assert_called()
        self.assertGreaterEqual(progress_callback.call_count, 2)


class TestLFAttacks(unittest.TestCase):
    """Тесты для LF атак"""
    
    def setUp(self):
        self.mock_pm3 = Mock()
        self.attack = LFAttacks(self.mock_pm3)
    
    def test_em4100_bruteforce(self):
        """Тест брутфорса EM4100"""
        config = LFBruteforceConfig(
            tag_type="em4100",
            start_id=0,
            end_id=100
        )
        
        # Мокаем run_command
        self.mock_pm3.run_command.return_value = "EM410x UID: 0000000001"
        
        results = self.attack.bruteforce_em4100(config)
        
        # Проверяем, что команды вызывались
        self.assertTrue(self.mock_pm3.run_command.called)
    
    def test_hid_bruteforce(self):
        """Тест брутфорса HID"""
        config = LFBruteforceConfig(
            tag_type="hid",
            start_id=0,
            end_id=100,
            facility_code=123
        )
        
        # Мокаем run_command
        self.mock_pm3.run_command.return_value = "HID card found"
        
        results = self.attack.bruteforce_hid(config)
        
        # Проверяем, что команды вызывались
        self.assertTrue(self.mock_pm3.run_command.called)
    
    def test_sniff_reader(self):
        """Тест перехвата сигнала"""
        self.mock_pm3.run_command.return_value = """
LF Snoop completed
Found EM410x tag: ID: 1A2B3C4D5E
Found HID tag: FC: 123, CN: 4567
"""
        result = self.attack.sniff_reader(timeout=10)
        
        self.assertIn('detected_tags', result)
        self.assertGreaterEqual(len(result['detected_tags']), 2)
    
    def test_clone_em4100(self):
        """Тест клонирования EM4100"""
        result = self.attack.clone_tag("em4100", "1A2B3C4D5E")
        
        self.mock_pm3.run_command.assert_called_once()
        cmd = self.mock_pm3.run_command.call_args[0][0]
        
        self.assertIn("lf em 410x clone", cmd)
        self.assertIn("1A2B3C4D5E", cmd)
    
    def test_clone_hid(self):
        """Тест клонирования HID"""
        result = self.attack.clone_tag("hid", "123:4567")
        
        cmd = self.mock_pm3.run_command.call_args[0][0]
        
        self.assertIn("lf hid clone", cmd)
        self.assertIn("--fc 123", cmd)
        self.assertIn("--cn 4567", cmd)
    
    def test_clone_with_config(self):
        """Тест клонирования с конфигурацией"""
        config = {'config': '0x00088040', 'password': '12345678'}
        
        result = self.attack.clone_tag("em4100", "1A2B3C4D5E", config)
        
        cmd = self.mock_pm3.run_command.call_args[0][0]
        
        self.assertIn("--config 0x00088040", cmd)
        self.assertIn("--password 12345678", cmd)
    
    def test_analyze_signal(self):
        """Тест анализа сигнала"""
        sample_data = """
Frequency: 125.00 kHz
Modulation: ASK
Encoding: Manchester
Found EM410x pattern
"""
        result = self.attack.analyze_signal(sample_data)
        
        self.assertEqual(result['frequency'], 125.0)
        self.assertEqual(result['modulation'], "ASK")
        self.assertEqual(result['encoding'], "Manchester")
        self.assertEqual(result['data'], "EM4100")


class TestAttackThreads(unittest.TestCase):
    """Тесты потоков атак"""
    
    def setUp(self):
        self.mock_pm3 = Mock()
    
    def test_nested_attack_thread(self):
        """Тест потока Nested атаки"""
        thread = NestedAttackThread(
            self.mock_pm3,
            known_key="FFFFFFFFFFFF",
            known_sector=0,
            known_key_type=KeyType.KEY_A
        )
        
        # Мокаем run
        with patch.object(NestedAttack, 'recover_all_keys', return_value={0: {'key_a': 'FFFFFFFFFFFF', 'key_b': '????????????'}}):
            thread.run()
        
        # Проверяем сигналы
        self.assertIsNotNone(thread.finished)
    
    def test_hardnested_attack_thread(self):
        """Тест потока Hardnested атаки"""
        config = HardnestedConfig(known_key="FFFFFFFFFFFF")
        
        thread = HardnestedAttackThread(self.mock_pm3, config)
        
        with patch.object(HardnestedAttack, 'run_with_progress', return_value={}):
            thread.run()
    
    def test_lf_bruteforce_thread(self):
        """Тест потока LF брутфорса"""
        config = LFBruteforceConfig(tag_type="em4100")
        
        thread = LFBruteforceThread(self.mock_pm3, config)
        
        with patch.object(LFAttacks, 'bruteforce_em4100', return_value=[]):
            thread.run()


if __name__ == '__main__':
    unittest.main()