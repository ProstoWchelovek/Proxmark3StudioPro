#!/usr/bin/env python3
# run_tests.py
"""
Запуск всех тестов Proxmark3 Studio Pro
"""

import unittest
import sys
import os


def run_all_tests():
    """Запуск всех тестов"""
    print("=" * 60)
    print("🧪 Запуск тестов Proxmark3 Studio Pro")
    print("=" * 60)
    
    loader = unittest.TestLoader()
    start_dir = os.path.join(os.path.dirname(__file__), 'tests')
    suite = loader.discover(start_dir, pattern='test_*.py')
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "=" * 60)
    print(f"📊 Результаты:")
    print(f"   Всего тестов: {result.testsRun}")
    print(f"   ✅ Успешно: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"   ❌ Провалено: {len(result.failures)}")
    print(f"   ⚠️ Ошибок: {len(result.errors)}")
    print("=" * 60)
    
    return 0 if result.wasSuccessful() else 1


def run_test_class(class_name: str):
    """Запуск конкретного класса тестов"""
    import importlib
    
    print(f"🧪 Запуск тестов: {class_name}")
    print("-" * 40)
    
    module_name = f"tests.test_{class_name.lower().replace('test', '').replace('pm3', 'pm3_client')}"
    
    try:
        module = importlib.import_module(module_name)
        if hasattr(module, class_name):
            suite = unittest.TestLoader().loadTestsFromTestCase(getattr(module, class_name))
            runner = unittest.TextTestRunner(verbosity=2)
            result = runner.run(suite)
            return 0 if result.wasSuccessful() else 1
        else:
            print(f"Класс {class_name} не найден")
            return 1
    except ImportError as e:
        print(f"Ошибка импорта: {e}")
        return 1


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Запуск тестов Proxmark3 Studio Pro')
    parser.add_argument('--test', type=str, help='Запуск конкретного теста (например, TestPM3Client)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Подробный вывод')
    
    args = parser.parse_args()
    
    if args.test:
        sys.exit(run_test_class(args.test))
    else:
        sys.exit(run_all_tests())