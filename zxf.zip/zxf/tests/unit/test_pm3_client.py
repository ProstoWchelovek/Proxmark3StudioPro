# tests/test_pm3_client.py
"""
Тесты для клиента Proxmark3
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.pm3_client import PM3Client
from core.command_executor import CommandExecutor
from core.output_parser import OutputParser


class TestPM3Client(unittest.TestCase):
    """Тесты для PM3Client"""
    
    def setUp(self):
        """Подготовка к тестам"""
        self.pm3 = PM3Client()
    
    def test_initial_state(self):
        """Тест начального состояния"""
        self.assertIsNone(self.pm3.serial_connection)
        self.assertFalse(self.pm3.is_connected)
        self.assertEqual(self.pm3.baudrate, 115200)
    
    @patch('core.pm3_client.serial.Serial')
    def test_connect_success(self, mock_serial):
        """Тест успешного подключения"""
        mock_serial.return_value.is_open = True
        mock_serial.return_value.name = "COM3"
        
        result = self.pm3.connect(port="COM3")
        
        self.assertTrue(result)
        self.assertTrue(self.pm3.is_connected)
        mock_serial.assert_called_once_with(port="COM3", baudrate=115200, timeout=5)
    
    @patch('core.pm3_client.serial.Serial')
    def test_connect_failure(self, mock_serial):
        """Тест ошибки подключения"""
        mock_serial.side_effect = Exception("Port not found")
        
        result = self.pm3.connect(port="COM99")
        
        self.assertFalse(result)
        self.assertFalse(self.pm3.is_connected)
    
    def test_disconnect(self):
        """Тест отключения"""
        # Симулируем подключение
        self.pm3.serial_connection = MagicMock()
        self.pm3.serial_connection.is_open = True
        self.pm3.is_connected = True
        
        self.pm3.disconnect()
        
        self.pm3.serial_connection.close.assert_called_once()
        self.assertIsNone(self.pm3.serial_connection)
        self.assertFalse(self.pm3.is_connected)
    
    @patch('core.pm3_client.serial.Serial')
    def test_send_command(self, mock_serial):
        """Тест отправки команды"""
        mock_serial_instance = MagicMock()
        mock_serial.return_value = mock_serial_instance
        mock_serial_instance.is_open = True
        
        self.pm3.connect(port="COM3")
        
        # Симулируем ответ
        mock_serial_instance.readline.side_effect = [
            b"pm3--> ",
            b"response line 1\r\n",
            b"response line 2\r\n",
            b"pm3--> ",
            b""
        ]
        
        result = self.pm3.send_command("hw version")
        
        self.assertIsNotNone(result)
        self.assertIn("response line 1", result)
    
    def test_run_command_when_disconnected(self):
        """Тест выполнения команды при отключённом устройстве"""
        result = self.pm3.run_command("hw version")
        
        self.assertIn("не подключен", result.lower())
    
    @patch('core.pm3_client.serial.Serial')
    def test_get_hardware_info(self, mock_serial):
        """Тест получения информации об устройстве"""
        mock_serial_instance = MagicMock()
        mock_serial.return_value = mock_serial_instance
        mock_serial_instance.is_open = True
        
        self.pm3.connect(port="COM3")
        
        # Симулируем ответ
        version_output = """
[=] Hardware: Proxmark3 Easy
[=] Version: v4.0.0
[=] Commit: 1234567
[=] FPGA image built 2024-01-15
"""
        
        with patch.object(self.pm3, 'run_command', return_value=version_output):
            info = self.pm3.get_hardware_info()
            
            self.assertEqual(info['device'], 'Proxmark3 Easy')
            self.assertEqual(info['version'], 'v4.0.0')
            self.assertEqual(info['commit'], '1234567')


class TestCommandExecutor(unittest.TestCase):
    """Тесты для CommandExecutor"""
    
    def setUp(self):
        self.executor = CommandExecutor(Mock())
    
    def test_build_command(self):
        """Тест построения команды"""
        cmd = self.executor.build_command("hf mf rdsc", sector=5, key_type="A", key="FFFFFFFFFFFF")
        self.assertIn("5", cmd)
        self.assertIn("A", cmd)
        self.assertIn("FFFFFFFFFFFF", cmd)
    
    def test_build_lf_command(self):
        """Тест построения LF команды"""
        cmd = self.executor.build_lf_command("em410x", "read")
        self.assertEqual(cmd, "lf em410x read")
    
    def test_build_hf_command(self):
        """Тест построения HF команды"""
        cmd = self.executor.build_hf_command("mf", "nested", sector=0)
        self.assertEqual(cmd, "hf mf nested 0")
    
    def test_validate_command(self):
        """Тест валидации команды"""
        # Допустимая команда
        self.assertTrue(self.executor.validate_command("hf 14a reader"))
        
        # Опасная команда
        self.assertFalse(self.executor.validate_command("hw reset"))


class TestOutputParser(unittest.TestCase):
    """Тесты для OutputParser"""
    
    def setUp(self):
        self.parser = OutputParser()
    
    def test_parse_mifare_uid(self):
        """Тест парсинга UID Mifare"""
        output = """
[+] UID: 04 12 34 56
[+] ATQA: 00 04
[+] SAK: 08
"""
        result = self.parser.parse_mifare_info(output)
        
        self.assertEqual(result['uid'], "04123456")
        self.assertEqual(result['atqa'], "0004")
        self.assertEqual(result['sak'], "08")
    
    def test_parse_em4100_uid(self):
        """Тест парсинга UID EM4100"""
        output = """
EM410x UID: 1A2B3C4D5E
Found EM4100 tag
"""
        result = self.parser.parse_em4100(output)
        
        self.assertEqual(result['uid'], "1A2B3C4D5E")
        self.assertTrue(result['found'])
    
    def test_parse_hid_data(self):
        """Тест парсинга HID данных"""
        output = """
HID Prox card found:
FC: 123
CN: 4567
Format: 26-bit
"""
        result = self.parser.parse_hid(output)
        
        self.assertEqual(result['facility_code'], 123)
        self.assertEqual(result['card_number'], 4567)
        self.assertEqual(result['format'], "26-bit")
    
    def test_parse_nested_attack(self):
        """Тест парсинга Nested атаки"""
        output = """
Sector 00: Key A: FFFFFFFFFFFF Key B: 000000000000
Sector 01: Key A: A0A1A2A3A4A5 Key B: ????????????
Found key for sector 02: B0B1B2B3B4B5
"""
        result = self.parser.parse_nested_output(output)
        
        self.assertIn(0, result)
        self.assertEqual(result[0]['key_a'], "FFFFFFFFFFF")
        self.assertIn(1, result)
        self.assertEqual(result[1]['key_a'], "A0A1A2A3A4A5")
    
    def test_extract_hex_keys(self):
        """Тест извлечения HEX ключей"""
        text = "Found keys: FFFFFFFFFFFF, A0A1A2A3A4A5, 112233445566"
        keys = self.parser.extract_hex_keys(text)
        
        self.assertEqual(len(keys), 3)
        self.assertIn("FFFFFFFFFFFF", keys)
        self.assertIn("A0A1A2A3A4A5", keys)
    
    def test_parse_error(self):
        """Тест парсинга ошибок"""
        error_output = "[!] Command failed: Invalid sector"
        result = self.parser.parse_error(error_output)
        
        self.assertTrue(result['has_error'])
        self.assertIn("Invalid sector", result['message'])
    
    def test_parse_success(self):
        """Тест парсинга успешных операций"""
        success_output = "[+] Operation completed successfully"
        result = self.parser.parse_success(success_output)
        
        self.assertTrue(result['success'])


class TestIntegration(unittest.TestCase):
    """Интеграционные тесты (с моками)"""
    
    def setUp(self):
        self.pm3 = PM3Client()
    
    @patch('core.pm3_client.serial.Serial')
    def test_full_read_mifare_flow(self, mock_serial):
        """Тест полного цикла чтения Mifare карты"""
        mock_serial_instance = MagicMock()
        mock_serial.return_value = mock_serial_instance
        mock_serial_instance.is_open = True
        
        self.pm3.connect(port="COM3")
        
        # Мокаем ответы
        responses = [
            "[+] UID: 04 12 34 56\r\n",
            "[+] ATQA: 00 04\r\n",
            "[+] SAK: 08\r\n",
            "pm3--> \r\n"
        ]
        
        mock_serial_instance.readline.side_effect = [b"\r\n".join(r.encode()) for r in responses]
        
        result = self.pm3.run_command("hf 14a reader")
        
        self.assertIsNotNone(result)
        self.assertIn("04123456", result)


if __name__ == '__main__':
    unittest.main()