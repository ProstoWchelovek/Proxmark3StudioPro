# tests/test_decoders.py
"""
Тесты для декодеров протоколов
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from decoders.em4100 import EM4100Decoder, EM4100Analyzer
from decoders.hid import HIDDecoder, HIDAnalyzer
from decoders.mifare import MifareDecoder, MifareAnalyzer
from decoders.iso14443 import ISO14443Decoder, APDUAnalyzer


class TestEM4100Decoder(unittest.TestCase):
    """Тесты для EM4100 декодера"""
    
    def test_decode_valid_uid(self):
        """Тест декодирования валидного UID"""
        # Данные EM4100 метки с UID = 0123456789
        raw_data = "FFFFFFFFFFFFFFFFFFFFFFFFFFFF"  # Упрощённо
        result = EM4100Decoder.decode(raw_data)
        
        # Проверяем структуру результата
        if result:
            self.assertIn('uid', result)
            self.assertIn('type', result)
    
    def test_encode_em4100(self):
        """Тест кодирования EM4100"""
        uid = "0123456789"
        encoded = EM4100Decoder.encode(uid)
        
        self.assertIsNotNone(encoded)
        self.assertTrue(len(encoded) > 0)
    
    def test_hex_to_bits(self):
        """Тест конвертации HEX в биты"""
        hex_str = "0F"
        bits = EM4100Decoder.hex_to_bits(hex_str)
        
        self.assertEqual(bits, "00001111")
    
    def test_bits_to_hex(self):
        """Тест конвертации бит в HEX"""
        bits = "00001111"
        hex_str = EM4100Decoder.bits_to_hex(bits)
        
        self.assertEqual(hex_str, "0F")
    
    def test_analyze_em4100(self):
        """Тест анализа EM4100"""
        result = EM4100Analyzer.analyze("0123456789")
        
        self.assertIn('valid', result)
        self.assertIn('uid', result)


class TestHIDDecoder(unittest.TestCase):
    """Тесты для HID декодера"""
    
    def test_decode_26bit_format(self):
        """Тест декодирования 26-битного формата"""
        # Пример HID 26-битной карты FC=123, CN=4567
        raw_data = "0A1B2C3D"  # Упрощённо
        result = HIDDecoder.decode(raw_data)
        
        if result:
            self.assertIn('facility_code', result)
            self.assertIn('card_number', result)
    
    def test_encode_26bit(self):
        """Тест кодирования 26-битного формата"""
        encoded = HIDDecoder.encode(facility_code=123, card_number=4567, format_bits=26)
        
        self.assertIsNotNone(encoded)
    
    def test_analyze_hid(self):
        """Тест анализа HID"""
        result = HIDAnalyzer.analyze("FC:123, CN:4567")
        
        self.assertIn('facility_code', result)
        self.assertIn('card_number', result)
    
    def test_different_formats(self):
        """Тест разных форматов"""
        for fmt in [26, 35, 37, 48]:
            encoded = HIDDecoder.encode(facility_code=123, card_number=4567, format_bits=fmt)
            self.assertIsNotNone(encoded)


class TestMifareDecoder(unittest.TestCase):
    """Тесты для Mifare декодера"""
    
    def test_decode_uid_4byte(self):
        """Тест декодирования 4-байтного UID"""
        uid_hex = "04123456"
        result = MifareDecoder.decode_uid(uid_hex)
        
        self.assertEqual(result['uid'], "04123456")
        self.assertEqual(result['length'], 4)
        self.assertIn('manufacturer', result)
    
    def test_decode_uid_7byte(self):
        """Тест декодирования 7-байтного UID"""
        uid_hex = "04123456789012"
        result = MifareDecoder.decode_uid(uid_hex)
        
        self.assertEqual(result['length'], 7)
        self.assertIn('manufacturer', result)
    
    def test_identify_card_classic(self):
        """Тест идентификации Classic карты"""
        result = MifareDecoder.identify_card(atqa="0004", sak="08")
        
        self.assertIn('Mifare Classic', result['name'])
    
    def test_identify_card_ultralight(self):
        """Тест идентификации Ultralight карты"""
        result = MifareDecoder.identify_card(atqa="0044", sak="00")
        
        self.assertIn('Ultralight', result['name'])
    
    def test_decode_sector_trailer(self):
        """Тест декодирования трейлера сектора"""
        trailer = "FFFFFFFFFFFFFF078069FFFFFFFFFFFF"
        result = MifareDecoder.decode_sector_trailer(trailer)
        
        self.assertIn('key_a', result)
        self.assertIn('key_b', result)
        self.assertIn('access_bits', result)
    
    def test_analyze_dump(self):
        """Тест анализа дампа"""
        # Создаём тестовый дамп 1K
        dump_data = b'\x00' * 1024
        result = MifareAnalyzer.analyze_dump(dump_data)
        
        self.assertEqual(result['size'], 1024)
        self.assertEqual(result['type'], 'Mifare Classic 1K')
        self.assertEqual(result['sectors'], 16)
    
    def test_analyze_4k_dump(self):
        """Тест анализа 4K дампа"""
        dump_data = b'\x00' * 4096
        result = MifareAnalyzer.analyze_dump(dump_data)
        
        self.assertEqual(result['type'], 'Mifare Classic 4K')
        self.assertEqual(result['sectors'], 40)


class TestISO14443Decoder(unittest.TestCase):
    """Тесты для ISO14443 декодера"""
    
    def test_decode_select_apdu(self):
        """Тест декодирования SELECT APDU"""
        apdu = "00A4040008A000000003000000"
        result = ISO14443Decoder.decode_apdu(apdu)
        
        self.assertEqual(result['cla'], "00")
        self.assertEqual(result['ins'], "A4")
        self.assertEqual(result['command'], "SELECT")
    
    def test_decode_read_binary(self):
        """Тест декодирования READ BINARY"""
        apdu = "00B0000000"
        result = ISO14443Decoder.decode_apdu(apdu)
        
        self.assertEqual(result['ins'], "B0")
        self.assertEqual(result['command'], "READ BINARY")
    
    def test_decode_response_success(self):
        """Тест декодирования успешного ответа"""
        response = "0000000000009000"
        result = ISO14443Decoder.decode_response(response)
        
        self.assertEqual(result['sw1'], "90")
        self.assertEqual(result['sw2'], "00")
        self.assertEqual(result['status'], "Успешно")
    
    def test_decode_response_error(self):
        """Тест декодирования ответа с ошибкой"""
        response = "6A82"
        result = ISO14443Decoder.decode_response(response)
        
        self.assertEqual(result['sw1'], "6A")
        self.assertEqual(result['sw2'], "82")
    
    def test_build_apdu(self):
        """Тест сборки APDU"""
        apdu = ISO14443Decoder.build_apdu(
            cla="00", ins="A4", p1="04", p2="00",
            data="A000000003000000"
        )
        
        self.assertIsNotNone(apdu)
        self.assertTrue(len(apdu) > 0)
    
    def test_analyze_trace(self):
        """Тест анализа трассировки"""
        trace = """
00A4040008A000000003000000
6A82
00B0000000
9000
"""
        results = APDUAnalyzer.analyze_trace(trace)
        
        self.assertGreaterEqual(len(results), 1)


class TestDecoderIntegration(unittest.TestCase):
    """Интеграционные тесты декодеров"""
    
    def test_em4100_roundtrip(self):
        """Тест полного цикла EM4100 кодирования/декодирования"""
        original_uid = "0123456789"
        
        # Кодируем
        encoded = EM4100Decoder.encode(original_uid)
        
        # Декодируем
        decoded = EM4100Decoder.decode(encoded)
        
        # Проверяем, что UID совпадает (если декодирование удалось)
        if decoded and 'uid' in decoded:
            self.assertEqual(decoded['uid'], original_uid)
    
    def test_hid_roundtrip(self):
        """Тест полного цикла HID кодирования/декодирования"""
        fc, cn = 123, 4567
        
        encoded = HIDDecoder.encode(fc, cn, format_bits=26)
        decoded = HIDDecoder.decode(encoded)
        
        if decoded:
            self.assertEqual(decoded['facility_code'], fc)
            self.assertEqual(decoded['card_number'], cn)
    
    def test_apdu_build_decode_cycle(self):
        """Тест цикла сборки/разбора APDU"""
        original = "00A4040008A000000003000000"
        decoded = ISO14443Decoder.decode_apdu(original)
        rebuilt = ISO14443Decoder.build_apdu(
            cla=decoded['cla'],
            ins=decoded['ins'],
            p1=decoded['p1'],
            p2=decoded['p2'],
            data=decoded.get('data', '')
        )
        
        # Проверяем, что основные параметры совпадают
        self.assertEqual(decoded['cla'], original[0:2])
        self.assertEqual(decoded['ins'], original[2:4])


if __name__ == '__main__':
    # Запуск всех тестов
    unittest.main(verbosity=2)