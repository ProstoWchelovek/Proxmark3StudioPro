# setup.py
from setuptools import setup, find_packages

setup(
    name="proxmark3-studio-pro",
    version="2.0.0",
    description="Professional GUI for Proxmark3",
    author="Proxmark Studio Team",
    packages=find_packages(),
    install_requires=[
        "PySide6>=6.6.0",
        "pyserial>=3.5",
        "cryptography>=41.0.0",
        "colorama>=0.4.6",
        "numpy>=1.24.0",
        "matplotlib>=3.7.0",
        "scipy>=1.10.0",
        "sqlalchemy>=2.0.0",
        "lupa>=2.0",
        "pyqtgraph>=0.13.0",
        "construct>=2.10.0",
    ],
    entry_points={
        "console_scripts": [
            "proxmark3-studio=main:main",
        ],
    },
)