# attacks_lib/mf_sniff.py
"""
Sniff атака - перехват обмена между ридером и картой
"""

import re
from typing import List, Dict, Set


class SniffAttack:
    """Реализация Sniff атаки"""
    
    def __init__(self, pm3_client):
        self.pm3 = pm3_client
    
    def run(self, timeout: int = 60) -> Set[str]:
        """
        Запуск перехвата
        
        Returns:
            Найденные ключи
        """
        cmd = "hf mf sniff"
        output = self.pm3.run_command(cmd)
        
        return self.parse_output(output)
    
    def parse_output(self, output: str) -> Set[str]:
        """Парсинг вывода для извлечения ключей"""
        keys = set()
        
        # Ищем ключи в формате 12 HEX символов
        key_matches = re.findall(r'\b([0-9A-F]{12})\b', output, re.IGNORECASE)
        for key in key_matches:
            if key.upper() != "FFFFFFFFFFFF":
                keys.add(key.upper())
        
        # Ищем ключи в формате "Key: XXXXXX"
        key_matches = re.findall(r'Key:\s*([0-9A-F]{12})', output, re.IGNORECASE)
        for key in key_matches:
            keys.add(key.upper())
        
        return keys
    
    def start_sniffing(self) -> None:
        """Начало перехвата (блокирующий вызов)"""
        self.pm3.run_command("hf mf sniff")
    
    def stop_sniffing(self) -> None:
        """Остановка перехвата"""
        self.pm3.send_command("\x03")


class SniffThread(QThread):
    """Поток для Sniff атаки"""
    
    data_received = Signal(str)
    key_found = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        try:
            attack = SniffAttack(self.pm3)
            keys = attack.run()
            
            for key in keys:
                if not self.running:
                    break
                self.key_found.emit(key)
                self.data_received.emit(f"Найден ключ: {key}")
            
        except Exception as e:
            self.data_received.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")