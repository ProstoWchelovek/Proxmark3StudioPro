# attacks_lib/mf_hardnested.py
"""
Hardnested Attack для Mifare Classic
Оптимизированная атака для быстрого нахождения ключей
"""

import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass


@dataclass
class HardnestedConfig:
    """Конфигурация Hardnested атаки"""
    known_key: str = "FFFFFFFFFFFF"
    known_sector: int = 0
    known_key_type: str = "A"
    target_sector: Optional[int] = None
    threads: int = 4
    timeout: int = 300
    save_keys: bool = True


class HardnestedAttack:
    """Реализация Hardnested атаки"""
    
    def __init__(self, pm3_client):
        self.pm3 = pm3_client
        
    def run(self, config: HardnestedConfig) -> Dict[int, Dict[str, str]]:
        """
        Запуск Hardnested атаки
        
        Args:
            config: Конфигурация атаки
        
        Returns:
            Найденные ключи
        """
        result = {}
        
        # Базовые параметры
        cmd = f"hf mf hardnested --key {config.known_key}"
        
        # Добавляем параметры
        if config.known_sector is not None:
            cmd += f" --sector {config.known_sector}"
        
        if config.known_key_type:
            cmd += f" --keytype {config.known_key_type}"
        
        if config.target_sector is not None:
            cmd += f" --targsec {config.target_sector}"
        
        if config.threads > 1:
            cmd += f" --threads {config.threads}"
        
        if config.timeout:
            cmd += f" --timeout {config.timeout}"
        
        # Выполнение
        output = self.pm3.run_command(cmd)
        
        # Парсинг результата
        result = self.parse_output(output)
        
        return result
    
    def parse_output(self, output: str) -> Dict[int, Dict[str, str]]:
        """Парсинг вывода Hardnested атаки"""
        result = {}
        
        # Ищем найденные ключи
        patterns = [
            # Key found: sector 01, key A: FFFFFFFFFFFF
            r'Key\s+found:\s+sector\s+(\d+),\s+key\s+([AB]):\s+([0-9A-F]{12})',
            # Found key: AAAAAAAAAAAA
            r'Found\s+key:\s*([0-9A-F]{12})',
            # Key A: FFFFFFFFFFFF
            r'Key\s+([AB]):\s*([0-9A-F]{12})',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, output, re.IGNORECASE)
            for match in matches:
                if len(match) == 3:
                    sector = int(match[0])
                    key_type = match[1].upper()
                    key = match[2].upper()
                    
                    if sector not in result:
                        result[sector] = {'key_a': '????????????', 'key_b': '????????????'}
                    
                    if key_type == 'A':
                        result[sector]['key_a'] = key
                    else:
                        result[sector]['key_b'] = key
                
                elif len(match) == 1:
                    # Ключ без сектора - пытаемся определить сектор из контекста
                    # По умолчанию считаем что это ключ для сектора 0
                    key = match[0].upper()
                    result[0] = {'key_a': key, 'key_b': '????????????'}
        
        return result
    
    def run_with_progress(self, config: HardnestedConfig, callback=None):
        """Запуск с колбэком прогресса"""
        output_lines = []
        
        # Симулируем прогресс (в реальности нужно парсить вывод в реальном времени)
        for i in range(0, 101, 10):
            if callback:
                callback(i, f"Выполнение Hardnested атаки... {i}%")
        
        result = self.run(config)
        
        if callback:
            callback(100, "Атака завершена")
        
        return result


class HardnestedAttackThread(QThread):
    """Поток для выполнения Hardnested атаки"""
    progress = Signal(int, str)
    key_found = Signal(int, str, str)
    finished = Signal(dict)
    
    def __init__(self, pm3, config: HardnestedConfig):
        super().__init__()
        self.pm3 = pm3
        self.config = config
    
    def run(self):
        attack = HardnestedAttack(self.pm3)
        
        self.progress.emit(0, "Инициализация Hardnested атаки...")
        
        # Запуск с прогрессом
        result = attack.run_with_progress(self.config, self.progress.emit)
        
        for sector, keys in result.items():
            self.key_found.emit(sector, keys['key_a'], keys['key_b'])
        
        self.finished.emit(result)