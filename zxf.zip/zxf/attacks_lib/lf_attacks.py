# attacks_lib/lf_attacks.py
"""
Атаки для низкочастотных меток (125kHz, 134kHz)
"""

import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass


@dataclass
class LFBruteforceConfig:
    """Конфигурация брутфорса LF меток"""
    tag_type: str = "em4100"  # em4100, hid, indala, etc.
    start_id: int = 0
    end_id: int = 65535
    facility_code: Optional[int] = None
    timeout: int = 5


class LFAttacks:
    """Атаки для LF меток"""
    
    def __init__(self, pm3_client):
        self.pm3 = pm3_client
    
    def bruteforce_em4100(self, config: LFBruteforceConfig) -> List[str]:
        """
        Брутфорс EM4100 ID
        
        Returns:
            Список найденных ID
        """
        found_ids = []
        
        for uid in range(config.start_id, config.end_id + 1):
            # Форматируем ID в EM4100 формат (10 символов)
            uid_hex = f"{uid:010X}"
            
            # Эмулируем метку с этим ID
            cmd = f"lf em 410x sim --id {uid_hex}"
            
            # Проверяем, реагирует ли ридер
            # (в реальности нужно проверять ответ ридера)
            
            # Для демонстрации - просто добавляем найденные
            if uid % 1000 == 0:
                found_ids.append(uid_hex)
            
            # Лимит для тестирования
            if len(found_ids) > 10:
                break
        
        return found_ids
    
    def bruteforce_hid(self, config: LFBruteforceConfig) -> List[Tuple[int, int]]:
        """
        Брутфорс HID карт
        
        Returns:
            Список (facility_code, card_number)
        """
        found = []
        
        fc_range = [config.facility_code] if config.facility_code else range(0, 256)
        
        for fc in fc_range:
            for cn in range(config.start_id, min(config.end_id, 65535) + 1):
                # Формируем команду для эмуляции
                cmd = f"lf hid sim --fc {fc} --cn {cn}"
                
                # Проверяем (в реальности нужен детектор ридера)
                # Для демонстрации:
                if cn % 1000 == 0:
                    found.append((fc, cn))
                
                if len(found) > 10:
                    break
        
        return found
    
    def sniff_reader(self, timeout: int = 30) -> Dict:
        """
        Перехват сигнала от ридера (sniff)
        
        Returns:
            Информация о перехваченном сигнале
        """
        cmd = f"lf snoop --timeout {timeout}"
        output = self.pm3.run_command(cmd)
        
        result = {
            'raw_data': output,
            'detected_tags': [],
            'timing': None
        }
        
        # Анализируем перехваченные данные
        if "EM410x" in output:
            uid_match = re.search(r'ID:\s*([0-9A-F]+)', output, re.IGNORECASE)
            if uid_match:
                result['detected_tags'].append({
                    'type': 'EM4100',
                    'id': uid_match.group(1)
                })
        
        if "HID" in output:
            fc_match = re.search(r'FC:\s*(\d+)', output)
            cn_match = re.search(r'CN:\s*(\d+)', output)
            if fc_match and cn_match:
                result['detected_tags'].append({
                    'type': 'HID',
                    'facility_code': int(fc_match.group(1)),
                    'card_number': int(cn_match.group(1))
                })
        
        return result
    
    def clone_tag(self, tag_type: str, data: str, config: Dict = None) -> bool:
        """
        Клонирование LF метки на T55x7
        
        Args:
            tag_type: Тип метки (em4100, hid, indala, etc.)
            data: Данные для клонирования (UID, FC:CN, etc.)
            config: Дополнительная конфигурация
        
        Returns:
            True если успешно
        """
        if tag_type.lower() == 'em4100':
            cmd = f"lf em 410x clone --uid {data}"
        
        elif tag_type.lower() == 'hid':
            if ':' in data:
                fc, cn = data.split(':')
                cmd = f"lf hid clone --fc {fc} --cn {cn}"
            else:
                cmd = f"lf hid clone --raw {data}"
        
        elif tag_type.lower() == 'indala':
            cmd = f"lf indala clone --id {data}"
        
        elif tag_type.lower() == 'awid':
            cmd = f"lf awid clone --data {data}"
        
        else:
            return False
        
        # Добавляем конфигурацию T55x7
        if config and 'config' in config:
            cmd += f" --config {config['config']}"
        
        # Добавляем пароль
        if config and 'password' in config:
            cmd += f" --password {config['password']}"
        
        output = self.pm3.run_command(cmd)
        
        return "clone" in output.lower() or "success" in output.lower()
    
    def emulate_tag(self, tag_type: str, data: str, repeat: int = 0) -> None:
        """
        Эмуляция LF метки
        
        Args:
            tag_type: Тип метки
            data: Данные для эмуляции
            repeat: Количество повторений (0 = бесконечно)
        """
        repeat_flag = "" if repeat == 0 else f" --repeat {repeat}"
        
        if tag_type.lower() == 'em4100':
            cmd = f"lf em 410x sim --id {data}{repeat_flag}"
        
        elif tag_type.lower() == 'hid':
            if ':' in data:
                fc, cn = data.split(':')
                cmd = f"lf hid sim --fc {fc} --cn {cn}{repeat_flag}"
            else:
                cmd = f"lf hid sim --raw {data}{repeat_flag}"
        
        else:
            return
        
        # Запускаем эмуляцию (это блокирующая операция)
        self.pm3.run_command(cmd)
    
    def analyze_signal(self, sample_data: str) -> Dict:
        """
        Анализ сырого сигнала
        
        Returns:
            Результаты анализа
        """
        result = {
            'frequency': None,
            'modulation': None,
            'encoding': None,
            'data': None,
            'confidence': 0
        }
        
        # Анализ частоты
        freq_match = re.search(r'Frequency:\s*([\d.]+)\s*kHz', sample_data, re.IGNORECASE)
        if freq_match:
            result['frequency'] = float(freq_match.group(1))
        
        # Анализ модуляции
        if "ASK" in sample_data:
            result['modulation'] = "ASK"
        elif "FSK" in sample_data:
            result['modulation'] = "FSK"
        elif "PSK" in sample_data:
            result['modulation'] = "PSK"
        
        # Анализ кодирования
        if "Manchester" in sample_data:
            result['encoding'] = "Manchester"
        elif "Biphase" in sample_data:
            result['encoding'] = "Biphase"
        
        # Определение типа метки по сигналу
        if result['frequency']:
            if 120 < result['frequency'] < 130:
                # 125kHz - возможные типы
                if "EM410" in sample_data:
                    result['data'] = "EM4100"
                    result['confidence'] = 90
                elif "HID" in sample_data:
                    result['data'] = "HID"
                    result['confidence'] = 85
        
        return result


class LFBruteforceThread(QThread):
    """Поток для брутфорса LF меток"""
    progress = Signal(int, str)
    found = Signal(dict)
    finished = Signal(list)
    
    def __init__(self, pm3, config: LFBruteforceConfig):
        super().__init__()
        self.pm3 = pm3
        self.config = config
    
    def run(self):
        attack = LFAttacks(self.pm3)
        
        if self.config.tag_type.lower() == 'em4100':
            self.progress.emit(0, "Брутфорс EM4100...")
            results = attack.bruteforce_em4100(self.config)
            
            for i, uid in enumerate(results):
                self.progress.emit(int(i / len(results) * 100), f"Проверка {uid}...")
                self.found.emit({'type': 'EM4100', 'uid': uid})
            
            self.finished.emit(results)
        
        elif self.config.tag_type.lower() == 'hid':
            self.progress.emit(0, "Брутфорс HID...")
            results = attack.bruteforce_hid(self.config)
            
            for i, (fc, cn) in enumerate(results):
                self.progress.emit(int(i / len(results) * 100), f"Проверка FC:{fc} CN:{cn}...")
                self.found.emit({'type': 'HID', 'facility_code': fc, 'card_number': cn})
            
            self.finished.emit(results)