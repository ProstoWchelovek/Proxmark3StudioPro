# attacks_lib/mf_darkside.py
"""
Darkside атака для Mifare Classic
"""

import re
from typing import Dict, Optional


class DarksideAttack:
    """Реализация Darkside атаки"""
    
    def __init__(self, pm3_client):
        self.pm3 = pm3_client
    
    def run(self, timeout: int = 120) -> Optional[str]:
        """
        Запуск Darkside атаки
        
        Returns:
            Найденный ключ или None
        """
        cmd = "hf mf darkside"
        output = self.pm3.run_command(cmd)
        
        return self.parse_output(output)
    
    def parse_output(self, output: str) -> Optional[str]:
        """Парсинг вывода для извлечения ключа"""
        # Ищем ключ в формате "Found key: FFFFFFFFFFFF"
        match = re.search(r'Found\s+key:\s*([0-9A-F]{12})', output, re.IGNORECASE)
        if match:
            return match.group(1).upper()
        
        # Альтернативный формат
        match = re.search(r'Key\s+found:\s*([0-9A-F]{12})', output, re.IGNORECASE)
        if match:
            return match.group(1).upper()
        
        return None
    
    def is_vulnerable(self) -> bool:
        """Проверка, уязвима ли карта к Darkside атаке"""
        # Кратковременная проверка
        output = self.pm3.run_command("hf mf darkside -t 5")
        return "vulnerable" in output.lower() or "found" in output.lower()


class DarksideAttackThread(QThread):
    """Поток для Darkside атаки"""
    
    progress = Signal(int)
    output = Signal(str)
    key_found = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        try:
            self.progress.emit(10)
            self.output.emit("Выполнение Darkside атаки...")
            
            attack = DarksideAttack(self.pm3)
            key = attack.run()
            
            if not self.running:
                return
            
            self.progress.emit(50)
            
            if key:
                self.output.emit(f"✅ Найден ключ: {key}")
                self.key_found.emit(key)
            else:
                self.output.emit("❌ Ключ не найден. Карта может быть не уязвима.")
            
            self.progress.emit(100)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")