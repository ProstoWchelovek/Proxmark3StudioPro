# attacks_lib/mf_nested.py
"""
Nested Attack для Mifare Classic
Использует известный ключ для нахождения ключей других секторов
"""

import re
import struct
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class KeyType(Enum):
    """Тип ключа"""
    KEY_A = "A"
    KEY_B = "B"


@dataclass
class SectorKey:
    """Информация о ключе сектора"""
    sector: int
    key_type: KeyType
    key: str
    found: bool = True


class NestedAttack:
    """Реализация Nested атаки"""
    
    def __init__(self, pm3_client):
        self.pm3 = pm3_client
        self.found_keys = {}
        
    def run(self, known_key: str, known_sector: int, known_key_type: KeyType, 
            target_sectors: List[int] = None) -> Dict[int, Dict[str, str]]:
        """
        Запуск Nested атаки
        
        Args:
            known_key: Известный ключ (12 HEX символов)
            known_sector: Сектор с известным ключом
            known_key_type: Тип известного ключа (A или B)
            target_sectors: Список целевых секторов (None = все)
        
        Returns:
            Словарь {сектор: {'key_a': '...', 'key_b': '...'}}
        """
        result = {}
        
        # Формируем команду для Proxmark3
        key_type = "A" if known_key_type == KeyType.KEY_A else "B"
        
        if target_sectors:
            sectors = ','.join(str(s) for s in target_sectors)
            cmd = f"hf mf nested 1 0 {known_key} {known_sector} {key_type} t {sectors}"
        else:
            cmd = f"hf mf nested 1 0 {known_key} {known_sector} {key_type} t"
        
        # Выполняем команду
        output = self.pm3.run_command(cmd)
        
        # Парсим результат
        result = self.parse_nested_output(output)
        
        return result
    
    def parse_nested_output(self, output: str) -> Dict[int, Dict[str, str]]:
        """Парсинг вывода Nested атаки"""
        result = {}
        
        # Ищем паттерны типа: |Sector 01| Key A: FFFFFFFFFFFF | Key B: 000000000000 |
        sector_pattern = r'\|\s*Sector\s+(\d+)\s*\|\s*Key\s+[AB]:\s*([0-9A-F]{12})\s*\|\s*Key\s+[AB]:\s*([0-9A-F]{12})\s*\|'
        
        matches = re.findall(sector_pattern, output, re.IGNORECASE)
        
        for match in matches:
            sector = int(match[0])
            key_a = match[1].upper()
            key_b = match[2].upper()
            
            result[sector] = {
                'key_a': key_a,
                'key_b': key_b
            }
        
        # Альтернативный парсинг для другого формата вывода
        if not result:
            # Ищем: Found key for sector 01: AAAAAAAAAAAA
            alt_pattern = r'Found\s+key\s+for\s+sector\s+(\d+):\s*([0-9A-F]{12})'
            matches = re.findall(alt_pattern, output, re.IGNORECASE)
            
            for match in matches:
                sector = int(match[0])
                key = match[1].upper()
                
                if sector not in result:
                    result[sector] = {'key_a': '????????????', 'key_b': '????????????'}
                
                # Определяем тип ключа по контексту
                if 'Key A' in output[max(0, match.start()-50):match.end()+50]:
                    result[sector]['key_a'] = key
                else:
                    result[sector]['key_b'] = key
        
        return result
    
    def recover_all_keys(self, known_key: str, known_sector: int, 
                         known_key_type: KeyType) -> Dict[int, Dict[str, str]]:
        """Рекурсивное восстановление всех ключей"""
        all_keys = {}
        found_sectors = {known_sector: {
            'key_a': known_key if known_key_type == KeyType.KEY_A else '????????????',
            'key_b': known_key if known_key_type == KeyType.KEY_B else '????????????'
        }}
        
        # Продолжаем пока находим новые ключи
        max_iterations = 10
        for _ in range(max_iterations):
            # Ищем новые сектора
            new_keys = self.run(known_key, known_sector, known_key_type)
            
            if not new_keys:
                break
            
            # Обновляем найденные ключи
            for sector, keys in new_keys.items():
                if sector not in found_sectors:
                    found_sectors[sector] = keys
                    # Используем новый ключ для дальнейшего поиска
                    if keys['key_a'] != '????????????':
                        known_key = keys['key_a']
                        known_key_type = KeyType.KEY_A
                    elif keys['key_b'] != '????????????':
                        known_key = keys['key_b']
                        known_key_type = KeyType.KEY_B
        
        return found_sectors


class NestedAttackThread(QThread):
    """Поток для выполнения Nested атаки"""
    progress = Signal(str)
    sector_found = Signal(int, str, str)  # sector, key_a, key_b
    finished = Signal(dict)
    
    def __init__(self, pm3, known_key: str, known_sector: int, known_key_type: KeyType):
        super().__init__()
        self.pm3 = pm3
        self.known_key = known_key
        self.known_sector = known_sector
        self.known_key_type = known_key_type
    
    def run(self):
        attack = NestedAttack(self.pm3)
        
        self.progress.emit(f"Запуск Nested атаки на сектор {self.known_sector} с ключом {self.known_key}")
        
        result = attack.recover_all_keys(self.known_key, self.known_sector, self.known_key_type)
        
        for sector, keys in result.items():
            self.sector_found.emit(sector, keys['key_a'], keys['key_b'])
        
        self.finished.emit(result)