# gui/keys/key_manager.py
"""
Менеджер ключей - центральная панель управления ключами
"""

from PySide6.QtWidgets import *

from gui.keys.key_table import KeyTableWidget
from gui.keys.key_importer import KeyImporter
from gui.keys.key_analyzer import KeyAnalyzer
from gui.keys.key_generator import KeyGeneratorDialog


class KeyManager(QWidget):
    """Менеджер ключей"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        header = QLabel("🔑 УПРАВЛЕНИЕ КЛЮЧАМИ")
        header.setStyleSheet("""
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #3c3c3c;
            border-radius: 5px;
        """)
        layout.addWidget(header)
        
        # Вкладки
        tabs = QTabWidget()
        
        # Таблица ключей
        self.key_table = KeyTableWidget(self.key_repo)
        tabs.addTab(self.key_table, "📋 СПИСОК КЛЮЧЕЙ")
        
        # Импорт
        self.key_importer = KeyImporter(self.key_repo)
        self.key_importer.keys_imported.connect(self.key_table.refresh)
        tabs.addTab(self.key_importer, "📥 ИМПОРТ")
        
        # Анализ
        self.key_analyzer = KeyAnalyzer(self.key_repo)
        tabs.addTab(self.key_analyzer, "📊 АНАЛИЗ")
        
        # Генератор
        tabs.addTab(KeyGeneratorDialog(self.key_repo, self), "🎲 ГЕНЕРАТОР")
        
        layout.addWidget(tabs)
        self.setLayout(layout)
    
    def import_dictionary(self):
        self.key_importer.import_from_file()
    
    def export_keys(self):
        self.key_table.export_keys()
    
    def show_key_generator(self):
        dialog = KeyGeneratorDialog(self.key_repo, self)
        dialog.exec()