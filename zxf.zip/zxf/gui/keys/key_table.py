# gui/keys/key_table.py
"""
Таблица ключей с редактированием, поиском и фильтрацией
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class KeyTableWidget(QWidget):
    """Таблица для отображения и управления ключами"""
    
    def __init__(self, key_repo):
        super().__init__()
        self.key_repo = key_repo
        self.init_ui()
        self.refresh()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Панель инструментов
        toolbar = QHBoxLayout()
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Поиск ключей...")
        self.search_input.textChanged.connect(self.filter_keys)
        
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["Все", "Стандартные", "Найденные", "Пользовательские"])
        self.filter_combo.currentTextChanged.connect(self.filter_keys)
        
        btn_add = QPushButton("➕ Добавить")
        btn_add.clicked.connect(self.add_key)
        
        btn_import = QPushButton("📂 Импорт")
        btn_import.clicked.connect(self.import_keys)
        
        btn_export = QPushButton("💾 Экспорт")
        btn_export.clicked.connect(self.export_keys)
        
        btn_delete_all = QPushButton("🗑️ Удалить все")
        btn_delete_all.clicked.connect(self.delete_all_keys)
        
        toolbar.addWidget(self.search_input)
        toolbar.addWidget(self.filter_combo)
        toolbar.addStretch()
        toolbar.addWidget(btn_add)
        toolbar.addWidget(btn_import)
        toolbar.addWidget(btn_export)
        toolbar.addWidget(btn_delete_all)
        
        # Таблица
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID", "Ключ", "Тип", "Теги", "Использований", "Действия"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        
        # Контекстное меню
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addLayout(toolbar)
        layout.addWidget(self.table)
        
        # Статус
        self.status_label = QLabel()
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
    
    def refresh(self):
        """Обновление таблицы"""
        keys = self.key_repo.get_all()
        self.all_keys = keys
        self.filter_keys()
    
    def filter_keys(self):
        """Фильтрация ключей"""
        search_text = self.search_input.text().lower()
        filter_type = self.filter_combo.currentText()
        
        filtered = []
        for key in self.all_keys:
            # Фильтр по типу
            if filter_type == "Стандартные" and key.key_type != "default":
                continue
            elif filter_type == "Найденные" and key.key_type not in ["nested_attack", "hardnested"]:
                continue
            elif filter_type == "Пользовательские" and key.key_type != "user":
                continue
            
            # Поиск
            if search_text:
                if search_text not in key.key.lower() and search_text not in (key.tags or "").lower():
                    continue
            
            filtered.append(key)
        
        self.display_keys(filtered)
        self.status_label.setText(f"Показано {len(filtered)} из {len(self.all_keys)} ключей")
    
    def display_keys(self, keys):
        """Отображение ключей в таблице"""
        self.table.setRowCount(len(keys))
        
        for i, key in enumerate(keys):
            self.table.setItem(i, 0, QTableWidgetItem(str(key.id)))
            self.table.setItem(i, 1, QTableWidgetItem(key.key))
            self.table.setItem(i, 2, QTableWidgetItem(key.key_type))
            self.table.setItem(i, 3, QTableWidgetItem(key.tags or ""))
            self.table.setItem(i, 4, QTableWidgetItem(str(key.usage_count)))
            
            # Кнопки действий
            btn_edit = QPushButton("✏️")
            btn_edit.clicked.connect(lambda checked, k=key: self.edit_key(k))
            btn_delete = QPushButton("🗑️")
            btn_delete.clicked.connect(lambda checked, k=key: self.delete_key(k))
            
            widget = QWidget()
            layout = QHBoxLayout(widget)
            layout.addWidget(btn_edit)
            layout.addWidget(btn_delete)
            layout.setContentsMargins(2, 2, 2, 2)
            widget.setLayout(layout)
            
            self.table.setCellWidget(i, 5, widget)
    
    def add_key(self):
        """Добавление ключа"""
        key, ok = QInputDialog.getText(self, "Добавить ключ", "Введите ключ (HEX):")
        if ok and key:
            key = key.upper().replace(" ", "")
            if len(key) in [12, 16] and all(c in "0123456789ABCDEF" for c in key):
                self.key_repo.add_key(key, key_type="user")
                self.refresh()
            else:
                QMessageBox.warning(self, "Ошибка", "Неверный формат ключа")
    
    def edit_key(self, key):
        """Редактирование ключа"""
        dialog = KeyEditDialog(key, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh()
    
    def delete_key(self, key):
        """Удаление ключа"""
        reply = QMessageBox.question(self, "Удаление", f"Удалить ключ {key.key}?",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.key_repo.delete(key.id)
            self.refresh()
    
    def delete_all_keys(self):
        """Удаление всех ключей"""
        reply = QMessageBox.question(self, "Удаление всех", "Удалить ВСЕ ключи? Это действие необратимо!",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.key_repo.delete_all()
            self.refresh()
    
    def import_keys(self):
        """Импорт ключей из файла"""
        filename, _ = QFileDialog.getOpenFileName(self, "Импорт ключей", "", "Dictionary files (*.dic *.txt)")
        if filename:
            count = self.key_repo.import_from_file(filename)
            QMessageBox.information(self, "Импорт", f"Импортировано {count} ключей")
            self.refresh()
    
    def export_keys(self):
        """Экспорт ключей в файл"""
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт ключей", "", "Dictionary files (*.dic)")
        if filename:
            count = self.key_repo.export_to_file(filename)
            QMessageBox.information(self, "Экспорт", f"Экспортировано {count} ключей")
    
    def show_context_menu(self, pos):
        """Показать контекстное меню"""
        menu = QMenu()
        menu.addAction("📋 Копировать ключ", self.copy_selected_key)
        menu.addAction("🔍 Проверить на карте", self.test_key_on_card)
        menu.addAction("🏷️ Изменить теги", self.edit_tags)
        menu.addSeparator()
        menu.addAction("🗑️ Удалить", self.delete_selected_key)
        menu.exec(self.table.viewport().mapToGlobal(pos))
    
    def copy_selected_key(self):
        current = self.table.currentRow()
        if current >= 0:
            key_item = self.table.item(current, 1)
            if key_item:
                QApplication.clipboard().setText(key_item.text())
    
    def test_key_on_card(self):
        """Проверка ключа на карте"""
        # TODO: реализовать проверку ключа на карте
        QMessageBox.information(self, "Проверка", "Функция в разработке")
    
    def edit_tags(self):
        current = self.table.currentRow()
        if current >= 0:
            key_id = int(self.table.item(current, 0).text())
            key = self.key_repo.get_by_id(key_id)
            if key:
                tags, ok = QInputDialog.getText(self, "Теги", "Введите теги:", text=key.tags)
                if ok:
                    key.tags = tags
                    self.key_repo.update(key)
                    self.refresh()
    
    def delete_selected_key(self):
        current = self.table.currentRow()
        if current >= 0:
            key_id = int(self.table.item(current, 0).text())
            key = self.key_repo.get_by_id(key_id)
            self.delete_key(key)


class KeyEditDialog(QDialog):
    """Диалог редактирования ключа"""
    
    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key = key
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Редактирование ключа")
        self.setModal(True)
        layout = QFormLayout(self)
        
        self.key_edit = QLineEdit()
        self.key_edit.setText(self.key.key)
        self.key_edit.setReadOnly(True)
        
        self.type_combo = QComboBox()
        self.type_combo.addItems(["default", "known", "user", "custom"])
        self.type_combo.setCurrentText(self.key.key_type)
        
        self.tags_edit = QLineEdit()
        self.tags_edit.setText(self.key.tags or "")
        
        self.desc_edit = QTextEdit()
        self.desc_edit.setText(self.key.description or "")
        self.desc_edit.setMaximumHeight(100)
        
        layout.addRow("Ключ:", self.key_edit)
        layout.addRow("Тип:", self.type_combo)
        layout.addRow("Теги:", self.tags_edit)
        layout.addRow("Описание:", self.desc_edit)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
    
    def save(self):
        self.key.key_type = self.type_combo.currentText()
        self.key.tags = self.tags_edit.text()
        self.key.description = self.desc_edit.toPlainText()
        self.key_repo.update(self.key)
        self.accept()