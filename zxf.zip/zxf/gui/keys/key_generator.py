# gui/keys/key_generator.py
"""
Генератор ключей
"""

from PySide6.QtWidgets import *
from PySide6.QtGui import QFont
import secrets


class KeyGeneratorDialog(QDialog):
    """Диалог генерации ключей"""
    
    def __init__(self, key_repo, parent=None):
        super().__init__(parent)
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Генератор ключей")
        self.setModal(True)
        layout = QVBoxLayout(self)
        
        # Параметры
        params_group = QGroupBox("Параметры генерации")
        params_layout = QFormLayout()
        
        self.length_combo = QComboBox()
        self.length_combo.addItems(["48 бит (6 байт)", "64 бит (8 байт)", "96 бит (12 байт)", "128 бит (16 байт)"])
        
        self.count_spin = QSpinBox()
        self.count_spin.setRange(1, 100)
        self.count_spin.setValue(10)
        
        self.type_combo = QComboBox()
        self.type_combo.addItems(["Случайные", "Последовательные", "Стандартные"])
        
        params_layout.addRow("Длина:", self.length_combo)
        params_layout.addRow("Количество:", self.count_spin)
        params_layout.addRow("Тип:", self.type_combo)
        params_group.setLayout(params_layout)
        
        # Кнопки
        btn_generate = QPushButton("🎲 СГЕНЕРИРОВАТЬ")
        btn_generate.clicked.connect(self.generate)
        
        btn_save = QPushButton("💾 СОХРАНИТЬ В БД")
        btn_save.clicked.connect(self.save_to_db)
        
        btn_export = QPushButton("📁 ЭКСПОРТ В ФАЙЛ")
        btn_export.clicked.connect(self.export_to_file)
        
        # Результат
        result_group = QGroupBox("Сгенерированные ключи")
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setFont(QFont("Courier New", 10))
        
        result_layout.addWidget(self.result_text)
        result_group.setLayout(result_layout)
        
        layout.addWidget(params_group)
        layout.addWidget(btn_generate)
        layout.addWidget(btn_save)
        layout.addWidget(btn_export)
        layout.addWidget(result_group)
        
        self.generated_keys = []
    
    def generate(self):
        length_map = {"48 бит (6 байт)": 6, "64 бит (8 байт)": 8, "96 бит (12 байт)": 12, "128 бит (16 байт)": 16}
        bytes_count = length_map[self.length_combo.currentText()]
        count = self.count_spin.value()
        gen_type = self.type_combo.currentText()
        
        self.generated_keys = []
        
        if gen_type == "Случайные":
            for _ in range(count):
                key = secrets.token_hex(bytes_count).upper()
                self.generated_keys.append(key)
        
        elif gen_type == "Последовательные":
            for i in range(count):
                key = f"{i:0{bytes_count*2}X}"
                self.generated_keys.append(key)
        
        else:  # Стандартные
            default_keys = [
                "FFFFFFFFFFFF", "000000000000", "A0A1A2A3A4A5", "D3F7D3F7D3F7",
                "A0B0C0D0E0F0", "1A2B3C4D5E6F", "112233445566", "123456789ABC"
            ]
            self.generated_keys = default_keys[:count]
        
        self.result_text.clear()
        for key in self.generated_keys:
            self.result_text.append(key)
    
    def save_to_db(self):
        if not self.generated_keys:
            QMessageBox.warning(self, "Ошибка", "Сначала сгенерируйте ключи")
            return
        
        saved = 0
        for key in self.generated_keys:
            if self.key_repo.add_key(key, key_type="generated", tags="generated"):
                saved += 1
        
        QMessageBox.information(self, "Сохранение", f"Сохранено {saved} ключей")
    
    def export_to_file(self):
        if not self.generated_keys:
            QMessageBox.warning(self, "Ошибка", "Сначала сгенерируйте ключи")
            return
        
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт ключей", "", "Dictionary files (*.dic)")
        if filename:
            with open(filename, 'w') as f:
                for key in self.generated_keys:
                    f.write(f"{key}\n")
            QMessageBox.information(self, "Экспорт", f"Ключи сохранены в {filename}")