# gui/keys/key_editor.py
"""
Редактор ключей с возможностью пакетного редактирования
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class KeyEditorDialog(QDialog):
    """Диалог пакетного редактирования ключей"""
    
    def __init__(self, key_repo, parent=None):
        super().__init__(parent)
        self.key_repo = key_repo
        self.selected_keys = []
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Пакетное редактирование ключей")
        self.setGeometry(300, 300, 800, 600)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Список ключей
        self.key_list = QListWidget()
        self.key_list.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
        
        btn_load = QPushButton("📋 Загрузить ключи")
        btn_load.clicked.connect(self.load_keys)
        
        # Операции
        ops_group = QGroupBox("Операции")
        ops_layout = QGridLayout()
        
        self.add_tag_input = QLineEdit()
        self.add_tag_input.setPlaceholderHeader("Тег для добавления")
        btn_add_tag = QPushButton("➕ Добавить тег")
        btn_add_tag.clicked.connect(self.add_tag)
        
        self.remove_tag_input = QLineEdit()
        self.remove_tag_input.setPlaceholderText("Тег для удаления")
        btn_remove_tag = QPushButton("➖ Удалить тег")
        btn_remove_tag.clicked.connect(self.remove_tag)
        
        self.set_type_combo = QComboBox()
        self.set_type_combo.addItems(["default", "known", "user", "custom"])
        btn_set_type = QPushButton("🏷️ Установить тип")
        btn_set_type.clicked.connect(self.set_type)
        
        ops_layout.addWidget(self.add_tag_input, 0, 0)
        ops_layout.addWidget(btn_add_tag, 0, 1)
        ops_layout.addWidget(self.remove_tag_input, 1, 0)
        ops_layout.addWidget(btn_remove_tag, 1, 1)
        ops_layout.addWidget(self.set_type_combo, 2, 0)
        ops_layout.addWidget(btn_set_type, 2, 1)
        ops_group.setLayout(ops_layout)
        
        # Кнопки
        btn_apply = QPushButton("✅ Применить")
        btn_apply.clicked.connect(self.apply_changes)
        
        btn_close = QPushButton("Закрыть")
        btn_close.clicked.connect(self.reject)
        
        layout.addWidget(self.key_list)
        layout.addWidget(btn_load)
        layout.addWidget(ops_group)
        layout.addWidget(btn_apply)
        layout.addWidget(btn_close)
    
    def load_keys(self):
        self.key_list.clear()
        keys = self.key_repo.get_all()
        for key in keys:
            item = QListWidgetItem(f"{key.key} [{key.key_type}] - {key.tags or ''}")
            item.setData(Qt.UserRole, key)
            self.key_list.addItem(item)
    
    def get_selected(self):
        return [item.data(Qt.UserRole) for item in self.key_list.selectedItems()]
    
    def add_tag(self):
        tag = self.add_tag_input.text().strip()
        if not tag:
            return
        
        for key in self.get_selected():
            current_tags = key.tags or ""
            if tag not in current_tags:
                new_tags = f"{current_tags}, {tag}" if current_tags else tag
                key.tags = new_tags
                self.key_repo.update(key)
        
        self.load_keys()
        self.add_tag_input.clear()
    
    def remove_tag(self):
        tag = self.remove_tag_input.text().strip()
        if not tag:
            return
        
        for key in self.get_selected():
            current_tags = key.tags or ""
            tags_list = [t.strip() for t in current_tags.split(',') if t.strip() and t.strip() != tag]
            key.tags = ', '.join(tags_list) if tags_list else None
            self.key_repo.update(key)
        
        self.load_keys()
        self.remove_tag_input.clear()
    
    def set_type(self):
        new_type = self.set_type_combo.currentText()
        
        for key in self.get_selected():
            key.key_type = new_type
            self.key_repo.update(key)
        
        self.load_keys()
    
    def apply_changes(self):
        self.accept()