# gui/keys/key_importer.py
"""
Импорт словарей ключей из различных форматов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os
import re
from pathlib import Path
from typing import List, Dict, Optional
import hashlib
from datetime import datetime


class KeyImporter(QWidget):
    """Импорт словарей ключей"""
    
    keys_imported = Signal(int)
    
    def __init__(self, key_repo):
        super().__init__()
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        title = QLabel("Импорт словарей ключей")
        title.setStyleSheet("font-size: 16px; font-weight: bold; margin: 10px;")
        layout.addWidget(title)
        
        # Вкладки для разных источников
        tabs = QTabWidget()
        
        # Вкладка: Из файла
        tabs.addTab(self.create_file_import_tab(), "📁 ИЗ ФАЙЛА")
        
        # Вкладка: Из буфера обмена
        tabs.addTab(self.create_clipboard_tab(), "📋 ИЗ БУФЕРА")
        
        # Вкладка: Стандартные словари
        tabs.addTab(self.create_standard_tab(), "📚 СТАНДАРТНЫЕ")
        
        layout.addWidget(tabs)
        
        # История импортов
        history_group = QGroupBox("История импортов")
        history_layout = QVBoxLayout()
        
        self.history_list = QListWidget()
        history_layout.addWidget(self.history_list)
        
        btn_clear_history = QPushButton("Очистить историю")
        btn_clear_history.clicked.connect(self.clear_history)
        history_layout.addWidget(btn_clear_history)
        
        history_group.setLayout(history_layout)
        layout.addWidget(history_group)
        
        self.setLayout(layout)
        self.load_history()
    
    def create_file_import_tab(self):
        """Вкладка импорта из файла"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Выбор файла
        file_group = QGroupBox("Выбор файла")
        file_layout = QHBoxLayout()
        
        self.file_path = QLineEdit()
        self.file_path.setReadOnly(True)
        self.file_path.setPlaceholderText("Выберите файл словаря...")
        
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(self.browse_file)
        
        file_layout.addWidget(self.file_path)
        file_layout.addWidget(btn_browse)
        file_group.setLayout(file_layout)
        
        # Формат файла
        format_group = QGroupBox("Формат файла")
        format_layout = QVBoxLayout()
        
        self.format_combo = QComboBox()
        self.format_combo.addItems([
            "Автоопределение",
            "Простой список ключей (по одному на строку)",
            "Mifare Classic (.dic)",
            "HEX строки (8-16 символов)",
            "MFOC ключи"
        ])
        
        format_layout.addWidget(self.format_combo)
        format_group.setLayout(format_layout)
        
        # Предпросмотр
        preview_group = QGroupBox("Предпросмотр")
        preview_layout = QVBoxLayout()
        
        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setMaximumHeight(150)
        self.preview_text.setFont(QFont("Courier New", 10))
        
        preview_layout.addWidget(self.preview_text)
        preview_group.setLayout(preview_layout)
        
        # Опции импорта
        options_group = QGroupBox("Опции импорта")
        options_layout = QGridLayout()
        
        self.skip_duplicates = QCheckBox("Пропускать дубликаты")
        self.skip_duplicates.setChecked(True)
        
        self.validate_keys = QCheckBox("Проверять валидность ключей")
        self.validate_keys.setChecked(True)
        
        self.add_tags = QCheckBox("Добавить теги")
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("импорт, словарь")
        self.tags_edit.setEnabled(False)
        self.add_tags.toggled.connect(self.tags_edit.setEnabled)
        
        options_layout.addWidget(self.skip_duplicates, 0, 0)
        options_layout.addWidget(self.validate_keys, 0, 1)
        options_layout.addWidget(self.add_tags, 1, 0, 1, 2)
        options_layout.addWidget(self.tags_edit, 2, 0, 1, 2)
        options_group.setLayout(options_layout)
        
        # Кнопки
        btn_preview = QPushButton("👁️ Предпросмотр")
        btn_preview.clicked.connect(self.preview_file)
        
        btn_import = QPushButton("📥 ИМПОРТИРОВАТЬ")
        btn_import.clicked.connect(self.import_from_file)
        btn_import.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_preview)
        button_layout.addStretch()
        button_layout.addWidget(btn_import)
        
        layout.addWidget(file_group)
        layout.addWidget(format_group)
        layout.addWidget(preview_group)
        layout.addWidget(options_group)
        layout.addLayout(button_layout)
        
        return widget
    
    def create_clipboard_tab(self):
        """Вкладка импорта из буфера обмена"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.clipboard_text = QTextEdit()
        self.clipboard_text.setPlaceholderText("Вставьте ключи здесь...")
        self.clipboard_text.setFont(QFont("Courier New", 10))
        
        btn_paste = QPushButton("📋 Вставить из буфера")
        btn_paste.clicked.connect(self.paste_from_clipboard)
        
        btn_import = QPushButton("📥 ИМПОРТИРОВАТЬ")
        btn_import.clicked.connect(self.import_from_clipboard)
        btn_import.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        layout.addWidget(btn_paste)
        layout.addWidget(self.clipboard_text)
        layout.addWidget(btn_import)
        
        return widget
    
    def create_standard_tab(self):
        """Вкладка со стандартными словарями"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.standard_list = QListWidget()
        
        standard_dicts = [
            ("Стандартные ключи Mifare", "FFFFFFFFFFFF, 000000000000, A0A1A2A3A4A5, D3F7D3F7D3F7, A0B0C0D0E0F0"),
            ("Расширенный словарь", "Расширенный набор из 50+ ключей"),
            ("Слабые ключи", "112233445566, 123456789ABC, 1A2B3C4D5E6F"),
            ("Тестовые ключи", "010203040506, 020304050607, 030405060708"),
        ]
        
        for name, desc in standard_dicts:
            item = QListWidgetItem(f"📚 {name}")
            item.setToolTip(desc)
            item.setData(Qt.UserRole, name)
            self.standard_list.addItem(item)
        
        btn_import = QPushButton("📥 ИМПОРТИРОВАТЬ ВЫБРАННЫЙ")
        btn_import.clicked.connect(self.import_standard)
        btn_import.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        layout.addWidget(self.standard_list)
        layout.addWidget(btn_import)
        
        return widget
    
    def browse_file(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите файл словаря", "", 
                                                   "Dictionary files (*.dic *.txt);;All files (*.*)")
        if filename:
            self.file_path.setText(filename)
    
    def paste_from_clipboard(self):
        clipboard = QApplication.clipboard()
        text = clipboard.text()
        if text:
            self.clipboard_text.setText(text)
    
    def preview_file(self):
        filename = self.file_path.text()
        if not filename or not os.path.exists(filename):
            return
        
        keys = self.parse_keys_from_file(filename, preview=True)
        self.preview_text.clear()
        
        if keys:
            self.preview_text.append(f"Найдено ключей: {len(keys)}\n")
            self.preview_text.append("-" * 40 + "\n")
            for i, key in enumerate(keys[:50], 1):
                self.preview_text.append(f"{i:3d}. {key}")
            if len(keys) > 50:
                self.preview_text.append(f"\n... и еще {len(keys) - 50} ключей")
        else:
            self.preview_text.append("Не найдено валидных ключей")
    
    def parse_keys_from_file(self, filename: str, preview: bool = False) -> List[str]:
        """Парсинг ключей из файла"""
        keys = []
        
        try:
            with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Ищем HEX строки длиной 8-16 символов
            hex_pattern = r'\b[0-9A-Fa-f]{8,16}\b'
            matches = re.findall(hex_pattern, content)
            
            for match in matches:
                key = match.upper()
                if self.is_valid_key(key):
                    keys.append(key)
            
            if not preview and self.skip_duplicates.isChecked():
                keys = list(dict.fromkeys(keys))
            
        except Exception as e:
            print(f"Ошибка чтения: {e}")
        
        return keys
    
    def is_valid_key(self, key: str) -> bool:
        """Проверка валидности ключа"""
        if not key:
            return False
        
        key = key.replace(' ', '').replace('-', '').replace(':', '')
        
        # Допустимые длины: 8, 10, 12, 14, 16 символов
        if len(key) not in [8, 10, 12, 14, 16]:
            return False
        
        return all(c in "0123456789ABCDEF" for c in key)
    
    def import_from_file(self):
        filename = self.file_path.text()
        if not filename:
            QMessageBox.warning(self, "Ошибка", "Выберите файл для импорта")
            return
        
        keys = self.parse_keys_from_file(filename)
        
        if not keys:
            QMessageBox.warning(self, "Ошибка", "Не найдено валидных ключей")
            return
        
        tags = self.tags_edit.text() if self.add_tags.isChecked() else "import"
        
        imported = 0
        for key in keys:
            if self.key_repo.add_key(key, key_type="dictionary", tags=tags, source=os.path.basename(filename)):
                imported += 1
        
        self.save_to_history(filename, imported)
        
        QMessageBox.information(self, "Импорт", f"Импортировано {imported} ключей")
        self.keys_imported.emit(imported)
    
    def import_from_clipboard(self):
        text = self.clipboard_text.toPlainText()
        if not text:
            QMessageBox.warning(self, "Ошибка", "Нет данных для импорта")
            return
        
        keys = []
        hex_pattern = r'\b[0-9A-Fa-f]{8,16}\b'
        matches = re.findall(hex_pattern, text, re.IGNORECASE)
        
        for match in matches:
            key = match.upper()
            if self.is_valid_key(key):
                keys.append(key)
        
        if not keys:
            QMessageBox.warning(self, "Ошибка", "Не найдено валидных ключей")
            return
        
        imported = 0
        for key in keys:
            if self.key_repo.add_key(key, key_type="clipboard", tags="clipboard_import"):
                imported += 1
        
        QMessageBox.information(self, "Импорт", f"Импортировано {imported} ключей")
        self.keys_imported.emit(imported)
    
    def import_standard(self):
        current = self.standard_list.currentItem()
        if not current:
            QMessageBox.warning(self, "Ошибка", "Выберите словарь")
            return
        
        dict_name = current.data(Qt.UserRole)
        
        standard_keys = {
            "Стандартные ключи Mifare": [
                "FFFFFFFFFFFF", "000000000000", "A0A1A2A3A4A5", "D3F7D3F7D3F7",
                "A0B0C0D0E0F0", "1A2B3C4D5E6F", "112233445566", "123456789ABC",
                "4C49424E4F43", "4E4554475554", "AA55AA55AA55", "55AA55AA55AA"
            ],
            "Расширенный словарь": [
                "A0A0A0A0A0A0", "B0B0B0B0B0B0", "C0C0C0C0C0C0", "D0D0D0D0D0D0",
                "E0E0E0E0E0E0", "F0F0F0F0F0F0", "1234567890AB", "ABCDEF012345"
            ],
            "Слабые ключи": [
                "112233445566", "123456789ABC", "1A2B3C4D5E6F", "010203040506",
                "020304050607", "030405060708", "040506070809", "05060708090A"
            ],
            "Тестовые ключи": [
                "010203040506", "020304050607", "030405060708", "040506070809"
            ]
        }
        
        keys = standard_keys.get(dict_name, [])
        
        imported = 0
        for key in keys:
            if self.key_repo.add_key(key, key_type="standard", tags=f"standard_{dict_name}"):
                imported += 1
        
        QMessageBox.information(self, "Импорт", f"Импортировано {imported} ключей")
        self.keys_imported.emit(imported)
    
    def save_to_history(self, source: str, count: int):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        history_item = f"[{timestamp}] {os.path.basename(source)}: +{count} ключей"
        
        history_file = Path.home() / ".proxmark3_studio" / "import_history.txt"
        history_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(history_file, 'a', encoding='utf-8') as f:
            f.write(history_item + '\n')
        
        self.load_history()
    
    def load_history(self):
        self.history_list.clear()
        
        history_file = Path.home() / ".proxmark3_studio" / "import_history.txt"
        if history_file.exists():
            with open(history_file, 'r', encoding='utf-8') as f:
                for line in f:
                    self.history_list.addItem(line.strip())
    
    def clear_history(self):
        self.history_list.clear()
        history_file = Path.home() / ".proxmark3_studio" / "import_history.txt"
        if history_file.exists():
            os.remove(history_file)