# gui/keys/key_analyzer.py
"""
Анализ и статистика ключей
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re
from collections import Counter
from typing import List, Dict
import math


class KeyAnalyzer(QWidget):
    """Анализ ключей"""
    
    def __init__(self, key_repo):
        super().__init__()
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        title = QLabel("Анализ ключей доступа")
        title.setStyleSheet("font-size: 16px; font-weight: bold; margin: 10px;")
        layout.addWidget(title)
        
        # Вкладки
        tabs = QTabWidget()
        
        tabs.addTab(self.create_stats_tab(), "📊 СТАТИСТИКА")
        tabs.addTab(self.create_weak_tab(), "⚠️ СЛАБЫЕ КЛЮЧИ")
        tabs.addTab(self.create_patterns_tab(), "🔍 ПОИСК")
        
        layout.addWidget(tabs)
        self.setLayout(layout)
        
        QTimer.singleShot(100, self.update_stats)
    
    def create_stats_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Общая статистика
        stats_group = QGroupBox("Общая статистика")
        stats_layout = QGridLayout()
        
        self.total_keys = QLabel("0")
        self.unique_keys = QLabel("0")
        self.weak_keys = QLabel("0")
        self.avg_entropy = QLabel("-")
        
        stats_layout.addWidget(QLabel("Всего ключей:"), 0, 0)
        stats_layout.addWidget(self.total_keys, 0, 1)
        stats_layout.addWidget(QLabel("Уникальных:"), 0, 2)
        stats_layout.addWidget(self.unique_keys, 0, 3)
        stats_layout.addWidget(QLabel("Слабых ключей:"), 1, 0)
        stats_layout.addWidget(self.weak_keys, 1, 1)
        stats_layout.addWidget(QLabel("Ср. энтропия:"), 1, 2)
        stats_layout.addWidget(self.avg_entropy, 1, 3)
        
        stats_group.setLayout(stats_layout)
        
        # По типам
        types_group = QGroupBox("Распределение по типам")
        types_layout = QVBoxLayout()
        
        self.types_list = QListWidget()
        types_layout.addWidget(self.types_list)
        types_group.setLayout(types_layout)
        
        # Популярные ключи
        popular_group = QGroupBox("Наиболее часто используемые ключи")
        popular_layout = QVBoxLayout()
        
        self.popular_list = QListWidget()
        popular_layout.addWidget(self.popular_list)
        popular_group.setLayout(popular_layout)
        
        layout.addWidget(stats_group)
        layout.addWidget(types_group)
        layout.addWidget(popular_group)
        
        return widget
    
    def create_weak_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Категории слабых ключей
        categories = [
            ("🔴 Все нули", self.find_zero_keys),
            ("🟡 Повторяющиеся байты", self.find_repeating_keys),
            ("🟢 Инкрементные ключи", self.find_incremental_keys),
            ("🔵 Стандартные ключи", self.find_default_keys),
        ]
        
        button_layout = QGridLayout()
        for i, (name, func) in enumerate(categories):
            btn = QPushButton(name)
            btn.clicked.connect(func)
            button_layout.addWidget(btn, i // 2, i % 2)
        
        # Результаты
        results_group = QGroupBox("Найденные слабые ключи")
        results_layout = QVBoxLayout()
        
        self.weak_results = QListWidget()
        self.weak_results.itemDoubleClicked.connect(self.copy_key)
        results_layout.addWidget(self.weak_results)
        results_group.setLayout(results_layout)
        
        layout.addLayout(button_layout)
        layout.addWidget(results_group)
        
        return widget
    
    def create_patterns_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Поиск
        search_group = QGroupBox("Поиск ключей")
        search_layout = QHBoxLayout()
        
        self.pattern_input = QLineEdit()
        self.pattern_input.setPlaceholderText("Поиск...")
        self.pattern_input.returnPressed.connect(self.search_pattern)
        
        btn_search = QPushButton("🔍 Найти")
        btn_search.clicked.connect(self.search_pattern)
        
        search_layout.addWidget(self.pattern_input)
        search_layout.addWidget(btn_search)
        search_group.setLayout(search_layout)
        
        # Результаты
        results_group = QGroupBox("Результаты поиска")
        results_layout = QVBoxLayout()
        
        self.search_results = QListWidget()
        self.search_results.itemDoubleClicked.connect(self.copy_key)
        results_layout.addWidget(self.search_results)
        results_group.setLayout(results_layout)
        
        layout.addWidget(search_group)
        layout.addWidget(results_group)
        
        return widget
    
    def update_stats(self):
        """Обновление статистики"""
        keys = self.key_repo.get_all()
        
        self.total_keys.setText(str(len(keys)))
        
        unique = len(set(k.key if hasattr(k, 'key') else k for k in keys))
        self.unique_keys.setText(str(unique))
        
        # По типам
        types = Counter()
        weak_count = 0
        entropies = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            if hasattr(key, 'key_type'):
                types[key.key_type] += 1
            if hasattr(key, 'is_weak') and key.is_weak:
                weak_count += 1
            entropies.append(self.compute_entropy(key_str))
        
        self.weak_keys.setText(str(weak_count))
        
        if entropies:
            self.avg_entropy.setText(f"{sum(entropies)/len(entropies):.4f}")
        
        self.types_list.clear()
        for t, count in types.most_common():
            self.types_list.addItem(f"{t}: {count}")
        
        # Популярные ключи
        popular = self.key_repo.get_most_used(10)
        self.popular_list.clear()
        for key in popular:
            key_str = key.key if hasattr(key, 'key') else key
            count = key.usage_count if hasattr(key, 'usage_count') else 0
            self.popular_list.addItem(f"{key_str} - использован {count} раз")
    
    def find_zero_keys(self):
        keys = self.key_repo.get_all()
        zero_keys = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            if all(c == '0' or c == 'F' for c in key_str):
                zero_keys.append(key_str)
        
        self.display_weak_results(zero_keys, "Нулевые ключи")
    
    def find_repeating_keys(self):
        keys = self.key_repo.get_all()
        repeating = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            if len(set(key_str[i:i+2] for i in range(0, len(key_str), 2))) == 1:
                repeating.append(key_str)
        
        self.display_weak_results(repeating, "Повторяющиеся байты")
    
    def find_incremental_keys(self):
        keys = self.key_repo.get_all()
        incremental = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            try:
                value = int(key_str, 16)
                if value < 0xFFFFFFFF:
                    incremental.append(f"{key_str} ({value})")
            except:
                pass
        
        self.display_weak_results(incremental, "Инкрементные ключи")
    
    def find_default_keys(self):
        default_keys = [
            "FFFFFFFFFFFF", "000000000000", "A0A1A2A3A4A5", "D3F7D3F7D3F7",
            "A0B0C0D0E0F0", "1A2B3C4D5E6F", "112233445566", "123456789ABC"
        ]
        
        keys = self.key_repo.get_all()
        found = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            if key_str in default_keys:
                found.append(key_str)
        
        self.display_weak_results(found, "Стандартные ключи")
    
    def display_weak_results(self, keys: List[str], title: str):
        self.weak_results.clear()
        for key in keys:
            self.weak_results.addItem(key)
        QMessageBox.information(self, "Анализ", f"Найдено {len(keys)} {title}")
    
    def search_pattern(self):
        pattern = self.pattern_input.text().upper()
        if not pattern:
            return
        
        keys = self.key_repo.get_all()
        results = []
        
        for key in keys:
            key_str = key.key if hasattr(key, 'key') else key
            if pattern in key_str or (hasattr(key, 'tags') and key.tags and pattern in key.tags):
                results.append(key_str)
        
        self.search_results.clear()
        for key in results[:500]:
            self.search_results.addItem(key)
        
        QMessageBox.information(self, "Поиск", f"Найдено {len(results)} ключей")
    
    def compute_entropy(self, data: str) -> float:
        if not data:
            return 0
        
        frequencies = Counter(data)
        length = len(data)
        entropy = 0
        
        for freq in frequencies.values():
            p = freq / length
            entropy -= p * math.log2(p)
        
        return entropy
    
    def copy_key(self, item):
        key = item.text()
        if ' ' in key:
            key = key.split()[0]
        clipboard = QApplication.clipboard()
        clipboard.setText(key)
        QToolTip.showText(QCursor.pos(), f"Скопировано: {key}", msec=1500)