# gui/hf/hf_panel.py
"""
Главная панель высокочастотного модуля
"""

from PySide6.QtWidgets import *

from gui.hf.mifare.mifare_panel import MifarePanel
from gui.hf.ultralight.ultralight_panel import UltralightPanel
from gui.hf.desfire.desfire_panel import DESFirePanel
from gui.hf.iclass.iclass_panel import iClassPanel
from gui.hf.iso15693.iso15693_panel import ISO15693Panel
from gui.hf.iso14443.iso14443_panel import ISO14443Panel
from gui.hf.legic.legic_panel import LegicPanel
from gui.hf.felica.felica_panel import FelicaPanel


class HFPanel(QWidget):
    """Главная панель HF модуля"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Заголовок
        header = QLabel("🔼 ВЫСОКИЕ ЧАСТОТЫ (13.56 MHz)")
        header.setStyleSheet("""
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #3c3c3c;
            border-radius: 5px;
        """)
        layout.addWidget(header)
        
        # Вкладки для разных HF протоколов
        tabs = QTabWidget()
        tabs.setTabPosition(QTabWidget.TabPosition.North)
        tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #555;
                border-radius: 5px;
            }
            QTabBar::tab {
                padding: 8px 15px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #4CAF50;
            }
        """)
        
        # Добавляем все подпанели
        tabs.addTab(MifarePanel(self.pm3), "💳 MIFARE CLASSIC")
        tabs.addTab(UltralightPanel(self.pm3), "🏷️ MIFARE ULTRALIGHT/NTAG")
        tabs.addTab(DESFirePanel(self.pm3), "🔐 MIFARE DESFIRE")
        tabs.addTab(iClassPanel(self.pm3), "📇 iCLASS")
        tabs.addTab(ISO15693Panel(self.pm3), "📖 ISO15693")
        tabs.addTab(ISO14443Panel(self.pm3), "🔄 ISO14443-4")
        tabs.addTab(LegicPanel(self.pm3), "🏢 LEGIC")
        tabs.addTab(FelicaPanel(self.pm3), "🇯🇵 FeliCa")
        
        layout.addWidget(tabs)
        self.setLayout(layout)