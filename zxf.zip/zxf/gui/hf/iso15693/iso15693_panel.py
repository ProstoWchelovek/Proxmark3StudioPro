# gui/hf/iso15693/iso15693_panel.py
"""
Панель для работы с ISO15693 картами (ICODE SLIX и др.)
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class ISO15693Panel(QWidget):
    """Панель ISO15693"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("Информация ISO15693")
        info_layout = QFormLayout()
        
        self.uid_label = QLabel("-")
        self.dsfid_label = QLabel("-")
        
        read_btn = QPushButton("📖 Прочитать информацию")
        read_btn.clicked.connect(self.read_info)
        
        info_layout.addRow("UID:", self.uid_label)
        info_layout.addRow("DSFID:", self.dsfid_label)
        info_layout.addRow("", read_btn)
        info_group.setLayout(info_layout)
        
        # Блоки
        blocks_group = QGroupBox("Блоки памяти")
        blocks_layout = QVBoxLayout()
        
        self.blocks_table = QTableWidget()
        self.blocks_table.setColumnCount(3)
        self.blocks_table.setHorizontalHeaderLabels(["Блок", "Данные (HEX)", "ASCII"])
        
        read_blocks_btn = QPushButton("📚 Читать все блоки")
        read_blocks_btn.clicked.connect(self.read_blocks)
        
        blocks_layout.addWidget(self.blocks_table)
        blocks_layout.addWidget(read_blocks_btn)
        blocks_group.setLayout(blocks_layout)
        
        # Действия с блоком
        block_edit_group = QGroupBox("Работа с блоком")
        block_edit_layout = QFormLayout()
        
        self.block_spin = QSpinBox()
        self.block_spin.setRange(0, 255)
        
        self.block_data = QLineEdit()
        self.block_data.setPlaceholderText("Данные (HEX)")
        
        read_block_btn = QPushButton("📖 Прочитать блок")
        read_block_btn.clicked.connect(self.read_block)
        
        write_block_btn = QPushButton("✍️ Записать блок")
        write_block_btn.clicked.connect(self.write_block)
        
        lock_block_btn = QPushButton("🔒 Заблокировать блок")
        lock_block_btn.clicked.connect(self.lock_block)
        
        block_edit_layout.addRow("Номер блока:", self.block_spin)
        block_edit_layout.addRow("Данные:", self.block_data)
        block_edit_layout.addRow("", read_block_btn)
        block_edit_layout.addRow("", write_block_btn)
        block_edit_layout.addRow("", lock_block_btn)
        block_edit_group.setLayout(block_edit_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(150)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(blocks_group)
        layout.addWidget(block_edit_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_info(self):
        self.append_output("📖 Чтение ISO15693 карты...", "#4CAF50")
        output = self.pm3.run_command("hf 15 reader")
        self.append_output(output)
    
    def read_blocks(self):
        self.append_output("📚 Чтение всех блоков...", "#4CAF50")
        output = self.pm3.run_command("hf 15 dump")
        self.append_output(output)
    
    def read_block(self):
        block = self.block_spin.value()
        self.append_output(f"📖 Чтение блока {block}...", "#4CAF50")
        output = self.pm3.run_command(f"hf 15 readblock --block {block}")
        self.append_output(output)
    
    def write_block(self):
        block = self.block_spin.value()
        data = self.block_data.text()
        if data:
            self.append_output(f"✍️ Запись блока {block} = {data}...", "#4CAF50")
            output = self.pm3.run_command(f"hf 15 writeblock --block {block} --data {data}")
            self.append_output(output)
    
    def lock_block(self):
        block = self.block_spin.value()
        reply = QMessageBox.question(self, "Блокировка", f"Заблокировать блок {block}? (необратимо!)",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.append_output(f"🔒 Блокировка блока {block}...", "#4CAF50")
            output = self.pm3.run_command(f"hf 15 lockblock --block {block}")
            self.append_output(output)