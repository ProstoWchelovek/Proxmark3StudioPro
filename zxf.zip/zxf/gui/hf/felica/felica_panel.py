# gui/hf/felica/felica_panel.py
"""
Панель для работы с FeliCa картами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class FelicaPanel(QWidget):
    """Панель FeliCa"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        info_group = QGroupBox("FeliCa информация")
        info_layout = QFormLayout()
        
        self.idm_label = QLabel("-")
        self.pmm_label = QLabel("-")
        
        read_btn = QPushButton("📖 Прочитать FeliCa")
        read_btn.clicked.connect(self.read_card)
        
        info_layout.addRow("IDm:", self.idm_label)
        info_layout.addRow("PMm:", self.pmm_label)
        info_layout.addRow("", read_btn)
        info_group.setLayout(info_layout)
        
        # Действия
        actions_group = QGroupBox("Действия")
        actions_layout = QHBoxLayout()
        
        dump_btn = QPushButton("💾 Дамп FeliCa")
        dump_btn.clicked.connect(self.dump_card)
        
        sim_btn = QPushButton("🎭 Эмулировать FeliCa")
        sim_btn.clicked.connect(self.simulate_card)
        
        actions_layout.addWidget(dump_btn)
        actions_layout.addWidget(sim_btn)
        actions_group.setLayout(actions_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        layout.addWidget(info_group)
        layout.addWidget(actions_group)
        layout.addWidget(output_group)
        layout.addStretch()
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_card(self):
        self.append_output("📖 Чтение FeliCa карты...", "#4CAF50")
        output = self.pm3.run_command("hf felica reader")
        self.append_output(output)
        
        # Парсинг IDm и PMm
        import re
        idm_match = re.search(r'IDm:\s*([0-9A-F]+)', output, re.IGNORECASE)
        if idm_match:
            self.idm_label.setText(idm_match.group(1))
        
        pmm_match = re.search(r'PMm:\s*([0-9A-F]+)', output, re.IGNORECASE)
        if pmm_match:
            self.pmm_label.setText(pmm_match.group(1))
    
    def dump_card(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп FeliCa", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"💾 Дамп FeliCa в {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf felica dump --file {filename}")
            self.append_output(output)
    
    def simulate_card(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп для эмуляции", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"🎭 Эмуляция FeliCa из {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf felica sim --file {filename}")
            self.append_output(output)