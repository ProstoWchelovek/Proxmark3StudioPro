# gui/hf/iclass/__init__.py
"""
iClass модуль
"""

from gui.hf.iclass.iclass_panel import iClassPanel

__all__ = ['iClassPanel']