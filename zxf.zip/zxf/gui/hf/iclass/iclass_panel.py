# gui/hf/iclass/iclass_panel.py
"""
Панель для работы с iClass картами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class iClassPanel(QWidget):
    """Панель iClass"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("Информация iClass")
        info_layout = QFormLayout()
        
        self.csn_label = QLabel("-")
        self.config_label = QLabel("-")
        
        read_btn = QPushButton("📖 Прочитать iClass")
        read_btn.clicked.connect(self.read_card)
        
        info_layout.addRow("CSN:", self.csn_label)
        info_layout.addRow("Конфигурация:", self.config_label)
        info_layout.addRow("", read_btn)
        info_group.setLayout(info_layout)
        
        # Действия
        actions_group = QGroupBox("Действия")
        actions_layout = QGridLayout()
        
        dump_btn = QPushButton("💾 Дамп iClass")
        dump_btn.clicked.connect(self.dump_card)
        
        sim_btn = QPushButton("🎭 Эмулировать iClass")
        sim_btn.clicked.connect(self.simulate_card)
        
        clone_btn = QPushButton("📝 Клонировать iClass")
        clone_btn.clicked.connect(self.clone_card)
        
        actions_layout.addWidget(dump_btn, 0, 0)
        actions_layout.addWidget(sim_btn, 0, 1)
        actions_layout.addWidget(clone_btn, 1, 0, 1, 2)
        actions_group.setLayout(actions_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        layout.addWidget(info_group)
        layout.addWidget(actions_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_card(self):
        self.append_output("📖 Чтение iClass карты...", "#4CAF50")
        output = self.pm3.run_command("hf iclass read")
        self.append_output(output)
    
    def dump_card(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп iClass", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"💾 Дамп iClass в {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass dump --file {filename}")
            self.append_output(output)
    
    def simulate_card(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп для эмуляции", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"🎭 Эмуляция iClass из {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass sim --file {filename}")
            self.append_output(output)
    
    def clone_card(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп для клонирования", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"📝 Клонирование iClass из {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass clone --file {filename}")
            self.append_output(output)