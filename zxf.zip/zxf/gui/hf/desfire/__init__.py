# gui/hf/desfire/__init__.py
"""
Mifare DESFire модуль
"""

from gui.hf.desfire.desfire_panel import DESFirePanel

__all__ = ['DESFirePanel']