# gui/hf/desfire/desfire_panel.py
"""
Панель для работы с Mifare DESFire картами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class DESFirePanel(QWidget):
    """Панель DESFire"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация о карте
        info_group = QGroupBox("Информация DESFire")
        info_layout = QFormLayout()
        
        self.uid_label = QLabel("-")
        self.version_label = QLabel("-")
        self.memory_label = QLabel("-")
        self.apps_label = QLabel("-")
        
        read_btn = QPushButton("📖 Прочитать информацию")
        read_btn.clicked.connect(self.read_info)
        
        info_layout.addRow("UID:", self.uid_label)
        info_layout.addRow("Версия:", self.version_label)
        info_layout.addRow("Память:", self.memory_label)
        info_layout.addRow("Приложения:", self.apps_label)
        info_layout.addRow("", read_btn)
        info_group.setLayout(info_layout)
        
        # Управление приложениями
        app_group = QGroupBox("Приложения")
        app_layout = QVBoxLayout()
        
        self.app_list = QListWidget()
        
        btn_list = QPushButton("📋 Список приложений")
        btn_list.clicked.connect(self.list_apps)
        
        btn_create = QPushButton("➕ Создать приложение")
        btn_create.clicked.connect(self.create_app)
        
        btn_delete = QPushButton("🗑️ Удалить приложение")
        btn_delete.clicked.connect(self.delete_app)
        
        btn_select = QPushButton("🎯 Выбрать приложение")
        btn_select.clicked.connect(self.select_app)
        
        app_layout.addWidget(self.app_list)
        app_layout.addWidget(btn_list)
        app_layout.addWidget(btn_create)
        app_layout.addWidget(btn_delete)
        app_layout.addWidget(btn_select)
        app_group.setLayout(app_layout)
        
        # Файлы в приложении
        files_group = QGroupBox("Файлы")
        files_layout = QVBoxLayout()
        
        self.files_list = QListWidget()
        
        btn_list_files = QPushButton("📋 Список файлов")
        btn_list_files.clicked.connect(self.list_files)
        
        files_layout.addWidget(self.files_list)
        files_layout.addWidget(btn_list_files)
        files_group.setLayout(files_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(150)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(app_group)
        layout.addWidget(files_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_info(self):
        self.append_output("📖 Чтение информации DESFire...", "#4CAF50")
        output = self.pm3.run_command("hf desfire info")
        self.append_output(output)
    
    def list_apps(self):
        self.append_output("📋 Получение списка приложений...", "#4CAF50")
        output = self.pm3.run_command("hf desfire apps")
        self.append_output(output)
        self.app_list.clear()
        self.app_list.addItem("000000 (Master Application)")
    
    def create_app(self):
        app_id, ok = QInputDialog.getText(self, "Создание приложения", "Введите ID приложения (6 HEX):")
        if ok and app_id:
            self.append_output(f"➕ Создание приложения {app_id}...", "#4CAF50")
            output = self.pm3.run_command(f"hf desfire create_app --aid {app_id}")
            self.append_output(output)
    
    def delete_app(self):
        current = self.app_list.currentItem()
        if current:
            reply = QMessageBox.question(self, "Удаление", f"Удалить приложение {current.text()}?",
                                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                self.append_output(f"🗑️ Удаление приложения...", "#4CAF50")
    
    def select_app(self):
        current = self.app_list.currentItem()
        if current:
            self.append_output(f"🎯 Выбрано приложение {current.text()}", "#4CAF50")
    
    def list_files(self):
        self.append_output("📋 Получение списка файлов...", "#4CAF50")
        output = self.pm3.run_command("hf desfire files")
        self.append_output(output)