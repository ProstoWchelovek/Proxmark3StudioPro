# gui/hf/__init__.py
"""
Высокочастотный модуль (13.56 MHz)
"""

from gui.hf.hf_panel import HFPanel
from gui.hf.mifare.mifare_panel import MifarePanel
from gui.hf.ultralight.ultralight_panel import UltralightPanel
from gui.hf.desfire.desfire_panel import DESFirePanel
from gui.hf.iclass.iclass_panel import iClassPanel
from gui.hf.iso15693.iso15693_panel import ISO15693Panel
from gui.hf.iso14443.iso14443_panel import ISO14443Panel
from gui.hf.legic.legic_panel import LegicPanel
from gui.hf.felica.felica_panel import FelicaPanel

__all__ = [
    'HFPanel',
    'MifarePanel',
    'UltralightPanel',
    'DESFirePanel',
    'iClassPanel',
    'ISO15693Panel',
    'ISO14443Panel',
    'LegicPanel',
    'FelicaPanel'
]