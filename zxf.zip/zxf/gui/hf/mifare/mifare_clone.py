# gui/hf/mifare/mifare_clone.py
"""
Диалог для клонирования Mifare карты
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class MifareCloneDialog(QDialog):
    """Диалог клонирования Mifare карты"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Клонирование Mifare карты")
        self.setModal(True)
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Источник
        source_group = QGroupBox("Карта-источник")
        source_layout = QFormLayout()
        
        self.source_type = QComboBox()
        self.source_type.addItems(["Физическая карта", "Файл дампа"])
        self.source_type.currentIndexChanged.connect(self.on_source_type_changed)
        
        self.source_file = QLineEdit()
        self.source_file.setPlaceholderText("Выберите файл дампа...")
        self.source_file.setEnabled(False)
        
        btn_source_browse = QPushButton("Обзор...")
        btn_source_browse.clicked.connect(lambda: self.browse_file(self.source_file))
        btn_source_browse.setEnabled(False)
        
        source_file_layout = QHBoxLayout()
        source_file_layout.addWidget(self.source_file)
        source_file_layout.addWidget(btn_source_browse)
        
        source_layout.addRow("Тип:", self.source_type)
        source_layout.addRow("Файл:", source_file_layout)
        source_group.setLayout(source_layout)
        
        # Цель
        target_group = QGroupBox("Карта-цель")
        target_layout = QFormLayout()
        
        self.target_uid = QLineEdit()
        self.target_uid.setPlaceholderText("Новый UID (оставьте пустым для копирования)")
        
        self.target_magic = QCheckBox("Magic карта (поддерживает смену UID)")
        self.target_magic.setChecked(True)
        
        target_layout.addRow("Новый UID:", self.target_uid)
        target_layout.addRow("", self.target_magic)
        target_group.setLayout(target_layout)
        
        # Опции
        options_group = QGroupBox("Опции")
        options_layout = QVBoxLayout()
        
        self.clone_keys = QCheckBox("Клонировать ключи")
        self.clone_keys.setChecked(True)
        
        self.clone_data = QCheckBox("Клонировать данные")
        self.clone_data.setChecked(True)
        
        self.verify_after = QCheckBox("Проверить после клонирования")
        self.verify_after.setChecked(True)
        
        options_layout.addWidget(self.clone_keys)
        options_layout.addWidget(self.clone_data)
        options_layout.addWidget(self.verify_after)
        options_group.setLayout(options_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        # Кнопки
        btn_start = QPushButton("📝 НАЧАТЬ КЛОНИРОВАНИЕ")
        btn_start.clicked.connect(self.start_clone)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_start)
        button_layout.addWidget(btn_cancel)
        
        # Лог
        log_group = QGroupBox("Лог")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        self.log_text.setMaximumHeight(200)
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        layout.addWidget(source_group)
        layout.addWidget(target_group)
        layout.addWidget(options_group)
        layout.addWidget(self.progress_bar)
        layout.addLayout(button_layout)
        layout.addWidget(log_group)
    
    def on_source_type_changed(self, index):
        is_file = index == 1
        self.source_file.setEnabled(is_file)
        self.sender().findChild(QPushButton, "Обзор...").setEnabled(is_file)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            line_edit.setText(filename)
    
    def append_log(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.log_text.append(formatted)
        QApplication.processEvents()
    
    def start_clone(self):
        source_is_file = self.source_type.currentIndex() == 1
        source_file = self.source_file.text() if source_is_file else None
        new_uid = self.target_uid.text().strip()
        
        if source_is_file and not source_file:
            QMessageBox.warning(self, "Ошибка", "Выберите файл дампа-источника")
            return
        
        self.append_log(f"📝 Начало клонирования...", "#4CAF50")
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(10)
        
        # Запуск в потоке
        self.clone_thread = CloneThread(self.pm3, source_is_file, source_file, new_uid, 
                                        self.clone_keys.isChecked(), self.clone_data.isChecked(),
                                        self.verify_after.isChecked(), self.target_magic.isChecked())
        self.clone_thread.progress.connect(self.progress_bar.setValue)
        self.clone_thread.log.connect(self.append_log)
        self.clone_thread.finished.connect(self.on_clone_finished)
        self.clone_thread.start()
    
    def on_clone_finished(self, success):
        self.progress_bar.setVisible(False)
        if success:
            self.append_log(f"✅ Клонирование завершено успешно!", "#4CAF50")
            QMessageBox.information(self, "Успех", "Карта успешно клонирована")
            self.accept()
        else:
            self.append_log(f"❌ Ошибка при клонировании", "#FF5555")
            QMessageBox.warning(self, "Ошибка", "Не удалось клонировать карту")


class CloneThread(QThread):
    """Поток для клонирования"""
    
    progress = Signal(int)
    log = Signal(str)
    finished = Signal(bool)
    
    def __init__(self, pm3, source_is_file, source_file, new_uid, clone_keys, clone_data, verify, magic):
        super().__init__()
        self.pm3 = pm3
        self.source_is_file = source_is_file
        self.source_file = source_file
        self.new_uid = new_uid
        self.clone_keys = clone_keys
        self.clone_data = clone_data
        self.verify = verify
        self.magic = magic
    
    def run(self):
        try:
            self.log.emit("Подготовка к клонированию...")
            self.progress.emit(20)
            
            if self.new_uid and self.magic:
                self.log.emit(f"Установка нового UID: {self.new_uid}")
                self.pm3.run_command(f"hf mf csetuid --uid {self.new_uid}")
            
            if self.source_is_file:
                cmd = f"hf mf restore --file {self.source_file}"
                if not self.clone_keys:
                    cmd += " --no-keys"
                if not self.clone_data:
                    cmd += " --no-data"
            else:
                cmd = "hf mf dump --clone"
            
            self.log.emit(f"Выполнение: {cmd}")
            self.progress.emit(40)
            
            output = self.pm3.run_command(cmd)
            self.log.emit(output)
            
            self.progress.emit(80)
            
            if self.verify:
                self.log.emit("Проверка клонирования...")
                verify_output = self.pm3.run_command("hf 14a reader")
                self.log.emit(verify_output)
            
            self.progress.emit(100)
            self.finished.emit(True)
            
        except Exception as e:
            self.log.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False)