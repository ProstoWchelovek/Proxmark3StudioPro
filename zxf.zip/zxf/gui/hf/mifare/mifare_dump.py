# gui/hf/mifare/mifare_dump.py
"""
Диалог для создания дампа Mifare карты
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os


class MifareDumpDialog(QDialog):
    """Диалог создания дампа Mifare карты"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Создание дампа Mifare карты")
        self.setModal(True)
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Параметры дампа
        params_group = QGroupBox("Параметры дампа")
        params_layout = QFormLayout()
        
        self.filename_edit = QLineEdit()
        self.filename_edit.setPlaceholderText("dump_YYYYMMDD_HHMMSS")
        
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(self.browse_file)
        
        file_layout = QHBoxLayout()
        file_layout.addWidget(self.filename_edit)
        file_layout.addWidget(btn_browse)
        
        self.card_type = QComboBox()
        self.card_type.addItems(["Mifare Classic 1K", "Mifare Classic 4K", "Автоопределение"])
        
        self.use_keys = QCheckBox("Использовать сохранённые ключи")
        self.use_keys.setChecked(True)
        
        self.full_dump = QCheckBox("Полный дамп (включая неизвестные сектора)")
        self.full_dump.setChecked(False)
        
        params_layout.addRow("Файл дампа:", file_layout)
        params_layout.addRow("Тип карты:", self.card_type)
        params_layout.addRow("", self.use_keys)
        params_layout.addRow("", self.full_dump)
        params_group.setLayout(params_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        # Кнопки
        btn_start = QPushButton("💾 НАЧАТЬ ДАМП")
        btn_start.clicked.connect(self.start_dump)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_start)
        button_layout.addWidget(btn_cancel)
        
        # Лог
        log_group = QGroupBox("Лог")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        self.log_text.setMaximumHeight(150)
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        layout.addWidget(params_group)
        layout.addWidget(self.progress_bar)
        layout.addLayout(button_layout)
        layout.addWidget(log_group)
    
    def browse_file(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп", "", "Dump files (*.dump);;Binary files (*.bin)")
        if filename:
            self.filename_edit.setText(filename)
    
    def append_log(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.log_text.append(formatted)
        QApplication.processEvents()
    
    def start_dump(self):
        filename = self.filename_edit.text()
        if not filename:
            QMessageBox.warning(self, "Ошибка", "Укажите имя файла для сохранения дампа")
            return
        
        card_type = self.card_type.currentText()
        use_keys = self.use_keys.isChecked()
        full_dump = self.full_dump.isChecked()
        
        self.append_log(f"📖 Начало дампа карты...", "#4CAF50")
        self.append_log(f"Файл: {filename}")
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(10)
        
        # Запуск в потоке
        self.dump_thread = DumpThread(self.pm3, filename, card_type, use_keys, full_dump)
        self.dump_thread.progress.connect(self.progress_bar.setValue)
        self.dump_thread.log.connect(self.append_log)
        self.dump_thread.finished.connect(self.on_dump_finished)
        self.dump_thread.start()
    
    def on_dump_finished(self, success, filename):
        self.progress_bar.setVisible(False)
        if success:
            self.append_log(f"✅ Дамп успешно сохранён в {filename}", "#4CAF50")
            QMessageBox.information(self, "Успех", f"Дамп сохранён в {filename}")
            self.accept()
        else:
            self.append_log(f"❌ Ошибка при создании дампа", "#FF5555")
            QMessageBox.warning(self, "Ошибка", "Не удалось создать дамп")


class DumpThread(QThread):
    """Поток для создания дампа"""
    
    progress = Signal(int)
    log = Signal(str)
    finished = Signal(bool, str)
    
    def __init__(self, pm3, filename, card_type, use_keys, full_dump):
        super().__init__()
        self.pm3 = pm3
        self.filename = filename
        self.card_type = card_type
        self.use_keys = use_keys
        self.full_dump = full_dump
    
    def run(self):
        try:
            self.log.emit("Определение карты...")
            self.progress.emit(20)
            
            if "1K" in self.card_type:
                cmd = "hf mf dump --1k"
            elif "4K" in self.card_type:
                cmd = "hf mf dump --4k"
            else:
                cmd = "hf mf dump"
            
            cmd += f" --file {self.filename}"
            
            if not self.use_keys:
                cmd += " --no-keys"
            if self.full_dump:
                cmd += " --full"
            
            self.log.emit(f"Выполнение: {cmd}")
            self.progress.emit(30)
            
            output = self.pm3.run_command(cmd)
            self.log.emit(output)
            
            self.progress.emit(100)
            self.finished.emit(True, self.filename)
            
        except Exception as e:
            self.log.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False, "")