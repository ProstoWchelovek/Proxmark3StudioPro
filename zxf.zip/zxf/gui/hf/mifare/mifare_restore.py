# gui/hf/mifare/mifare_restore.py
"""
Диалог для восстановления дампа на Mifare карту
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os


class MifareRestoreDialog(QDialog):
    """Диалог восстановления дампа на карту"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Восстановление дампа на карту")
        self.setModal(True)
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Параметры восстановления
        params_group = QGroupBox("Параметры восстановления")
        params_layout = QFormLayout()
        
        self.filename_edit = QLineEdit()
        self.filename_edit.setPlaceholderText("Выберите файл дампа...")
        
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(self.browse_file)
        
        file_layout = QHBoxLayout()
        file_layout.addWidget(self.filename_edit)
        file_layout.addWidget(btn_browse)
        
        self.verify_check = QCheckBox("Проверить после записи")
        self.verify_check.setChecked(True)
        
        self.backup_check = QCheckBox("Создать резервную копию текущей карты")
        self.backup_check.setChecked(True)
        
        params_layout.addRow("Файл дампа:", file_layout)
        params_layout.addRow("", self.verify_check)
        params_layout.addRow("", self.backup_check)
        params_group.setLayout(params_layout)
        
        # Предпросмотр дампа
        preview_group = QGroupBox("Предпросмотр дампа")
        preview_layout = QVBoxLayout()
        
        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setFont(QFont("Courier New", 10))
        self.preview_text.setMaximumHeight(150)
        
        preview_layout.addWidget(self.preview_text)
        preview_group.setLayout(preview_layout)
        
        # Предупреждение
        warning_label = QLabel("⚠️ ВНИМАНИЕ: Восстановление перезапишет данные на карте!")
        warning_label.setStyleSheet("color: #FFC107; font-weight: bold;")
        
        # Прогресс
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        # Кнопки
        btn_start = QPushButton("🔄 НАЧАТЬ ВОССТАНОВЛЕНИЕ")
        btn_start.clicked.connect(self.start_restore)
        btn_start.setStyleSheet("background-color: #f44336; padding: 10px; font-weight: bold;")
        
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_start)
        button_layout.addWidget(btn_cancel)
        
        # Лог
        log_group = QGroupBox("Лог")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        self.log_text.setMaximumHeight(150)
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        layout.addWidget(params_group)
        layout.addWidget(preview_group)
        layout.addWidget(warning_label)
        layout.addWidget(self.progress_bar)
        layout.addLayout(button_layout)
        layout.addWidget(log_group)
    
    def browse_file(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump);;Binary files (*.bin)")
        if filename:
            self.filename_edit.setText(filename)
            self.load_preview(filename)
    
    def load_preview(self, filename):
        """Загрузка предпросмотра дампа"""
        try:
            size = os.path.getsize(filename)
            self.preview_text.clear()
            self.preview_text.append(f"Файл: {os.path.basename(filename)}")
            self.preview_text.append(f"Размер: {size} байт")
            
            if size == 1024:
                self.preview_text.append("Тип: Mifare Classic 1K")
            elif size == 4096:
                self.preview_text.append("Тип: Mifare Classic 4K")
            else:
                self.preview_text.append("Тип: Неизвестный формат")
                
        except Exception as e:
            self.preview_text.append(f"Ошибка: {str(e)}")
    
    def append_log(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.log_text.append(formatted)
        QApplication.processEvents()
    
    def start_restore(self):
        filename = self.filename_edit.text()
        if not filename or not os.path.exists(filename):
            QMessageBox.warning(self, "Ошибка", "Выберите файл дампа")
            return
        
        reply = QMessageBox.question(self, "Подтверждение", 
            "Восстановление перезапишет данные на карте!\n"
            "Убедитесь, что карта поддерживает запись.\n\n"
            "Продолжить?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply != QMessageBox.StandardButton.Yes:
            return
        
        self.append_log(f"🔄 Начало восстановления дампа...", "#4CAF50")
        self.append_log(f"Файл: {filename}")
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(10)
        
        # Запуск в потоке
        self.restore_thread = RestoreThread(self.pm3, filename, self.verify_check.isChecked(), self.backup_check.isChecked())
        self.restore_thread.progress.connect(self.progress_bar.setValue)
        self.restore_thread.log.connect(self.append_log)
        self.restore_thread.finished.connect(self.on_restore_finished)
        self.restore_thread.start()
    
    def on_restore_finished(self, success):
        self.progress_bar.setVisible(False)
        if success:
            self.append_log(f"✅ Восстановление завершено успешно!", "#4CAF50")
            QMessageBox.information(self, "Успех", "Данные успешно восстановлены на карту")
            self.accept()
        else:
            self.append_log(f"❌ Ошибка при восстановлении", "#FF5555")
            QMessageBox.warning(self, "Ошибка", "Не удалось восстановить данные")


class RestoreThread(QThread):
    """Поток для восстановления дампа"""
    
    progress = Signal(int)
    log = Signal(str)
    finished = Signal(bool)
    
    def __init__(self, pm3, filename, verify, backup):
        super().__init__()
        self.pm3 = pm3
        self.filename = filename
        self.verify = verify
        self.backup = backup
    
    def run(self):
        try:
            self.log.emit("Подготовка к восстановлению...")
            self.progress.emit(20)
            
            if self.backup:
                backup_filename = self.filename.replace('.dump', '_backup.dump')
                self.log.emit(f"Создание резервной копии: {backup_filename}")
                self.pm3.run_command(f"hf mf dump --file {backup_filename}")
            
            cmd = f"hf mf restore --file {self.filename}"
            self.log.emit(f"Выполнение: {cmd}")
            self.progress.emit(40)
            
            output = self.pm3.run_command(cmd)
            self.log.emit(output)
            
            self.progress.emit(80)
            
            if self.verify:
                self.log.emit("Проверка восстановленных данных...")
                verify_output = self.pm3.run_command(f"hf mf dump --verify --file {self.filename}")
                self.log.emit(verify_output)
            
            self.progress.emit(100)
            self.finished.emit(True)
            
        except Exception as e:
            self.log.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False)