# gui/hf/mifare/mifare_emulation.py
"""
Диалог для эмуляции Mifare карты
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class MifareEmulationDialog(QDialog):
    """Диалог эмуляции Mifare карты"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.is_emulating = False
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Эмуляция Mifare карты")
        self.setModal(True)
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Источник данных
        source_group = QGroupBox("Источник данных для эмуляции")
        source_layout = QFormLayout()
        
        self.source_type = QComboBox()
        self.source_type.addItems(["Файл дампа", "Физическая карта (сначала прочитать)", "Вручную ввести UID"])
        self.source_type.currentIndexChanged.connect(self.on_source_type_changed)
        
        self.source_file = QLineEdit()
        self.source_file.setPlaceholderText("Выберите файл дампа...")
        self.source_file.setEnabled(True)
        
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(lambda: self.browse_file(self.source_file))
        
        source_file_layout = QHBoxLayout()
        source_file_layout.addWidget(self.source_file)
        source_file_layout.addWidget(btn_browse)
        
        self.custom_uid = QLineEdit()
        self.custom_uid.setPlaceholderText("FFFFFFFFFFFF")
        self.custom_uid.setMaxLength(12)
        self.custom_uid.setEnabled(False)
        
        source_layout.addRow("Тип:", self.source_type)
        source_layout.addRow("Файл:", source_file_layout)
        source_layout.addRow("UID:", self.custom_uid)
        source_group.setLayout(source_layout)
        
        # Параметры эмуляции
        params_group = QGroupBox("Параметры эмуляции")
        params_layout = QFormLayout()
        
        self.emulation_mode = QComboBox()
        self.emulation_mode.addItems(["Полная эмуляция", "Только UID", "Только данные"])
        
        self.repeat_spin = QSpinBox()
        self.repeat_spin.setRange(0, 9999)
        self.repeat_spin.setSpecialValueText("∞")
        self.repeat_spin.setValue(0)
        self.repeat_spin.setToolTip("0 = бесконечно")
        
        self.gap_spin = QSpinBox()
        self.gap_spin.setRange(0, 10000)
        self.gap_spin.setValue(1000)
        self.gap_spin.setSuffix(" мс")
        
        params_layout.addRow("Режим:", self.emulation_mode)
        params_layout.addRow("Повторы:", self.repeat_spin)
        params_layout.addRow("Интервал:", self.gap_spin)
        params_group.setLayout(params_layout)
        
        # Статус
        status_group = QGroupBox("Статус эмуляции")
        status_layout = QHBoxLayout()
        
        self.status_indicator = QLabel("🔴 Не активна")
        self.status_indicator.setStyleSheet("font-weight: bold;")
        
        self.stopwatch = QLabel("00:00:00")
        self.stopwatch.setStyleSheet("font-family: monospace; font-size: 14px;")
        
        status_layout.addWidget(self.status_indicator)
        status_layout.addStretch()
        status_layout.addWidget(self.stopwatch)
        status_group.setLayout(status_layout)
        
        # Кнопки
        btn_start = QPushButton("▶️ НАЧАТЬ ЭМУЛЯЦИЮ")
        btn_start.clicked.connect(self.start_emulation)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_emulation)
        btn_stop.setEnabled(False)
        btn_stop.setStyleSheet("background-color: #f44336; padding: 10px; font-weight: bold;")
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_start)
        button_layout.addWidget(btn_stop)
        
        # Лог
        log_group = QGroupBox("Лог")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        self.log_text.setMaximumHeight(150)
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        layout.addWidget(source_group)
        layout.addWidget(params_group)
        layout.addWidget(status_group)
        layout.addLayout(button_layout)
        layout.addWidget(log_group)
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.elapsed_seconds = 0
    
    def on_source_type_changed(self, index):
        is_file = index == 0
        is_custom = index == 2
        self.source_file.setEnabled(is_file)
        self.custom_uid.setEnabled(is_custom)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            line_edit.setText(filename)
    
    def append_log(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.log_text.append(formatted)
        QApplication.processEvents()
    
    def start_emulation(self):
        source_type = self.source_type.currentIndex()
        source_file = self.source_file.text() if source_type == 0 else None
        custom_uid = self.custom_uid.text().strip() if source_type == 2 else None
        mode = self.emulation_mode.currentText()
        repeat = self.repeat_spin.value()
        gap = self.gap_spin.value()
        
        if source_type == 0 and not source_file:
            QMessageBox.warning(self, "Ошибка", "Выберите файл дампа")
            return
        
        if source_type == 2 and not custom_uid:
            QMessageBox.warning(self, "Ошибка", "Введите UID для эмуляции")
            return
        
        self.append_log(f"▶️ Запуск эмуляции...", "#4CAF50")
        
        self.emulation_thread = EmulationThread(self.pm3, source_type, source_file, custom_uid, mode, repeat, gap)
        self.emulation_thread.log.connect(self.append_log)
        self.emulation_thread.started_signal.connect(self.on_emulation_started)
        self.emulation_thread.finished_signal.connect(self.on_emulation_finished)
        self.emulation_thread.start()
        
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def on_emulation_started(self):
        self.is_emulating = True
        self.status_indicator.setText("🟢 Активна")
        self.status_indicator.setStyleSheet("color: #4CAF50; font-weight: bold;")
        self.elapsed_seconds = 0
        self.timer.start(1000)
    
    def on_emulation_finished(self):
        self.is_emulating = False
        self.status_indicator.setText("🔴 Не активна")
        self.status_indicator.setStyleSheet("font-weight: bold;")
        self.timer.stop()
        self.stopwatch.setText("00:00:00")
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)
    
    def stop_emulation(self):
        if self.emulation_thread:
            self.emulation_thread.stop()
            self.append_log("⏹️ Эмуляция остановлена пользователем", "#FFC107")
    
    def update_timer(self):
        self.elapsed_seconds += 1
        hours = self.elapsed_seconds // 3600
        minutes = (self.elapsed_seconds % 3600) // 60
        seconds = self.elapsed_seconds % 60
        self.stopwatch.setText(f"{hours:02d}:{minutes:02d}:{seconds:02d}")


class EmulationThread(QThread):
    """Поток для эмуляции"""
    
    log = Signal(str)
    started_signal = Signal()
    finished_signal = Signal()
    
    def __init__(self, pm3, source_type, source_file, custom_uid, mode, repeat, gap):
        super().__init__()
        self.pm3 = pm3
        self.source_type = source_type
        self.source_file = source_file
        self.custom_uid = custom_uid
        self.mode = mode
        self.repeat = repeat
        self.gap = gap
        self.running = True
    
    def run(self):
        try:
            self.started_signal.emit()
            
            if self.source_type == 0:  # Файл дампа
                cmd = f"hf mf sim --file {self.source_file}"
            elif self.source_type == 1:  # Физическая карта
                cmd = "hf mf sim"
            else:  # Пользовательский UID
                cmd = f"hf mf sim --uid {self.custom_uid}"
            
            if "UID" in self.mode:
                cmd += " --uid-only"
            if "данные" in self.mode:
                cmd += " --data-only"
            
            if self.repeat > 0:
                cmd += f" --repeat {self.repeat}"
            if self.gap > 0:
                cmd += f" --gap {self.gap}"
            
            self.log.emit(f"Выполнение: {cmd}")
            
            output = self.pm3.run_command(cmd)
            if output:
                self.log.emit(output)
            
        except Exception as e:
            self.log.emit(f"Ошибка: {str(e)}")
        
        self.finished_signal.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")