# gui/hf/mifare/mifare_panel.py
"""
Панель для работы с Mifare Classic картами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class MifarePanel(QWidget):
    """Панель Mifare Classic"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Группа: Информация о карте
        info_group = QGroupBox("Информация о карте")
        info_layout = QFormLayout()
        
        self.uid_label = QLabel("Не определена")
        self.atqa_label = QLabel("Не определена")
        self.sak_label = QLabel("Не определена")
        self.type_label = QLabel("Не определена")
        self.size_label = QLabel("Не определена")
        
        self.read_info_btn = QPushButton("📖 Прочитать информацию (hf 14a reader)")
        self.read_info_btn.clicked.connect(self.read_card_info)
        
        info_layout.addRow("UID:", self.uid_label)
        info_layout.addRow("ATQA:", self.atqa_label)
        info_layout.addRow("SAK:", self.sak_label)
        info_layout.addRow("Тип:", self.type_label)
        info_layout.addRow("Размер:", self.size_label)
        info_layout.addRow("", self.read_info_btn)
        info_group.setLayout(info_layout)
        
        # Группа: Действия с картой
        actions_group = QGroupBox("Действия")
        actions_layout = QGridLayout()
        
        self.dump_btn = QPushButton("💾 СДЕЛАТЬ ДАМП")
        self.dump_btn.clicked.connect(self.dump_card)
        
        self.restore_btn = QPushButton("🔄 ВОССТАНОВИТЬ")
        self.restore_btn.clicked.connect(self.restore_card)
        
        self.clone_btn = QPushButton("📝 КЛОНИРОВАТЬ")
        self.clone_btn.clicked.connect(self.clone_card)
        
        self.simulate_btn = QPushButton("🎭 ЭМУЛИРОВАТЬ")
        self.simulate_btn.clicked.connect(self.simulate_card)
        
        self.write_uid_btn = QPushButton("✏️ ИЗМЕНИТЬ UID")
        self.write_uid_btn.clicked.connect(self.change_uid)
        
        actions_layout.addWidget(self.dump_btn, 0, 0)
        actions_layout.addWidget(self.restore_btn, 0, 1)
        actions_layout.addWidget(self.clone_btn, 1, 0)
        actions_layout.addWidget(self.simulate_btn, 1, 1)
        actions_layout.addWidget(self.write_uid_btn, 2, 0, 1, 2)
        actions_group.setLayout(actions_layout)
        
        # Группа: Атаки на ключи
        attacks_group = QGroupBox("Атаки на ключи")
        attacks_layout = QVBoxLayout()
        
        # Известный ключ
        known_layout = QHBoxLayout()
        self.known_key = QLineEdit()
        self.known_key.setPlaceholderText("FFFFFFFFFFFF")
        self.known_key.setMaxLength(12)
        
        self.known_sector = QSpinBox()
        self.known_sector.setRange(0, 39)
        self.known_sector.setValue(0)
        
        self.known_key_type = QComboBox()
        self.known_key_type.addItems(["Key A", "Key B"])
        
        known_layout.addWidget(QLabel("Известный ключ:"))
        known_layout.addWidget(self.known_key)
        known_layout.addWidget(QLabel("Сектор:"))
        known_layout.addWidget(self.known_sector)
        known_layout.addWidget(self.known_key_type)
        
        # Кнопки атак
        self.nested_btn = QPushButton("🎯 NESTED ATTACK")
        self.nested_btn.clicked.connect(self.nested_attack)
        
        self.hardnested_btn = QPushButton("⚡ HARDNESTED ATTACK")
        self.hardnested_btn.clicked.connect(self.hardnested_attack)
        
        self.darkside_btn = QPushButton("🌑 DARKSIDE ATTACK")
        self.darkside_btn.clicked.connect(self.darkside_attack)
        
        self.sniff_btn = QPushButton("👂 SNIFF (перехват)")
        self.sniff_btn.clicked.connect(self.sniff_attack)
        
        self.chk_btn = QPushButton("🔑 ПРОВЕРКА КЛЮЧЕЙ")
        self.chk_btn.clicked.connect(self.check_keys)
        
        attacks_layout.addLayout(known_layout)
        attacks_layout.addWidget(self.nested_btn)
        attacks_layout.addWidget(self.hardnested_btn)
        attacks_layout.addWidget(self.darkside_btn)
        attacks_layout.addWidget(self.sniff_btn)
        attacks_layout.addWidget(self.chk_btn)
        attacks_group.setLayout(attacks_layout)
        
        # Визуализация секторов
        sectors_group = QGroupBox("Секторы карты")
        sectors_layout = QVBoxLayout()
        
        self.sectors_table = QTableWidget()
        self.sectors_table.setColumnCount(4)
        self.sectors_table.setHorizontalHeaderLabels(["Сектор", "Key A", "Key B", "Статус"])
        self.sectors_table.horizontalHeader().setStretchLastSection(True)
        
        sectors_layout.addWidget(self.sectors_table)
        sectors_group.setLayout(sectors_layout)
        
        # Область вывода
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(actions_group)
        layout.addWidget(attacks_group)
        layout.addWidget(sectors_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        """Добавление текста в вывод"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_card_info(self):
        """Чтение информации о карте"""
        self.append_output("📖 Чтение информации о карте...", "#4CAF50")
        output = self.pm3.run_command("hf 14a reader")
        self.append_output(output)
        
        # Парсинг UID
        uid_match = re.search(r"UID:\s*([0-9A-F\s]+)", output, re.IGNORECASE)
        if uid_match:
            uid = uid_match.group(1).replace(" ", "")
            self.uid_label.setText(uid)
            self.append_output(f"✅ UID: {uid}", "#4CAF50")
        
        # Парсинг ATQA
        atqa_match = re.search(r"ATQA:\s*([0-9A-F]{4})", output, re.IGNORECASE)
        if atqa_match:
            self.atqa_label.setText(atqa_match.group(1))
        
        # Парсинг SAK
        sak_match = re.search(r"SAK:\s*([0-9A-F]{2})", output, re.IGNORECASE)
        if sak_match:
            sak = sak_match.group(1)
            self.sak_label.setText(sak)
            
            if sak == "08":
                self.type_label.setText("Mifare Classic 1K")
                self.size_label.setText("1024 байт (16 секторов)")
                self.sectors_table.setRowCount(16)
            elif sak == "18":
                self.type_label.setText("Mifare Classic 4K")
                self.size_label.setText("4096 байт (40 секторов)")
                self.sectors_table.setRowCount(40)
    
    def dump_card(self):
        """Создание дампа карты"""
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            self.append_output(f"💾 Создание дампа в {filename}...", "#4CAF50")
            
            # Запуск в потоке
            self.dump_thread = MifareDumpThread(self.pm3, filename)
            self.dump_thread.output.connect(self.append_output)
            self.dump_thread.finished.connect(lambda: self.append_output("✅ Дамп завершён", "#4CAF50"))
            self.dump_thread.start()
    
    def restore_card(self):
        """Восстановление карты из дампа"""
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            self.append_output(f"🔄 Восстановление карты из {filename}...", "#4CAF50")
            
            restore_thread = MifareRestoreThread(self.pm3, filename)
            restore_thread.output.connect(self.append_output)
            restore_thread.start()
    
    def clone_card(self):
        """Клонирование карты"""
        dialog = MifareCloneDialog(self.pm3, self)
        dialog.exec()
    
    def simulate_card(self):
        """Эмуляция карты"""
        dialog = MifareEmulationDialog(self.pm3, self)
        dialog.exec()
    
    def change_uid(self):
        """Изменение UID (требуется magic card)"""
        new_uid, ok = QInputDialog.getText(self, "Изменение UID", "Введите новый UID (HEX):")
        if ok and new_uid:
            self.append_output(f"✏️ Изменение UID на {new_uid}...", "#4CAF50")
            output = self.pm3.run_command(f"hf mf csetuid --uid {new_uid}")
            self.append_output(output)
    
    def nested_attack(self):
        """Запуск Nested атаки"""
        key = self.known_key.text()
        sector = self.known_sector.value()
        key_type = "A" if self.known_key_type.currentText() == "Key A" else "B"
        
        if len(key) != 12:
            QMessageBox.warning(self, "Ошибка", "Введите корректный ключ (12 HEX символов)")
            return
        
        self.append_output(f"🎯 Запуск Nested атаки с ключом {key} на секторе {sector}...", "#4CAF50")
        
        attack_thread = NestedAttackThread(self.pm3, key, sector, key_type)
        attack_thread.output.connect(self.append_output)
        attack_thread.sector_found.connect(self.on_sector_key_found)
        attack_thread.start()
    
    def hardnested_attack(self):
        """Запуск Hardnested атаки"""
        key = self.known_key.text()
        
        if len(key) != 12:
            QMessageBox.warning(self, "Ошибка", "Введите корректный ключ (12 HEX символов)")
            return
        
        self.append_output(f"⚡ Запуск Hardnested атаки с ключом {key}...", "#4CAF50")
        self.append_output("Это может занять несколько минут...")
        
        attack_thread = HardnestedAttackThread(self.pm3, key)
        attack_thread.output.connect(self.append_output)
        attack_thread.sector_found.connect(self.on_sector_key_found)
        attack_thread.start()
    
    def darkside_attack(self):
        """Запуск Darkside атаки"""
        self.append_output("🌑 Запуск Darkside атаки...", "#4CAF50")
        
        attack_thread = DarksideAttackThread(self.pm3)
        attack_thread.output.connect(self.append_output)
        attack_thread.start()
    
    def sniff_attack(self):
        """Перехват обмена"""
        self.append_output("👂 Начало перехвата... Поднесите карту к ридеру", "#4CAF50")
        
        sniff_thread = SniffAttackThread(self.pm3)
        sniff_thread.output.connect(self.append_output)
        sniff_thread.start()
    
    def check_keys(self):
        """Проверка ключей из словаря"""
        dict_file, _ = QFileDialog.getOpenFileName(self, "Выберите словарь ключей", "", "Dictionary files (*.dic *.txt)")
        if dict_file:
            self.append_output(f"🔑 Проверка ключей из {dict_file}...", "#4CAF50")
            
            chk_thread = CheckKeysThread(self.pm3, dict_file)
            chk_thread.output.connect(self.append_output)
            chk_thread.key_found.connect(self.on_sector_key_found)
            chk_thread.start()
    
    def on_sector_key_found(self, sector, key_a, key_b):
        """Обработка найденного ключа"""
        if sector >= self.sectors_table.rowCount():
            self.sectors_table.setRowCount(sector + 1)
        
        self.sectors_table.setItem(sector, 0, QTableWidgetItem(str(sector)))
        self.sectors_table.setItem(sector, 1, QTableWidgetItem(key_a[:12] if key_a else "?"))
        self.sectors_table.setItem(sector, 2, QTableWidgetItem(key_b[:12] if key_b else "?"))
        self.sectors_table.setItem(sector, 3, QTableWidgetItem("✅ Найден"))


class MifareDumpThread(QThread):
    """Поток для создания дампа Mifare"""
    
    output = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3, filename):
        super().__init__()
        self.pm3 = pm3
        self.filename = filename
    
    def run(self):
        try:
            output = self.pm3.run_command(f"hf mf dump --file {self.filename}")
            self.output.emit(output)
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        self.finished.emit()


class MifareRestoreThread(QThread):
    """Поток для восстановления дампа"""
    
    output = Signal(str)
    
    def __init__(self, pm3, filename):
        super().__init__()
        self.pm3 = pm3
        self.filename = filename
    
    def run(self):
        output = self.pm3.run_command(f"hf mf restore --file {self.filename}")
        self.output.emit(output)


class MifareCloneDialog(QDialog):
    """Диалог клонирования Mifare карты"""
    
    def __init__(self, pm3, parent=None):
        super().__init__(parent)
        self.pm3 = pm3
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Клонирование Mifare карты")
        self.setModal(True)
        layout = QFormLayout(self)
        
        self.source_file = QLineEdit()
        self.source_file.setPlaceholderText("Путь к исходному дампу")
        btn_source = QPushButton("Обзор...")
        btn_source.clicked.connect(lambda: self.browse_file(self.source_file))
        
        source_layout = QHBoxLayout()
        source_layout.addWidget(self.source_file)
        source_layout.addWidget(btn_source)
        
        self.target_uid = QLineEdit()
        self.target_uid.setPlaceholderText("Новый UID (опционально)")
        
        self.use_keys = QCheckBox("Использовать сохранённые ключи")
        
        layout.addRow("Исходный дамп:", source_layout)
        layout.addRow("Новый UID:", self.target_uid)
        layout.addRow("", self.use_keys)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.clone)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            line_edit.setText(filename)
    
    def clone(self):
        self.accept()


class MifareEmulationDialog(QDialog):
    """Диалог эмуляции Mifare карты"""
    
    def __init__(self, pm3, parent=None):
        super().__init__(parent)
        self.pm3 = pm3
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Эмуляция Mifare карты")
        self.setModal(True)
        layout = QFormLayout(self)
        
        self.dump_file = QLineEdit()
        self.dump_file.setPlaceholderText("Путь к дампу для эмуляции")
        btn_file = QPushButton("Обзор...")
        btn_file.clicked.connect(lambda: self.browse_file(self.dump_file))
        
        file_layout = QHBoxLayout()
        file_layout.addWidget(self.dump_file)
        file_layout.addWidget(btn_file)
        
        self.uid_edit = QLineEdit()
        self.uid_edit.setPlaceholderText("UID для эмуляции (опционально)")
        
        layout.addRow("Файл дампа:", file_layout)
        layout.addRow("UID:", self.uid_edit)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.emulate)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", "Dump files (*.dump *.bin)")
        if filename:
            line_edit.setText(filename)
    
    def emulate(self):
        self.accept()


class NestedAttackThread(QThread):
    """Поток для Nested атаки"""
    
    output = Signal(str)
    sector_found = Signal(int, str, str)
    
    def __init__(self, pm3, known_key, known_sector, known_key_type):
        super().__init__()
        self.pm3 = pm3
        self.known_key = known_key
        self.known_sector = known_sector
        self.known_key_type = known_key_type
    
    def run(self):
        cmd = f"hf mf nested 1 0 {self.known_key} {self.known_sector} {self.known_key_type} t"
        output = self.pm3.run_command(cmd)
        self.output.emit(output)
        
        # Парсим найденные ключи
        import re
        matches = re.findall(r'Sector\s+(\d+).*?Key A:\s*([0-9A-F]+).*?Key B:\s*([0-9A-F]+)', output, re.DOTALL)
        for match in matches:
            sector = int(match[0])
            key_a = match[1]
            key_b = match[2]
            self.sector_found.emit(sector, key_a, key_b)


class HardnestedAttackThread(QThread):
    """Поток для Hardnested атаки"""
    
    output = Signal(str)
    sector_found = Signal(int, str, str)
    
    def __init__(self, pm3, known_key):
        super().__init__()
        self.pm3 = pm3
        self.known_key = known_key
    
    def run(self):
        cmd = f"hf mf hardnested --key {self.known_key}"
        output = self.pm3.run_command(cmd)
        self.output.emit(output)


class DarksideAttackThread(QThread):
    """Поток для Darkside атаки"""
    
    output = Signal(str)
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
    
    def run(self):
        output = self.pm3.run_command("hf mf darkside")
        self.output.emit(output)


class SniffAttackThread(QThread):
    """Поток для перехвата"""
    
    output = Signal(str)
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
    
    def run(self):
        output = self.pm3.run_command("hf mf sniff")
        self.output.emit(output)


class CheckKeysThread(QThread):
    """Поток для проверки ключей"""
    
    output = Signal(str)
    key_found = Signal(int, str, str)
    
    def __init__(self, pm3, dict_file):
        super().__init__()
        self.pm3 = pm3
        self.dict_file = dict_file
    
    def run(self):
        cmd = f"hf mf chk --dict {self.dict_file}"
        output = self.pm3.run_command(cmd)
        self.output.emit(output)