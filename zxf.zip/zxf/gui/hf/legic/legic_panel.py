# gui/hf/legic/legic_panel.py
"""
Панель для работы с LEGIC картами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LegicPanel(QWidget):
    """Панель LEGIC"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        info_group = QGroupBox("LEGIC информация")
        info_layout = QFormLayout()
        
        self.csn_label = QLabel("-")
        self.memory_label = QLabel("-")
        
        read_btn = QPushButton("📖 Прочитать LEGIC")
        read_btn.clicked.connect(self.read_card)
        
        info_layout.addRow("CSN:", self.csn_label)
        info_layout.addRow("Память:", self.memory_label)
        info_layout.addRow("", read_btn)
        info_group.setLayout(info_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        layout.addWidget(info_group)
        layout.addWidget(output_group)
        layout.addStretch()
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_card(self):
        self.append_output("📖 Чтение LEGIC карты...", "#4CAF50")
        output = self.pm3.run_command("hf legic reader")
        self.append_output(output)