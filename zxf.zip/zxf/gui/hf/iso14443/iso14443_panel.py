# gui/hf/iso14443/iso14443_panel.py
"""
Панель для работы с ISO14443-4 картами (APDU команды)
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class ISO14443Panel(QWidget):
    """Панель ISO14443-4 APDU"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Редактор APDU
        apdu_group = QGroupBox("APDU команда")
        apdu_layout = QVBoxLayout()
        
        self.apdu_input = QTextEdit()
        self.apdu_input.setPlaceholderText("Введите APDU команду в HEX...\nПример: 00A4040008A000000003000000")
        self.apdu_input.setMaximumHeight(80)
        self.apdu_input.setFont(QFont("Courier New", 11))
        
        send_btn = QPushButton("📤 Отправить APDU")
        send_btn.clicked.connect(self.send_apdu)
        send_btn.setStyleSheet("background-color: #4CAF50; padding: 8px;")
        
        apdu_layout.addWidget(self.apdu_input)
        apdu_layout.addWidget(send_btn)
        apdu_group.setLayout(apdu_layout)
        
        # Параметрический редактор
        param_group = QGroupBox("Параметрический редактор APDU")
        param_layout = QFormLayout()
        
        self.cla_edit = QLineEdit("00")
        self.ins_edit = QLineEdit("A4")
        self.p1_edit = QLineEdit("04")
        self.p2_edit = QLineEdit("00")
        self.data_edit = QLineEdit("A000000003000000")
        self.le_edit = QLineEdit("00")
        
        build_btn = QPushButton("🏗️ Собрать APDU")
        build_btn.clicked.connect(self.build_apdu)
        
        param_layout.addRow("CLA:", self.cla_edit)
        param_layout.addRow("INS:", self.ins_edit)
        param_layout.addRow("P1:", self.p1_edit)
        param_layout.addRow("P2:", self.p2_edit)
        param_layout.addRow("Data:", self.data_edit)
        param_layout.addRow("Le:", self.le_edit)
        param_layout.addRow("", build_btn)
        param_group.setLayout(param_layout)
        
        # Предустановленные команды
        preset_group = QGroupBox("Предустановленные команды")
        preset_layout = QGridLayout()
        
        commands = [
            ("SELECT MF", "00A4040008A000000003000000"),
            ("GET DATA", "80CA006600"),
            ("GET CHALLENGE", "0084000008"),
            ("VERIFY PIN", "0020000004FFFFFFFF"),
            ("READ BINARY", "00B0000000"),
            ("GET RESPONSE", "00C0000000"),
        ]
        
        for i, (name, cmd) in enumerate(commands):
            row = i // 3
            col = i % 3
            btn = QPushButton(name)
            btn.clicked.connect(lambda checked, c=cmd: self.apdu_input.setText(c))
            preset_layout.addWidget(btn, row, col)
        
        preset_group.setLayout(preset_layout)
        
        # Ответ
        response_group = QGroupBox("Ответ")
        response_layout = QVBoxLayout()
        
        self.response_text = QTextEdit()
        self.response_text.setReadOnly(True)
        self.response_text.setFont(QFont("Courier New", 10))
        self.response_text.setMaximumHeight(150)
        
        response_layout.addWidget(self.response_text)
        response_group.setLayout(response_layout)
        
        # Сборка
        layout.addWidget(apdu_group)
        layout.addWidget(param_group)
        layout.addWidget(preset_group)
        layout.addWidget(response_group)
        
        self.setLayout(layout)
    
    def append_response(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.response_text.append(formatted)
        QApplication.processEvents()
    
    def send_apdu(self):
        apdu = self.apdu_input.toPlainText().replace(" ", "").replace("\n", "")
        if not apdu:
            QMessageBox.warning(self, "Ошибка", "Введите APDU команду")
            return
        
        self.append_response(f"📤 Отправка APDU: {apdu}", "#4CAF50")
        output = self.pm3.run_command(f"hf 14a apdu --apdu {apdu}")
        self.append_response(output)
    
    def build_apdu(self):
        cla = self.cla_edit.text()
        ins = self.ins_edit.text()
        p1 = self.p1_edit.text()
        p2 = self.p2_edit.text()
        data = self.data_edit.text()
        le = self.le_edit.text()
        
        apdu = f"{cla}{ins}{p1}{p2}"
        
        if data:
            lc = f"{len(data)//2:02X}"
            apdu += lc + data
        
        if le and le != "00":
            apdu += le
        
        self.apdu_input.setText(apdu)
        self.append_response(f"🏗️ Собрана APDU: {apdu}", "#888888")