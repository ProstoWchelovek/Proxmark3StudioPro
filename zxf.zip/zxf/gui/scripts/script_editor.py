# gui/scripts/script_editor.py
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

class ScriptEditor(QPlainTextEdit):
    """Расширенный редактор скриптов с подсветкой синтаксиса"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont("Courier New", 11))
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(' '))
        
        # Подсветка
        self.highlighter = LuaHighlighter(self.document())
        
        # Номера строк
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.update_line_number_area_width()
        
        # Автодополнение
        self.completer = None
        self.init_completer()
    
    def init_completer(self):
        """Инициализация автодополнения"""
        self.completer = QCompleter()
        self.completer.setWidget(self)
        self.completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        
        # Словарь ключевых слов Lua
        lua_keywords = [
            "and", "break", "do", "else", "elseif", "end", "false", "for", 
            "function", "if", "in", "local", "nil", "not", "or", "repeat", 
            "return", "then", "true", "until", "while",
            "pm3", "print", "sleep", "command"
        ]
        
        self.completer_model = QStringListModel(lua_keywords)
        self.completer.setModel(self.completer_model)
    
    def line_number_area_width(self):
        """Ширина области номеров строк"""
        digits = len(str(self.blockCount()))
        return 10 + self.fontMetrics().horizontalAdvance('9') * digits
    
    def update_line_number_area_width(self):
        """Обновление ширины области номеров"""
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)
    
    def update_line_number_area(self, rect, dy):
        """Обновление области номеров"""
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width()
    
    def resizeEvent(self, event):
        """Обработка изменения размера"""
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height()))
    
    def line_number_area_paint_event(self, event):
        """Отрисовка номеров строк"""
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor(45, 45, 45))
        
        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(QColor(150, 150, 150))
                painter.drawText(0, int(top), self.line_number_area.width() - 2, self.fontMetrics().height(),
                               Qt.AlignmentFlag.AlignRight, number)
            
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1
    
    def keyPressEvent(self, event):
        """Обработка нажатий клавиш"""
        # Автодополнение
        if self.completer and self.completer.popup().isVisible():
            if event.key() in (Qt.Key.Key_Enter, Qt.Key.Key_Return, Qt.Key.Key_Escape):
                event.ignore()
                return
        
        # Tab для отступов
        if event.key() == Qt.Key.Key_Tab:
            self.insertPlainText("    ")
            return
        
        # Ctrl+Space для автодополнения
        if event.key() == Qt.Key.Key_Space and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            self.show_completer()
            return
        
        super().keyPressEvent(event)
    
    def show_completer(self):
        """Показ автодополнения"""
        cursor = self.textCursor()
        cursor.select(QTextCursor.SelectionType.WordUnderCursor)
        word = cursor.selectedText()
        
        if not word:
            return
        
        # Фильтруем по началу слова
        matches = [kw for kw in self.completer_model.stringList() if kw.startswith(word.lower())]
        
        if matches:
            self.completer_model.setStringList(matches)
            self.completer.setCompletionPrefix(word)
            self.completer.complete()
    
    def contextMenuEvent(self, event):
        """Контекстное меню"""
        menu = self.createStandardContextMenu()
        
        menu.addSeparator()
        
        # Дополнительные действия
        run_action = menu.addAction("▶️ Выполнить скрипт")
        run_action.triggered.connect(lambda: self.parent().run_script() if hasattr(self.parent(), 'run_script') else None)
        
        format_action = menu.addAction("🎨 Форматировать код")
        format_action.triggered.connect(self.format_code)
        
        comment_action = menu.addAction("💬 Закомментировать строку")
        comment_action.triggered.connect(self.comment_line)
        
        menu.exec(event.globalPos())
    
    def format_code(self):
        """Форматирование кода (базовое)"""
        text = self.toPlainText()
        lines = text.split('\n')
        formatted = []
        
        indent_level = 0
        for line in lines:
            stripped = line.strip()
            
            # Уменьшаем отступ для закрывающих блоков
            if stripped.startswith('end') or stripped.startswith('else') or stripped.startswith('until'):
                indent_level = max(0, indent_level - 1)
            
            # Добавляем строку с отступом
            indent = '    ' * indent_level
            formatted.append(indent + stripped)
            
            # Увеличиваем отступ для открывающих блоков
            if 'function' in stripped or stripped.startswith('if') or stripped.startswith('for') or stripped.startswith('while'):
                indent_level += 1
        
        self.setPlainText('\n'.join(formatted))
    
    def comment_line(self):
        """Закомментировать текущую строку"""
        cursor = self.textCursor()
        cursor.select(QTextCursor.SelectionType.LineUnderCursor)
        selected_text = cursor.selectedText()
        
        if selected_text:
            if selected_text.startswith('--'):
                # Раскомментировать
                new_text = selected_text[2:]
            else:
                # Закомментировать
                new_text = '-- ' + selected_text
            
            cursor.insertText(new_text)


class LuaHighlighter(QSyntaxHighlighter):
    """Подсветка синтаксиса Lua"""
    
    def __init__(self, parent):
        super().__init__(parent)
        self.highlighting_rules = []
        
        # Ключевые слова
        keywords = [
            "and", "break", "do", "else", "elseif", "end", "false", "for", 
            "function", "if", "in", "local", "nil", "not", "or", "repeat", 
            "return", "then", "true", "until", "while"
        ]
        
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor(86, 156, 214))
        keyword_format.setFontWeight(QFont.Weight.Bold)
        
        for word in keywords:
            pattern = QRegularExpression(f"\\b{word}\\b")
            self.highlighting_rules.append((pattern, keyword_format))
        
        # Функции Proxmark3
        pm3_funcs = ["pm3\\.command", "print", "sleep", "pm3"]
        pm3_format = QTextCharFormat()
        pm3_format.setForeground(QColor(220, 220, 170))
        
        for func in pm3_funcs:
            pattern = QRegularExpression(f"\\b{func}\\b")
            self.highlighting_rules.append((pattern, pm3_format))
        
        # Строки
        string_format = QTextCharFormat()
        string_format.setForeground(QColor(206, 145, 120))
        self.highlighting_rules.append((QRegularExpression("\"[^\"]*\""), string_format))
        self.highlighting_rules.append((QRegularExpression("'[^']*'"), string_format))
        
        # Комментарии
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(106, 153, 85))
        self.highlighting_rules.append((QRegularExpression("--[^\n]*"), comment_format))
        
        # Числа
        number_format = QTextCharFormat()
        number_format.setForeground(QColor(181, 206, 168))
        self.highlighting_rules.append((QRegularExpression("\\b[0-9]+\\b"), number_format))
        self.highlighting_rules.append((QRegularExpression("\\b0x[0-9a-fA-F]+\\b"), number_format))
    
    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            match_iterator = pattern.globalMatch(text)
            while match_iterator.hasNext():
                match = match_iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)


class LineNumberArea(QWidget):
    """Область номеров строк"""
    
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
    
    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)
    
    def paintEvent(self, event):
        self.editor.line_number_area_paint_event(event)