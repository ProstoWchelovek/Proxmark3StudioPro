# gui/scripts/script_runner.py
"""
Запуск и управление выполнением скриптов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class ScriptRunner(QWidget):
    """Виджет для запуска и мониторинга скриптов"""
    
    def __init__(self, pm3, script_engine):
        super().__init__()
        self.pm3 = pm3
        self.script_engine = script_engine
        self.current_process = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Выбор скрипта
        select_group = QGroupBox("Выбор скрипта")
        select_layout = QHBoxLayout()
        
        self.script_combo = QComboBox()
        self.script_combo.setEditable(True)
        self.refresh_scripts()
        
        btn_refresh = QPushButton("🔄 Обновить")
        btn_refresh.clicked.connect(self.refresh_scripts)
        
        btn_browse = QPushButton("📁 Обзор...")
        btn_browse.clicked.connect(self.browse_script)
        
        select_layout.addWidget(self.script_combo)
        select_layout.addWidget(btn_refresh)
        select_layout.addWidget(btn_browse)
        select_group.setLayout(select_layout)
        
        # Управление
        control_group = QGroupBox("Управление")
        control_layout = QHBoxLayout()
        
        self.run_btn = QPushButton("▶️ ВЫПОЛНИТЬ")
        self.run_btn.clicked.connect(self.run_script)
        self.run_btn.setStyleSheet("background-color: #4CAF50; padding: 8px;")
        
        self.stop_btn = QPushButton("⏹️ ОСТАНОВИТЬ")
        self.stop_btn.clicked.connect(self.stop_script)
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet("background-color: #f44336; padding: 8px;")
        
        control_layout.addWidget(self.run_btn)
        control_layout.addWidget(self.stop_btn)
        control_group.setLayout(control_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод скрипта")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Статус
        self.status_label = QLabel("Готов к выполнению")
        
        layout.addWidget(select_group)
        layout.addWidget(control_group)
        layout.addWidget(output_group)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
    
    def refresh_scripts(self):
        self.script_combo.clear()
        scripts = self.script_engine.list_scripts()
        for script in scripts:
            self.script_combo.addItem(script['name'])
    
    def browse_script(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите скрипт", "", 
                                                   "Lua files (*.lua);;Python files (*.py)")
        if filename:
            self.script_combo.setEditText(filename)
    
    def run_script(self):
        script_path = self.script_combo.currentText()
        if not script_path:
            QMessageBox.warning(self, "Ошибка", "Выберите скрипт")
            return
        
        self.output_text.clear()
        self.append_output(f"🚀 Запуск скрипта: {script_path}")
        self.status_label.setText("Выполняется...")
        self.run_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        
        # Запуск в потоке
        self.script_thread = ScriptThread(self.script_engine, script_path)
        self.script_thread.output.connect(self.append_output)
        self.script_thread.finished.connect(self.on_script_finished)
        self.script_thread.start()
    
    def stop_script(self):
        if self.script_thread:
            self.script_thread.stop()
            self.append_output("⏹️ Скрипт остановлен пользователем")
            self.status_label.setText("Остановлен")
    
    def on_script_finished(self):
        self.append_output("✅ Выполнение скрипта завершено")
        self.status_label.setText("Готов")
        self.run_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()


class ScriptThread(QThread):
    """Поток для выполнения скрипта"""
    
    output = Signal(str)
    finished = Signal()
    
    def __init__(self, script_engine, script_path):
        super().__init__()
        self.script_engine = script_engine
        self.script_path = script_path
        self.running = True
    
    def run(self):
        try:
            result = self.script_engine.run_script(self.script_path)
            self.output.emit(result)
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.script_engine.stop_script()