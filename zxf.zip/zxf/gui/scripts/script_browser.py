# gui/scripts/script_browser.py
"""
Браузер скриптов с категориями и поиском
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os
from pathlib import Path


class ScriptBrowser(QWidget):
    """Браузер скриптов с категориями"""
    
    script_selected = Signal(str)
    
    def __init__(self, script_engine):
        super().__init__()
        self.script_engine = script_engine
        self.init_ui()
        self.load_scripts()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Поиск
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Поиск скриптов...")
        self.search_input.textChanged.connect(self.filter_scripts)
        layout.addWidget(self.search_input)
        
        # Дерево категорий
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("Скрипты")
        self.tree.setIconSize(QSize(24, 24))
        self.tree.itemDoubleClicked.connect(self.on_script_double_click)
        
        layout.addWidget(self.tree)
        
        self.setLayout(layout)
    
    def load_scripts(self):
        """Загрузка скриптов в дерево"""
        self.tree.clear()
        
        # Категории
        categories = {
            "📁 Встроенные": [],
            "📁 Пользовательские": []
        }
        
        # Встроенные скрипты
        for script in self.script_engine.get_builtin_scripts():
            categories["📁 Встроенные"].append(script)
        
        # Пользовательские скрипты
        for script in self.script_engine.list_scripts():
            categories["📁 Пользовательские"].append(script)
        
        # Добавляем в дерево
        for cat_name, scripts in categories.items():
            if scripts:
                cat_item = QTreeWidgetItem([cat_name])
                cat_item.setIcon(0, QIcon())
                self.tree.addTopLevelItem(cat_item)
                
                for script in scripts:
                    script_item = QTreeWidgetItem([script.get('name', '')])
                    script_item.setData(0, Qt.UserRole, script)
                    script_item.setIcon(0, QIcon())
                    cat_item.addChild(script_item)
        
        self.tree.expandAll()
    
    def filter_scripts(self):
        """Фильтрация скриптов"""
        search_text = self.search_input.text().lower()
        
        for i in range(self.tree.topLevelItemCount()):
            cat_item = self.tree.topLevelItem(i)
            visible = False
            
            for j in range(cat_item.childCount()):
                script_item = cat_item.child(j)
                script_name = script_item.text(0).lower()
                
                if search_text in script_name:
                    script_item.setHidden(False)
                    visible = True
                else:
                    script_item.setHidden(True)
            
            cat_item.setHidden(not visible)
    
    def on_script_double_click(self, item, column):
        """Обработка двойного клика по скрипту"""
        script_data = item.data(0, Qt.UserRole)
        if script_data:
            self.script_selected.emit(script_data.get('name', ''))