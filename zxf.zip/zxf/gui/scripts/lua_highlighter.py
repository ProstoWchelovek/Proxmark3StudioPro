# gui/scripts/lua_highlighter.py
from PySide6.QtCore import *
from PySide6.QtGui import *

class LuaHighlighter(QSyntaxHighlighter):
    """Полная подсветка синтаксиса Lua с поддержкой Proxmark3 API"""
    
    def __init__(self, parent):
        super().__init__(parent)
        
        self.highlighting_rules = []
        
        # Цветовая схема (темная)
        self.colors = {
            'keyword': QColor(86, 156, 214),      # Синий
            'function': QColor(220, 220, 170),    # Желтоватый
            'string': QColor(206, 145, 120),      # Оранжевый
            'comment': QColor(106, 153, 85),      # Зеленый
            'number': QColor(181, 206, 168),      # Светло-зеленый
            'operator': QColor(180, 180, 180),    # Серый
            'pm3_api': QColor(78, 201, 176),      # Бирюзовый
            'constant': QColor(197, 134, 192),    # Фиолетовый
        }
        
        self.setup_rules()
        
        # Многострочные комментарии
        self.comment_start = QRegularExpression("--[[")
        self.comment_end = QRegularExpression("]]")
    
    def setup_rules(self):
        """Настройка правил подсветки"""
        
        # 1. Ключевые слова Lua
        keywords = [
            "and", "break", "do", "else", "elseif", "end", "false", "for",
            "function", "goto", "if", "in", "local", "nil", "not", "or",
            "repeat", "return", "then", "true", "until", "while"
        ]
        
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(self.colors['keyword'])
        keyword_format.setFontWeight(QFont.Weight.Bold)
        
        for word in keywords:
            pattern = QRegularExpression(f"\\b{word}\\b")
            self.highlighting_rules.append((pattern, keyword_format))
        
        # 2. Функции Proxmark3 API
        pm3_functions = [
            "pm3\\.command", "pm3\\.cmd", "pm3\\.read", "pm3\\.write",
            "print", "printf", "sleep", "msleep", "usleep",
            "core\\.", "utils\\.",
        ]
        
        pm3_format = QTextCharFormat()
        pm3_format.setForeground(self.colors['pm3_api'])
        pm3_format.setFontWeight(QFont.Weight.Bold)
        
        for func in pm3_functions:
            pattern = QRegularExpression(f"\\b{func}\\b")
            self.highlighting_rules.append((pattern, pm3_format))
        
        # 3. Стандартные функции Lua
        std_functions = [
            "assert", "collectgarbage", "dofile", "error", "getmetatable",
            "ipairs", "load", "loadfile", "next", "pairs", "pcall", "print",
            "rawequal", "rawget", "rawlen", "rawset", "select", "setmetatable",
            "tonumber", "tostring", "type", "xpcall", "_G", "_VERSION",
            "table\\.",
        ]
        
        func_format = QTextCharFormat()
        func_format.setForeground(self.colors['function'])
        
        for func in std_functions:
            pattern = QRegularExpression(f"\\b{func}\\b")
            self.highlighting_rules.append((pattern, func_format))
        
        # 4. Константы
        constants = ["true", "false", "nil", "math\\.", "string\\."]
        const_format = QTextCharFormat()
        const_format.setForeground(self.colors['constant'])
        
        for const in constants:
            pattern = QRegularExpression(f"\\b{const}\\b")
            self.highlighting_rules.append((pattern, const_format))
        
        # 5. Строки (двойные кавычки)
        string_format = QTextCharFormat()
        string_format.setForeground(self.colors['string'])
        self.highlighting_rules.append((
            QRegularExpression("\"[^\"]*\""),
            string_format
        ))
        
        # 6. Строки (одинарные кавычки)
        self.highlighting_rules.append((
            QRegularExpression("'[^']*'"),
            string_format
        ))
        
        # 7. Однострочные комментарии
        comment_format = QTextCharFormat()
        comment_format.setForeground(self.colors['comment'])
        self.highlighting_rules.append((
            QRegularExpression("--[^\n]*"),
            comment_format
        ))
        
        # 8. Числа (десятичные)
        number_format = QTextCharFormat()
        number_format.setForeground(self.colors['number'])
        self.highlighting_rules.append((
            QRegularExpression("\\b[0-9]+\\b"),
            number_format
        ))
        
        # 9. Числа (шестнадцатеричные)
        self.highlighting_rules.append((
            QRegularExpression("\\b0x[0-9a-fA-F]+\\b"),
            number_format
        ))
        
        # 10. Числа с плавающей точкой
        self.highlighting_rules.append((
            QRegularExpression("\\b[0-9]+\\.[0-9]+\\b"),
            number_format
        ))
        
        # 11. Операторы
        operators = ["+", "-", "*", "/", "%", "^", "#", "==", "~=", "<=", ">=", "<", ">", "=", "and", "or", "not"]
        operator_format = QTextCharFormat()
        operator_format.setForeground(self.colors['operator'])
        
        for op in operators:
            pattern = QRegularExpression(f"\\{op}" if op in "+-*/%^#" else f"\\b{op}\\b")
            self.highlighting_rules.append((pattern, operator_format))
        
        # 12. HEX ключи (специально для Proxmark3)
        hex_key_format = QTextCharFormat()
        hex_key_format.setForeground(QColor(255, 200, 100))
        hex_key_format.setFontWeight(QFont.Weight.Bold)
        self.highlighting_rules.append((
            QRegularExpression("\\b[0-9A-Fa-f]{8,16}\\b"),
            hex_key_format
        ))
    
    def highlightBlock(self, text):
        """Подсветка блока текста"""
        # Применяем все правила
        for pattern, format in self.highlighting_rules:
            match_iterator = pattern.globalMatch(text)
            while match_iterator.hasNext():
                match = match_iterator.next()
                start = match.capturedStart()
                length = match.capturedLength()
                self.setFormat(start, length, format)
        
        # Многострочные комментарии
        self.setCurrentBlockState(0)
        
        start_index = 0
        if self.previousBlockState() != 1:
            start_index = text.indexOf(self.comment_start)
        
        while start_index >= 0:
            match = self.comment_end.match(text, start_index)
            end_index = match.capturedStart()
            
            if end_index == -1:
                self.setCurrentBlockState(1)
                comment_length = len(text) - start_index
            else:
                comment_length = end_index - start_index + match.capturedLength()
            
            self.setFormat(start_index, comment_length, QTextCharFormat().setForeground(self.colors['comment']))
            start_index = text.indexOf(self.comment_start, start_index + comment_length)