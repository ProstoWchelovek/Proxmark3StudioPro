# gui/scripts/script_manager.py
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os
import shutil
from pathlib import Path
from datetime import datetime

class ScriptManager(QWidget):
    """Управление Lua/Python скриптами для Proxmark3"""
    
    script_selected = Signal(str)
    
    def __init__(self, pm3_client, script_engine):
        super().__init__()
        self.pm3 = pm3_client
        self.script_engine = script_engine
        self.scripts_dir = self.get_scripts_dir()
        self.init_ui()
        self.load_scripts()
    
    def get_scripts_dir(self):
        """Получение директории скриптов"""
        # Проверяем несколько возможных мест
        possible_dirs = [
            os.path.join(Path.home(), '.proxmark3_studio', 'scripts'),
            os.path.join(os.path.dirname(__file__), '..', '..', 'resources', 'scripts'),
            os.path.join(os.getcwd(), 'resources', 'scripts'),
        ]
        
        for dir_path in possible_dirs:
            if os.path.exists(dir_path):
                return dir_path
        
        # Создаём директорию
        default_dir = os.path.join(Path.home(), '.proxmark3_studio', 'scripts')
        os.makedirs(default_dir, exist_ok=True)
        return default_dir
    
    def init_ui(self):
        layout = QHBoxLayout()
        
        # Левая панель - список скриптов
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_panel.setMaximumWidth(350)
        
        self.script_list = QListWidget()
        self.script_list.setIconSize(QSize(24, 24))
        self.script_list.itemClicked.connect(self.on_script_selected)
        self.script_list.itemDoubleClicked.connect(self.run_script_from_list)
        
        # Панель инструментов
        toolbar = QToolBar()
        toolbar.setIconSize(QSize(20, 20))
        
        btn_refresh = QPushButton("🔄")
        btn_refresh.setToolTip("Обновить список")
        btn_refresh.clicked.connect(self.load_scripts)
        
        btn_new = QPushButton("➕")
        btn_new.setToolTip("Новый скрипт")
        btn_new.clicked.connect(self.new_script)
        
        btn_import = QPushButton("📁")
        btn_import.setToolTip("Импорт скрипта")
        btn_import.clicked.connect(self.import_script)
        
        btn_delete = QPushButton("🗑️")
        btn_delete.setToolTip("Удалить скрипт")
        btn_delete.clicked.connect(self.delete_script)
        
        btn_run = QPushButton("▶️")
        btn_run.setToolTip("Выполнить скрипт")
        btn_run.clicked.connect(self.run_selected_script)
        
        btn_stop = QPushButton("⏹️")
        btn_stop.setToolTip("Остановить выполнение")
        btn_stop.clicked.connect(self.stop_script)
        
        toolbar.addWidget(btn_refresh)
        toolbar.addWidget(btn_new)
        toolbar.addWidget(btn_import)
        toolbar.addWidget(btn_delete)
        toolbar.addSeparator()
        toolbar.addWidget(btn_run)
        toolbar.addWidget(btn_stop)
        
        # Поиск
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Поиск скриптов...")
        self.search_input.textChanged.connect(self.filter_scripts)
        
        left_layout.addWidget(toolbar)
        left_layout.addWidget(self.search_input)
        left_layout.addWidget(self.script_list)
        
        # Правая панель - редактор
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Информация о скрипте
        info_layout = QHBoxLayout()
        self.script_name = QLineEdit()
        self.script_name.setPlaceholderText("Имя скрипта")
        self.script_name.setMinimumWidth(300)
        
        self.script_type = QComboBox()
        self.script_type.addItems(["Lua Script (.lua)", "Python Script (.py)"])
        
        info_layout.addWidget(self.script_name)
        info_layout.addWidget(self.script_type)
        info_layout.addStretch()
        
        # Редактор с подсветкой
        self.script_editor = QTextEdit()
        self.script_editor.setFont(QFont("Courier New", 11))
        
        # Панель выполнения
        exec_panel = QWidget()
        exec_layout = QVBoxLayout(exec_panel)
        exec_layout.setContentsMargins(0, 0, 0, 0)
        
        exec_header = QLabel("Результат выполнения:")
        self.exec_output = QTextEdit()
        self.exec_output.setReadOnly(True)
        self.exec_output.setFont(QFont("Courier New", 10))
        self.exec_output.setMaximumHeight(200)
        
        exec_layout.addWidget(exec_header)
        exec_layout.addWidget(self.exec_output)
        
        # Кнопки сохранения
        btn_save = QPushButton("💾 СОХРАНИТЬ СКРИПТ")
        btn_save.clicked.connect(self.save_script)
        btn_save.setStyleSheet("background-color: #4CAF50; padding: 8px; font-weight: bold;")
        
        right_layout.addLayout(info_layout)
        right_layout.addWidget(self.script_editor)
        right_layout.addWidget(exec_panel)
        right_layout.addWidget(btn_save)
        
        # Разделитель
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([300, 900])
        
        layout.addWidget(splitter)
        self.setLayout(layout)
        
        # Текущий скрипт
        self.current_script = None
        self.current_script_path = None
        self.running_thread = None
    
    def load_scripts(self):
        """Загрузка списка скриптов"""
        self.script_list.clear()
        
        if not os.path.exists(self.scripts_dir):
            os.makedirs(self.scripts_dir)
        
        for file in sorted(os.listdir(self.scripts_dir)):
            if file.endswith(('.lua', '.py')):
                item = QListWidgetItem(self.get_script_icon(file), file)
                item.setData(Qt.UserRole, os.path.join(self.scripts_dir, file))
                self.script_list.addItem(item)
    
    def get_script_icon(self, filename: str):
        """Получение иконки для скрипта"""
        if filename.endswith('.lua'):
            return "📜"
        else:
            return "🐍"
    
    def filter_scripts(self):
        """Фильтрация списка скриптов"""
        search_text = self.search_input.text().lower()
        
        for i in range(self.script_list.count()):
            item = self.script_list.item(i)
            item.setHidden(search_text not in item.text().lower())
    
    def on_script_selected(self, item):
        """Выбор скрипта"""
        script_path = item.data(Qt.UserRole)
        self.current_script_path = script_path
        self.current_script = os.path.basename(script_path)
        
        # Обновляем поля
        self.script_name.setText(self.current_script)
        
        ext = os.path.splitext(self.current_script)[1]
        self.script_type.setCurrentIndex(0 if ext == '.lua' else 1)
        
        # Загружаем содержимое
        try:
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
                self.script_editor.setText(content)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить скрипт: {e}")
        
        self.script_selected.emit(self.current_script)
    
    def new_script(self):
        """Создание нового скрипта"""
        self.current_script = None
        self.current_script_path = None
        self.script_name.clear()
        self.script_editor.clear()
        
        # Шаблон скрипта
        template = """-- Proxmark3 Lua Script
-- Автоматически сгенерировано Proxmark3 Studio Pro

local pm3 = require('pm3')

function main()
    print("=== Proxmark3 Script Started ===")
    
    -- Ваш код здесь
    -- Пример: чтение карты
    local result = pm3.command('hf 14a reader')
    print(result)
    
    print("=== Script Finished ===")
    return 0
end

main()
"""
        self.script_editor.setText(template)
        self.script_name.setFocus()
    
    def import_script(self):
        """Импорт скрипта из файла"""
        filename, _ = QFileDialog.getOpenFileName(
            self, "Импорт скрипта", "",
            "Script files (*.lua *.py);;Lua files (*.lua);;Python files (*.py);;All files (*.*)"
        )
        
        if filename:
            dest = os.path.join(self.scripts_dir, os.path.basename(filename))
            
            # Проверка на существование
            if os.path.exists(dest):
                reply = QMessageBox.question(
                    self, "Файл существует",
                    f"Файл {os.path.basename(filename)} уже существует. Заменить?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply != QMessageBox.StandardButton.Yes:
                    return
            
            shutil.copy2(filename, dest)
            self.load_scripts()
            QMessageBox.information(self, "Успех", f"Скрипт импортирован: {os.path.basename(filename)}")
    
    def delete_script(self):
        """Удаление скрипта"""
        current_item = self.script_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "Ошибка", "Выберите скрипт для удаления")
            return
        
        script_name = current_item.text()
        reply = QMessageBox.question(
            self, "Удаление",
            f"Удалить скрипт '{script_name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            script_path = current_item.data(Qt.UserRole)
            try:
                os.remove(script_path)
                self.load_scripts()
                QMessageBox.information(self, "Успех", f"Скрипт удалён: {script_name}")
            except Exception as e:
                QMessageBox.warning(self, "Ошибка", f"Не удалось удалить: {e}")
    
    def save_script(self):
        """Сохранение скрипта"""
        name = self.script_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Ошибка", "Введите имя скрипта")
            return
        
        # Добавляем расширение если нужно
        ext = '.lua' if self.script_type.currentIndex() == 0 else '.py'
        if not name.endswith(ext):
            name += ext
        
        script_path = os.path.join(self.scripts_dir, name)
        
        # Проверка на перезапись
        if self.current_script_path != script_path and os.path.exists(script_path):
            reply = QMessageBox.question(
                self, "Файл существует",
                f"Файл {name} уже существует. Перезаписать?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        
        # Сохраняем
        try:
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(self.script_editor.toPlainText())
            
            self.current_script_path = script_path
            self.current_script = name
            self.load_scripts()
            
            QMessageBox.information(self, "Успех", f"Скрипт сохранён: {name}")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось сохранить: {e}")
    
    def run_selected_script(self):
        """Запуск выбранного скрипта"""
        current_item = self.script_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "Ошибка", "Выберите скрипт для выполнения")
            return
        
        self.run_script(current_item.data(Qt.UserRole))
    
    def run_script_from_list(self, item):
        """Запуск скрипта по двойному клику"""
        self.run_script(item.data(Qt.UserRole))
    
    def run_script(self, script_path):
        """Запуск скрипта"""
        self.exec_output.clear()
        self.exec_output.append(f"=== Запуск скрипта: {os.path.basename(script_path)} ===\n")
        
        # Запуск в отдельном потоке
        self.running_thread = ScriptExecutionThread(self.script_engine, script_path, self.pm3)
        self.running_thread.output.connect(self.exec_output.append)
        self.running_thread.finished.connect(self.on_script_finished)
        self.running_thread.start()
    
    def stop_script(self):
        """Остановка выполнения скрипта"""
        if self.running_thread and self.running_thread.isRunning():
            self.running_thread.stop()
            self.exec_output.append("\n⚠️ Скрипт остановлен пользователем")
    
    def on_script_finished(self):
        """Обработка завершения скрипта"""
        self.exec_output.append("\n=== Выполнение скрипта завершено ===")
        self.running_thread = None


class ScriptExecutionThread(QThread):
    """Поток для выполнения скриптов"""
    output = Signal(str)
    
    def __init__(self, script_engine, script_path, pm3):
        super().__init__()
        self.script_engine = script_engine
        self.script_path = script_path
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        try:
            if self.script_path.endswith('.lua'):
                self.execute_lua_script()
            else:
                self.execute_python_script()
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
    
    def execute_lua_script(self):
        """Выполнение Lua скрипта"""
        import lupa
        from lupa import LuaRuntime
        
        lua = LuaRuntime(unpack_returned_tuples=True)
        
        # Определяем функции для Lua
        def pm3_command(cmd):
            if not self.running:
                return "Script stopped"
            result = self.pm3.run_command(cmd)
            self.output.emit(f">>> {cmd}\n{result}")
            return result
        
        def print_message(msg):
            self.output.emit(str(msg))
            return None
        
        def sleep_ms(ms):
            if self.running:
                QThread.msleep(ms)
        
        lua.globals().pm3 = pm3_command
        lua.globals().print = print_message
        lua.globals().sleep = sleep_ms
        
        # Загружаем и выполняем скрипт
        with open(self.script_path, 'r', encoding='utf-8') as f:
            script_content = f.read()
        
        self.output.emit("📜 Выполнение Lua скрипта...")
        result = lua.execute(script_content)
        self.output.emit(f"Результат: {result}")
    
    def execute_python_script(self):
        """Выполнение Python скрипта"""
        import importlib.util
        import sys
        
        # Загружаем скрипт как модуль
        spec = importlib.util.spec_from_file_location("user_script", self.script_path)
        module = importlib.util.module_from_spec(spec)
        
        # Передаём объекты в скрипт
        module.pm3 = self.pm3
        module.output = self.output.emit
        
        spec.loader.exec_module(module)
        
        # Вызываем main если есть
        if hasattr(module, 'main'):
            self.output.emit("🐍 Выполнение Python скрипта...")
            module.main()
    
    def stop(self):
        self.running = False