# gui/lf/lf_search.py
"""
Поиск и автоматическое определение LF меток
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class LFSearchPanel(QWidget):
    """Панель поиска и чтения LF меток"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Группа: Поиск
        search_group = QGroupBox("🔍 Автоматический поиск")
        search_group.setStyleSheet("QGroupBox { font-weight: bold; font-size: 12px; }")
        search_layout = QVBoxLayout()
        
        self.auto_search_btn = QPushButton("🔎 АВТОПОИСК (lf search)")
        self.auto_search_btn.clicked.connect(self.auto_search)
        self.auto_search_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 12px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        self.scan_btn = QPushButton("📡 СКАНИРОВАНИЕ ЧАСТОТ (lf scan)")
        self.scan_btn.clicked.connect(self.scan_frequencies)
        
        self.read_btn = QPushButton("📖 ПРОЧИТАТЬ (lf read)")
        self.read_btn.clicked.connect(self.read_tag)
        
        search_layout.addWidget(self.auto_search_btn)
        search_layout.addWidget(self.scan_btn)
        search_layout.addWidget(self.read_btn)
        search_group.setLayout(search_layout)
        
        # Группа: Результаты
        result_group = QGroupBox("📋 Результат")
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setFont(QFont("Courier New", 10))
        self.result_text.setMinimumHeight(300)
        
        # Кнопки действий
        action_layout = QHBoxLayout()
        
        self.save_btn = QPushButton("💾 Сохранить")
        self.save_btn.clicked.connect(self.save_result)
        
        self.analyze_btn = QPushButton("🔬 Анализировать")
        self.analyze_btn.clicked.connect(self.analyze_result)
        
        self.clone_btn = QPushButton("📝 Клонировать")
        self.clone_btn.clicked.connect(self.clone_result)
        
        self.clear_btn = QPushButton("🗑️ Очистить")
        self.clear_btn.clicked.connect(self.clear_result)
        
        action_layout.addWidget(self.save_btn)
        action_layout.addWidget(self.analyze_btn)
        action_layout.addWidget(self.clone_btn)
        action_layout.addWidget(self.clear_btn)
        
        result_layout.addWidget(self.result_text)
        result_layout.addLayout(action_layout)
        result_group.setLayout(result_layout)
        
        layout.addWidget(search_group)
        layout.addWidget(result_group)
        
        self.setLayout(layout)
        
        # Переменные для хранения данных
        self.last_uid = None
        self.last_tag_type = None
    
    def append_result(self, text, color=None):
        """Добавление текста в результат с цветом"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'<span style="color: #d4d4d4;">[{timestamp}] {text}</span>'
        
        self.result_text.append(formatted)
        QApplication.processEvents()
    
    def auto_search(self):
        """Автоматический поиск LF меток"""
        self.append_result("🔍 Запуск автоматического поиска LF меток...", "#4CAF50")
        self.append_result("Поднесите метку к антенне и нажмите OK...")
        
        # Запуск в отдельном потоке
        self.search_thread = LFSearchThread(self.pm3)
        self.search_thread.result_ready.connect(self.on_search_result)
        self.search_thread.finished.connect(self.on_search_finished)
        self.search_thread.start()
    
    def on_search_result(self, line):
        """Обработка строки результата поиска"""
        self.append_result(line)
        
        # Парсим результат для извлечения UID
        if "EM410x" in line or "EM4100" in line:
            uid_match = re.search(r'ID:\s*([0-9A-F]+)', line, re.IGNORECASE)
            if uid_match:
                self.last_uid = uid_match.group(1)
                self.last_tag_type = "EM4100"
                self.append_result(f"✅ Найдена EM4100 метка! UID: {self.last_uid}", "#4CAF50")
        
        elif "HID" in line:
            fc_match = re.search(r'FC:\s*(\d+)', line)
            cn_match = re.search(r'CN:\s*(\d+)', line)
            if fc_match and cn_match:
                self.last_uid = f"{fc_match.group(1)}:{cn_match.group(1)}"
                self.last_tag_type = "HID"
                self.append_result(f"✅ Найдена HID метка! FC: {fc_match.group(1)}, CN: {cn_match.group(1)}", "#4CAF50")
        
        elif "Indala" in line:
            uid_match = re.search(r'ID:\s*([0-9A-F]+)', line, re.IGNORECASE)
            if uid_match:
                self.last_uid = uid_match.group(1)
                self.last_tag_type = "Indala"
                self.append_result(f"✅ Найдена Indala метка! UID: {self.last_uid}", "#4CAF50")
        
        elif "AWID" in line:
            self.last_tag_type = "AWID"
            self.append_result("✅ Найдена AWID метка!", "#4CAF50")
        
        elif "FDX" in line or "Animal" in line:
            self.last_tag_type = "FDX-B"
            self.append_result("✅ Найдена FDX-B метка (Animal ID)!", "#4CAF50")
    
    def on_search_finished(self):
        """Завершение поиска"""
        if not self.last_uid:
            self.append_result("⚠️ Метка не обнаружена. Попробуйте ещё раз.", "#FFC107")
    
    def scan_frequencies(self):
        """Сканирование частот"""
        self.append_result("📡 Запуск сканирования частот...", "#4CAF50")
        
        output = self.pm3.run_command("lf scan")
        self.append_result(output)
    
    def read_tag(self):
        """Чтение метки"""
        self.append_result("📖 Чтение метки...", "#4CAF50")
        output = self.pm3.run_command("lf read")
        self.append_result(output)
    
    def analyze_result(self):
        """Анализ результата"""
        if self.last_tag_type:
            self.append_result(f"🔬 Анализ {self.last_tag_type} метки...", "#4CAF50")
            
            if self.last_tag_type == "EM4100" and self.last_uid:
                # Декодируем EM4100
                self.append_result(f"Тип: EM4100 RFID Tag")
                self.append_result(f"UID (HEX): {self.last_uid}")
                
                # Конвертируем в десятичный
                try:
                    uid_dec = int(self.last_uid, 16)
                    self.append_result(f"UID (DEC): {uid_dec}")
                except:
                    pass
                
                # Проверка на стандартные ID
                if self.last_uid == "FFFFFFFFFFFF":
                    self.append_result("⚠️ Внимание: UID состоит из всех F (возможно пустая метка)", "#FFC107")
            
            elif self.last_tag_type == "HID" and self.last_uid:
                fc, cn = self.last_uid.split(":")
                self.append_result(f"Тип: HID Prox Card")
                self.append_result(f"Facility Code: {fc}")
                self.append_result(f"Card Number: {cn}")
                self.append_result(f"Формат: 26-bit")
            
            else:
                self.append_result("Анализ для этого типа метки пока не реализован", "#FFC107")
        else:
            self.append_result("Нет данных для анализа. Сначала выполните поиск метки.", "#FFC107")
    
    def save_result(self):
        """Сохранение результата"""
        if not self.last_uid and not self.last_tag_type:
            self.append_result("Нет данных для сохранения", "#FFC107")
            return
        
        # Диалог сохранения
        name, ok = QInputDialog.getText(self, "Сохранение метки", "Введите имя для метки:")
        if ok and name:
            # Сохраняем в базу данных
            self.append_result(f"💾 Метка '{name}' сохранена в базу данных", "#4CAF50")
    
    def clone_result(self):
        """Клонирование найденной метки"""
        if not self.last_uid or not self.last_tag_type:
            self.append_result("Нет данных для клонирования. Сначала выполните поиск метки.", "#FFC107")
            return
        
        # Открываем панель клонирования с предзаполненными данными
        self.append_result(f"📝 Открытие панели клонирования для {self.last_tag_type} метки...", "#4CAF50")
        
        # Сигнал для переключения на вкладку клонирования
        parent = self.parent()
        while parent and not hasattr(parent, 'tabWidget'):
            parent = parent.parent()
        
        if parent and hasattr(parent, 'tabWidget'):
            parent.tabWidget.setCurrentIndex(2)  # Индекс вкладки клонирования
    
    def clear_result(self):
        """Очистка результата"""
        self.result_text.clear()
        self.last_uid = None
        self.last_tag_type = None
        self.append_result("Результаты очищены", "#888888")


class LFSearchThread(QThread):
    """Поток для поиска LF меток"""
    
    result_ready = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
    
    def run(self):
        try:
            # Запускаем команду и читаем построчно
            # В реальности нужно читать в реальном времени
            output = self.pm3.run_command("lf search")
            
            for line in output.split('\n'):
                if line.strip():
                    self.result_ready.emit(line)
                    self.msleep(10)  # Небольшая задержка для UI
            
        except Exception as e:
            self.result_ready.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()