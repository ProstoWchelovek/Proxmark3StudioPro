# gui/lf/lf_analyzer.py
"""
Панель анализа LF сигналов с визуализацией
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import numpy as np

try:
    import pyqtgraph as pg
    PG_AVAILABLE = True
except ImportError:
    PG_AVAILABLE = False
    pg = None


class LFAnalyzerPanel(QWidget):
    """Панель анализа LF сигналов"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.samples = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Панель управления
        control_layout = QHBoxLayout()
        
        self.sample_btn = QPushButton("📡 ЗАХВАТИТЬ СИГНАЛ")
        self.sample_btn.clicked.connect(self.capture_signal)
        
        self.sample_time = QSpinBox()
        self.sample_time.setRange(1, 100)
        self.sample_time.setValue(10)
        self.sample_time.setSuffix(" мс")
        
        self.zoom_spin = QDoubleSpinBox()
        self.zoom_spin.setRange(0.1, 10)
        self.zoom_spin.setValue(1)
        self.zoom_spin.setSuffix("x")
        self.zoom_spin.valueChanged.connect(self.zoom_signal)
        
        control_layout.addWidget(self.sample_btn)
        control_layout.addWidget(QLabel("Длительность:"))
        control_layout.addWidget(self.sample_time)
        control_layout.addWidget(QLabel("Масштаб:"))
        control_layout.addWidget(self.zoom_spin)
        control_layout.addStretch()
        
        # График сигнала
        if PG_AVAILABLE:
            self.plot_widget = pg.PlotWidget()
            self.plot_widget.setLabel('left', 'Амплитуда')
            self.plot_widget.setLabel('bottom', 'Время', 'мкс')
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            self.plot_curve = self.plot_widget.plot(pen='g')
        else:
            self.plot_widget = QLabel("Установите pyqtgraph для визуализации:\npip install pyqtgraph")
            self.plot_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.plot_widget.setMinimumHeight(300)
            self.plot_widget.setStyleSheet("border: 1px solid #555; background-color: #1e1e1e;")
        
        # Панель анализа
        analysis_group = QGroupBox("Анализ сигнала")
        analysis_layout = QGridLayout()
        
        self.freq_label = QLabel("-")
        self.modulation_label = QLabel("-")
        self.encoding_label = QLabel("-")
        self.amplitude_label = QLabel("-")
        self.snr_label = QLabel("-")
        self.confidence_label = QLabel("-")
        
        analysis_layout.addWidget(QLabel("Частота:"), 0, 0)
        analysis_layout.addWidget(self.freq_label, 0, 1)
        analysis_layout.addWidget(QLabel("Модуляция:"), 0, 2)
        analysis_layout.addWidget(self.modulation_label, 0, 3)
        analysis_layout.addWidget(QLabel("Кодирование:"), 1, 0)
        analysis_layout.addWidget(self.encoding_label, 1, 1)
        analysis_layout.addWidget(QLabel("Амплитуда:"), 1, 2)
        analysis_layout.addWidget(self.amplitude_label, 1, 3)
        analysis_layout.addWidget(QLabel("SNR:"), 2, 0)
        analysis_layout.addWidget(self.snr_label, 2, 1)
        analysis_layout.addWidget(QLabel("Уверенность:"), 2, 2)
        analysis_layout.addWidget(self.confidence_label, 2, 3)
        
        analysis_group.setLayout(analysis_layout)
        
        # Кнопки обработки
        process_layout = QHBoxLayout()
        
        btn_demod = QPushButton("🔄 Демодулировать")
        btn_demod.clicked.connect(self.demodulate)
        
        btn_filter = QPushButton("🎛️ Фильтр шума")
        btn_filter.clicked.connect(self.filter_signal)
        
        btn_fft = QPushButton("📊 Показать FFT")
        btn_fft.clicked.connect(self.show_fft)
        
        btn_export = QPushButton("💾 Экспортировать")
        btn_export.clicked.connect(self.export_signal)
        
        process_layout.addWidget(btn_demod)
        process_layout.addWidget(btn_filter)
        process_layout.addWidget(btn_fft)
        process_layout.addWidget(btn_export)
        
        # Вывод демодуляции
        demod_group = QGroupBox("Демодулированные данные")
        demod_layout = QVBoxLayout()
        
        self.demod_text = QTextEdit()
        self.demod_text.setReadOnly(True)
        self.demod_text.setFont(QFont("Courier New", 10))
        self.demod_text.setMaximumHeight(150)
        
        demod_layout.addWidget(self.demod_text)
        demod_group.setLayout(demod_layout)
        
        # Сборка
        layout.addLayout(control_layout)
        layout.addWidget(self.plot_widget, 2)
        layout.addWidget(analysis_group)
        layout.addLayout(process_layout)
        layout.addWidget(demod_group)
        
        self.setLayout(layout)
    
    def capture_signal(self):
        """Захват сигнала"""
        time_ms = self.sample_time.value()
        self.demod_text.append(f"📡 Захват сигнала на {time_ms} мс...")
        
        # Запуск захвата в потоке
        self.capture_thread = SignalCaptureThread(self.pm3, time_ms)
        self.capture_thread.data_ready.connect(self.on_signal_captured)
        self.capture_thread.start()
    
    def on_signal_captured(self, samples):
        """Обработка захваченного сигнала"""
        self.samples = samples
        self.plot_signal(samples)
        self.analyze_signal(samples)
    
    def plot_signal(self, samples):
        """Отображение сигнала"""
        if PG_AVAILABLE:
            zoom = self.zoom_spin.value()
            x = np.arange(len(samples)) / zoom
            self.plot_curve.setData(x, samples)
            self.plot_widget.autoRange()
    
    def analyze_signal(self, samples):
        """Анализ сигнала"""
        if samples is None or len(samples) < 10:
            return
        
        # Базовый анализ
        amplitude = np.max(np.abs(samples))
        self.amplitude_label.setText(f"{amplitude:.2f}")
        
        # FFT для определения частоты
        fft = np.fft.fft(samples)
        freqs = np.fft.fftfreq(len(samples), 1/2000000)  # 2 MHz sample rate
        magnitude = np.abs(fft)
        magnitude[0] = 0  # Убираем DC
        
        if len(magnitude) > 1:
            peak_idx = np.argmax(magnitude[1:]) + 1
            freq = abs(freqs[peak_idx])
            
            if 120000 < freq < 130000:
                self.freq_label.setText(f"{freq/1000:.1f} kHz (LF)")
                self.modulation_label.setText("ASK")
                self.encoding_label.setText("Manchester")
                self.confidence_label.setText("85%")
            elif 130000 < freq < 140000:
                self.freq_label.setText(f"{freq/1000:.1f} kHz (LF)")
                self.modulation_label.setText("FSK")
                self.encoding_label.setText("Biphase")
                self.confidence_label.setText("80%")
            else:
                self.freq_label.setText(f"{freq/1000:.1f} kHz")
        
        # SNR
        signal_power = np.mean(samples[:50]**2) if len(samples) > 50 else np.mean(samples**2)
        noise_power = np.mean(samples[-50:]**2) if len(samples) > 50 else np.mean(samples**2) * 0.1
        snr = 10 * np.log10(signal_power / (noise_power + 1e-10))
        self.snr_label.setText(f"{snr:.1f} dB")
    
    def zoom_signal(self):
        """Масштабирование сигнала"""
        if self.samples is not None:
            self.plot_signal(self.samples)
    
    def demodulate(self):
        """Демодуляция сигнала"""
        if self.samples is None:
            self.demod_text.append("Нет сигнала для демодуляции")
            return
        
        self.demod_text.append("🔄 Демодуляция сигнала...")
        
        # Простая демодуляция ASK
        threshold = np.mean(self.samples) + 0.3 * np.std(self.samples)
        bits = ['1' if s > threshold else '0' for s in self.samples[::10]]
        
        bits_str = ''.join(bits[:200])
        self.demod_text.append(f"Биты: {bits_str}...")
        
        # Попытка декодирования манчестера
        if len(bits_str) > 10:
            decoded = []
            for i in range(0, len(bits_str) - 1, 2):
                if bits_str[i] == '0' and bits_str[i+1] == '1':
                    decoded.append('0')
                elif bits_str[i] == '1' and bits_str[i+1] == '0':
                    decoded.append('1')
            
            if decoded:
                hex_str = ''.join(decoded)
                self.demod_text.append(f"Декодировано: {hex_str}")
    
    def filter_signal(self):
        """Фильтрация сигнала"""
        self.demod_text.append("🎛️ Применение фильтра...")
        # TODO: реализовать фильтрацию
        self.demod_text.append("Фильтрация в разработке")
    
    def show_fft(self):
        """Показать FFT сигнала"""
        if self.samples is None:
            self.demod_text.append("Нет сигнала для FFT")
            return
        
        self.demod_text.append("📊 Расчет FFT...")
        
        fft = np.fft.fft(self.samples)
        freqs = np.fft.fftfreq(len(self.samples), 1/2000000)
        magnitude = np.abs(fft)
        
        # Находим основные частоты
        magnitude[0] = 0
        peaks = []
        for i in range(1, len(magnitude)//2):
            if magnitude[i] > np.mean(magnitude) * 3:
                peaks.append(freqs[i])
        
        if peaks:
            self.demod_text.append(f"Основные частоты: {', '.join([f'{p/1000:.1f}kHz' for p in peaks[:5]])}")
        else:
            self.demod_text.append("Основные частоты не обнаружены")
    
    def export_signal(self):
        """Экспорт сигнала в файл"""
        if self.samples is None:
            self.demod_text.append("Нет сигнала для экспорта")
            return
        
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт сигнала", "", 
                                                   "CSV files (*.csv);;Numpy files (*.npy);;Text files (*.txt)")
        if filename:
            if filename.endswith('.csv'):
                np.savetxt(filename, self.samples, delimiter=',')
            elif filename.endswith('.npy'):
                np.save(filename, self.samples)
            else:
                with open(filename, 'w') as f:
                    f.write(','.join(map(str, self.samples)))
            
            self.demod_text.append(f"💾 Сигнал экспортирован в {filename}")


class SignalCaptureThread(QThread):
    """Поток для захвата сигнала"""
    
    data_ready = Signal(object)
    
    def __init__(self, pm3, time_ms):
        super().__init__()
        self.pm3 = pm3
        self.time_ms = time_ms
    
    def run(self):
        try:
            output = self.pm3.run_command(f"lf sample {self.time_ms}")
            
            # Парсим сэмплы
            import re
            match = re.search(r'Samples?:\s*\[(.*?)\]', output, re.IGNORECASE)
            if match:
                samples_str = match.group(1)
                samples = np.array([int(x.strip()) for x in samples_str.split(',') if x.strip()])
                self.data_ready.emit(samples)
            else:
                # Генерируем тестовый сигнал для демонстрации
                t = np.linspace(0, self.time_ms/1000, 1000)
                samples = np.sin(2 * np.pi * 125000 * t) + 0.5 * np.random.randn(len(t))
                self.data_ready.emit(samples)
                
        except Exception as e:
            print(f"Ошибка захвата: {e}")