# gui/lf/lf_emulation.py
"""
Панель эмуляции LF меток
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LFEmulationPanel(QWidget):
    """Панель эмуляции LF меток"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.is_emulating = False
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Быстрая эмуляция
        quick_group = QGroupBox("🚀 Быстрая эмуляция")
        quick_layout = QGridLayout()
        
        protocols = [
            ("EM4100", "lf em 410x sim"),
            ("HID Prox", "lf hid sim"),
            ("Indala", "lf indala sim"),
            ("AWID", "lf awid sim"),
            ("Viking", "lf viking sim"),
            ("T55x7", "lf t55xx sim"),
            ("FDX-B", "lf fdx sim"),
            ("PCF7931", "lf pcf7931 sim"),
        ]
        
        for i, (name, cmd_base) in enumerate(protocols):
            row = i // 2
            col = i % 2
            
            btn = QPushButton(f"🎭 {name}")
            btn.clicked.connect(lambda checked, n=name, c=cmd_base: self.quick_emulate(n, c))
            btn.setMinimumHeight(50)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #3c3c3c;
                    border: 1px solid #555;
                    border-radius: 5px;
                    font-size: 12px;
                }
                QPushButton:hover {
                    background-color: #4a4a4a;
                }
            """)
            quick_layout.addWidget(btn, row, col)
        
        quick_group.setLayout(quick_layout)
        
        # Расширенная эмуляция
        advanced_group = QGroupBox("🔧 Расширенная эмуляция")
        advanced_layout = QFormLayout()
        
        self.emulation_type = QComboBox()
        self.emulation_type.addItems([
            "EM4100",
            "HID 26-bit",
            "HID 35-bit",
            "HID 37-bit",
            "HID 48-bit",
            "Indala 26-bit",
            "Indala 48-bit",
            "AWID 26-bit",
            "Viking",
            "FDX-B",
            "Custom raw"
        ])
        self.emulation_type.currentIndexChanged.connect(self.on_type_changed)
        
        self.emulation_data = QLineEdit()
        self.emulation_data.setPlaceholderText("UID, FC:CN, или сырые данные")
        
        self.emulation_gap = QSpinBox()
        self.emulation_gap.setRange(0, 10000)
        self.emulation_gap.setValue(1000)
        self.emulation_gap.setSuffix(" мс")
        self.emulation_gap.setToolTip("Пауза между циклами эмуляции")
        
        self.emulation_repeats = QSpinBox()
        self.emulation_repeats.setRange(0, 9999)
        self.emulation_repeats.setSpecialValueText("∞")
        self.emulation_repeats.setValue(0)
        self.emulation_repeats.setToolTip("Количество повторений (0 = бесконечно)")
        
        self.emulation_help = QLabel("")
        self.emulation_help.setStyleSheet("color: #888888; font-size: 10px;")
        
        advanced_layout.addRow("Тип метки:", self.emulation_type)
        advanced_layout.addRow("Данные:", self.emulation_data)
        advanced_layout.addRow("Интервал:", self.emulation_gap)
        advanced_layout.addRow("Повторы:", self.emulation_repeats)
        advanced_layout.addRow("", self.emulation_help)
        advanced_group.setLayout(advanced_layout)
        
        # Статус эмуляции
        status_group = QGroupBox("Статус эмуляции")
        status_layout = QHBoxLayout()
        
        self.status_indicator = QLabel("🔴 Не активна")
        self.status_indicator.setStyleSheet("font-weight: bold;")
        
        self.stopwatch = QLabel("00:00:00")
        self.stopwatch.setStyleSheet("font-family: monospace; font-size: 14px;")
        
        status_layout.addWidget(self.status_indicator)
        status_layout.addStretch()
        status_layout.addWidget(self.stopwatch)
        status_group.setLayout(status_layout)
        
        # Кнопки управления
        button_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("▶️ СТАРТ ЭМУЛЯЦИИ")
        self.start_btn.clicked.connect(self.start_emulation)
        self.start_btn.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        self.stop_btn = QPushButton("⏹️ ОСТАНОВИТЬ")
        self.stop_btn.clicked.connect(self.stop_emulation)
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet("background-color: #f44336; padding: 10px; font-weight: bold;")
        
        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.stop_btn)
        
        # Область вывода
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(150)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(quick_group)
        layout.addWidget(advanced_group)
        layout.addWidget(status_group)
        layout.addLayout(button_layout)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
        
        self.on_type_changed()
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.elapsed_seconds = 0
    
    def on_type_changed(self):
        """Изменение типа эмуляции"""
        em_type = self.emulation_type.currentText()
        
        if "EM4100" in em_type:
            self.emulation_help.setText("Пример: 1A2B3C4D5E (10 символов HEX)")
            self.emulation_data.setPlaceholderText("1A2B3C4D5E")
        elif "HID" in em_type:
            self.emulation_help.setText("Пример: FC:CN (например 123:4567)")
            self.emulation_data.setPlaceholderText("123:4567")
        elif "Indala" in em_type:
            self.emulation_help.setText("Пример ID: 12345678")
            self.emulation_data.setPlaceholderText("12345678")
        elif "FDX-B" in em_type:
            self.emulation_help.setText("Пример: 982000000000001")
            self.emulation_data.setPlaceholderText("982000000000001")
        else:
            self.emulation_help.setText("Введите сырые данные в HEX")
            self.emulation_data.setPlaceholderText("FFFFFFFFFFFF...")
    
    def quick_emulate(self, name, cmd_base):
        """Быстрая эмуляция с предустановленными данными"""
        # Для быстрой эмуляции используем тестовые данные
        if "EM4100" in name:
            data = "1234567890"
            cmd = f"{cmd_base} --id {data}"
        elif "HID" in name:
            cmd = f"{cmd_base} --fc 123 --cn 4567"
        elif "Indala" in name:
            cmd = f"{cmd_base} --id 12345678"
        else:
            cmd = cmd_base
        
        self.append_output(f"🎭 Запуск эмуляции {name}...")
        self.start_emulation_thread(cmd)
    
    def start_emulation(self):
        """Запуск расширенной эмуляции"""
        data = self.emulation_data.text().strip()
        em_type = self.emulation_type.currentText()
        
        if not data and "HID" not in em_type:
            QMessageBox.warning(self, "Ошибка", "Введите данные для эмуляции")
            return
        
        # Формируем команду
        cmd = ""
        if "EM4100" in em_type:
            cmd = f"lf em 410x sim --id {data}"
        elif "HID" in em_type:
            if ":" in data:
                fc, cn = data.split(":")
                cmd = f"lf hid sim --fc {fc} --cn {cn}"
            else:
                cmd = f"lf hid sim --raw {data}"
        elif "Indala" in em_type:
            cmd = f"lf indala sim --id {data}"
        elif "AWID" in em_type:
            cmd = f"lf awid sim --data {data}"
        elif "Viking" in em_type:
            cmd = f"lf viking sim --data {data}"
        elif "FDX-B" in em_type:
            cmd = f"lf fdx sim --data {data}"
        else:
            cmd = f"lf cmd sim --data {data}"
        
        # Добавляем интервал и повторы
        if self.emulation_gap.value() > 0:
            cmd += f" --gap {self.emulation_gap.value()}"
        if self.emulation_repeats.value() > 0:
            cmd += f" --repeat {self.emulation_repeats.value()}"
        
        self.start_emulation_thread(cmd)
    
    def start_emulation_thread(self, cmd):
        """Запуск эмуляции в потоке"""
        if self.is_emulating:
            self.stop_emulation()
        
        self.append_output(f"🔄 Запуск эмуляции: {cmd}", "#4CAF50")
        
        self.emulation_thread = EmulationThread(self.pm3, cmd)
        self.emulation_thread.started_signal.connect(self.on_emulation_started)
        self.emulation_thread.finished_signal.connect(self.on_emulation_finished)
        self.emulation_thread.output_signal.connect(self.append_output)
        self.emulation_thread.start()
    
    def on_emulation_started(self):
        """Эмуляция началась"""
        self.is_emulating = True
        self.status_indicator.setText("🟢 Активна")
        self.status_indicator.setStyleSheet("color: #4CAF50; font-weight: bold;")
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        
        # Запускаем таймер
        self.elapsed_seconds = 0
        self.timer.start(1000)
    
    def on_emulation_finished(self):
        """Эмуляция завершена"""
        self.is_emulating = False
        self.status_indicator.setText("🔴 Не активна")
        self.status_indicator.setStyleSheet("font-weight: bold;")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.timer.stop()
        self.stopwatch.setText("00:00:00")
    
    def stop_emulation(self):
        """Остановка эмуляции"""
        if hasattr(self, 'emulation_thread') and self.emulation_thread.isRunning():
            self.emulation_thread.stop()
            self.append_output("⏹️ Эмуляция остановлена пользователем", "#FFC107")
    
    def update_timer(self):
        """Обновление таймера"""
        self.elapsed_seconds += 1
        hours = self.elapsed_seconds // 3600
        minutes = (self.elapsed_seconds % 3600) // 60
        seconds = self.elapsed_seconds % 60
        self.stopwatch.setText(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
    
    def append_output(self, text, color=None):
        """Добавление текста в вывод"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()


class EmulationThread(QThread):
    """Поток для эмуляции LF меток"""
    
    started_signal = Signal()
    finished_signal = Signal()
    output_signal = Signal(str, str)
    
    def __init__(self, pm3, command):
        super().__init__()
        self.pm3 = pm3
        self.command = command
        self.running = True
    
    def run(self):
        try:
            self.started_signal.emit()
            self.output_signal.emit(f"Выполнение: {self.command}", "#888888")
            
            # Эмуляция - блокирующая операция
            # В реальности нужно читать в реальном времени
            result = self.pm3.run_command(self.command)
            
            if result:
                self.output_signal.emit(result, None)
            
        except Exception as e:
            self.output_signal.emit(f"Ошибка: {str(e)}", "#ff5555")
        
        self.finished_signal.emit()
    
    def stop(self):
        self.running = False
        # Отправляем Ctrl+C для остановки
        self.pm3.send_command("\x03")