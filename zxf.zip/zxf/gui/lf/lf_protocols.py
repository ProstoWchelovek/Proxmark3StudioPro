# gui/lf/lf_protocols.py
"""
Панель со всеми поддерживаемыми LF протоколами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LFProtocolsPanel(QWidget):
    """Панель с кнопками для всех LF протоколов"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        info_label = QLabel("Выберите протокол для чтения метки:")
        info_label.setStyleSheet("font-size: 12px; margin-bottom: 10px;")
        layout.addWidget(info_label)
        
        # Создаём сетку с кнопками
        scroll_widget = QWidget()
        scroll_layout = QGridLayout(scroll_widget)
        scroll_layout.setSpacing(8)
        
        # Протоколы и соответствующие команды
        protocols = [
            ("🏷️ EM4100/EM4102", self.read_em4100, "125kHz EM Microelectronic"),
            ("🏷️ EM4x50", self.read_em4x50, "EM4x50 series"),
            ("🔑 HID Prox", self.read_hid, "HID 26/35/37/48 bit"),
            ("🔑 HID Corporate", self.read_hid_corp, "HID Corporate 1000"),
            ("🎯 Indala", self.read_indala, "Motorola Indala"),
            ("⚙️ T55x7", self.read_t55xx, "Atmel T55x7 configurable"),
            ("📡 AWID", self.read_awid, "AWID proximity"),
            ("🏢 Viking", self.read_viking, "Viking format"),
            ("🐄 FDX-B", self.read_fdxb, "Animal ID ISO11784/5"),
            ("🐄 HDX", self.read_hdx, "Animal ID HDX"),
            ("🔘 Hitag 1", self.read_hitag1, "NXP Hitag 1"),
            ("🔘 Hitag 2", self.read_hitag2, "NXP Hitag 2"),
            ("🔘 Hitag S", self.read_hitags, "NXP Hitag S"),
            ("💾 PCF7931", self.read_pcf7931, "PCF7931 transponder"),
            ("💾 PCF7936", self.read_pcf7936, "PCF7936 transponder"),
            ("⚡ EM4305", self.read_em4305, "EM4305"),
            ("🛡️ Nexwatch", self.read_nexwatch, "Nexwatch"),
            ("🔐 Keri", self.read_keri, "Keri MS series"),
            ("🏦 PAC/Stanley", self.read_pac, "PAC/Stanley"),
            ("📋 Presco", self.read_presco, "Presco"),
            ("🔌 IO Prox", self.read_io_prox, "IO Prox"),
            ("🔺 Pyramid", self.read_pyramid, "Pyramid"),
            ("🌏 Gallagher", self.read_gallagher, "Gallagher"),
            ("📟 Casi Russo", self.read_casi_russo, "Casi Russo"),
            ("🇳🇴 Noralsy", self.read_noralsy, "Noralsy"),
            ("🔒 Jablotron", self.read_jablotron, "Jablotron"),
            ("⚙️ Paradox", self.read_paradox, "Paradox"),
            ("🔍 Generic LF", self.read_generic, "Auto-detect"),
        ]
        
        # Располагаем кнопки в сетке 3 колонки
        row, col = 0, 0
        for name, func, tooltip in protocols:
            btn = QPushButton(name)
            btn.clicked.connect(func)
            btn.setToolTip(tooltip)
            btn.setMinimumHeight(55)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #3c3c3c;
                    border: 1px solid #555;
                    border-radius: 5px;
                    text-align: left;
                    padding: 8px;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #4a4a4a;
                    border-color: #4CAF50;
                }
            """)
            
            scroll_layout.addWidget(btn, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1
        
        # Добавляем скролл
        scroll_area = QScrollArea()
        scroll_area.setWidget(scroll_widget)
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        
        layout.addWidget(scroll_area)
        
        # Область вывода результата
        result_group = QGroupBox("Результат чтения")
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setFont(QFont("Courier New", 10))
        self.result_text.setMaximumHeight(200)
        
        result_layout.addWidget(self.result_text)
        result_group.setLayout(result_layout)
        
        layout.addWidget(result_group)
        
        self.setLayout(layout)
    
    def append_result(self, text):
        """Добавление результата"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        self.result_text.append(f"[{timestamp}] {text}")
        QApplication.processEvents()
    
    def run_command(self, cmd, description):
        """Выполнение команды с выводом результата"""
        self.append_result(f"📖 {description}...")
        output = self.pm3.run_command(cmd)
        self.append_result(output)
        self.append_result("-" * 50)
    
    def read_em4100(self):
        self.run_command("lf em 410x read", "Чтение EM4100 метки")
    
    def read_em4x50(self):
        self.run_command("lf em 4x50 read", "Чтение EM4x50 метки")
    
    def read_hid(self):
        self.run_command("lf hid read", "Чтение HID метки")
    
    def read_hid_corp(self):
        self.run_command("lf hid read --corporate", "Чтение HID Corporate метки")
    
    def read_indala(self):
        self.run_command("lf indala read", "Чтение Indala метки")
    
    def read_t55xx(self):
        self.run_command("lf t55xx dump", "Чтение T55x7 метки")
    
    def read_awid(self):
        self.run_command("lf awid read", "Чтение AWID метки")
    
    def read_viking(self):
        self.run_command("lf viking read", "Чтение Viking метки")
    
    def read_fdxb(self):
        self.run_command("lf fdx read", "Чтение FDX-B метки")
    
    def read_hdx(self):
        self.run_command("lf hdx read", "Чтение HDX метки")
    
    def read_hitag1(self):
        self.run_command("lf hitag read --tag1", "Чтение Hitag 1 метки")
    
    def read_hitag2(self):
        self.run_command("lf hitag read --tag2", "Чтение Hitag 2 метки")
    
    def read_hitags(self):
        self.run_command("lf hitag read --tags", "Чтение Hitag S метки")
    
    def read_pcf7931(self):
        self.run_command("lf pcf7931 read", "Чтение PCF7931 метки")
    
    def read_pcf7936(self):
        self.run_command("lf pcf7936 read", "Чтение PCF7936 метки")
    
    def read_em4305(self):
        self.run_command("lf em4305 dump", "Чтение EM4305 метки")
    
    def read_nexwatch(self):
        self.run_command("lf nexwatch read", "Чтение Nexwatch метки")
    
    def read_keri(self):
        self.run_command("lf keri read", "Чтение Keri метки")
    
    def read_pac(self):
        self.run_command("lf pac read", "Чтение PAC/Stanley метки")
    
    def read_presco(self):
        self.run_command("lf presco read", "Чтение Presco метки")
    
    def read_io_prox(self):
        self.run_command("lf io read", "Чтение IO Prox метки")
    
    def read_pyramid(self):
        self.run_command("lf pyramid read", "Чтение Pyramid метки")
    
    def read_gallagher(self):
        self.run_command("lf gallagher read", "Чтение Gallagher метки")
    
    def read_casi_russo(self):
        self.run_command("lf casi read", "Чтение Casi Russo метки")
    
    def read_noralsy(self):
        self.run_command("lf noralsy read", "Чтение Noralsy метки")
    
    def read_jablotron(self):
        self.run_command("lf jablotron read", "Чтение Jablotron метки")
    
    def read_paradox(self):
        self.run_command("lf paradox read", "Чтение Paradox метки")
    
    def read_generic(self):
        self.run_command("lf search", "Автоматическое определение")