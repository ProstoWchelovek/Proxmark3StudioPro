# gui/lf/lf_snoop.py
"""
Панель перехвата LF сигналов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class LFSnoopPanel(QWidget):
    """Панель перехвата LF сигналов"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.is_snooping = False
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Управление перехватом
        control_group = QGroupBox("Управление перехватом")
        control_layout = QVBoxLayout()
        
        self.snoop_btn = QPushButton("👂 НАЧАТЬ ПЕРЕХВАТ (lf snoop)")
        self.snoop_btn.clicked.connect(self.start_snoop)
        self.snoop_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 5px;
            }
        """)
        
        self.stop_btn = QPushButton("⏹️ ОСТАНОВИТЬ ПЕРЕХВАТ")
        self.stop_btn.clicked.connect(self.stop_snoop)
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 5px;
            }
        """)
        
        control_layout.addWidget(self.snoop_btn)
        control_layout.addWidget(self.stop_btn)
        control_group.setLayout(control_layout)
        
        # Настройки
        settings_group = QGroupBox("Настройки перехвата")
        settings_layout = QFormLayout()
        
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 60)
        self.timeout_spin.setValue(10)
        self.timeout_spin.setSuffix(" сек")
        
        self.trigger_spin = QSpinBox()
        self.trigger_spin.setRange(0, 100)
        self.trigger_spin.setValue(10)
        self.trigger_spin.setToolTip("Порог срабатывания")
        
        settings_layout.addRow("Таймаут:", self.timeout_spin)
        settings_layout.addRow("Порог триггера:", self.trigger_spin)
        settings_group.setLayout(settings_layout)
        
        # Статус
        status_group = QGroupBox("Статус")
        status_layout = QHBoxLayout()
        
        self.status_indicator = QLabel("🔴 Не активен")
        self.packets_count = QLabel("Пакетов: 0")
        
        status_layout.addWidget(self.status_indicator)
        status_layout.addStretch()
        status_layout.addWidget(self.packets_count)
        status_group.setLayout(status_layout)
        
        # Результаты перехвата
        result_group = QGroupBox("Результаты перехвата")
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setFont(QFont("Courier New", 10))
        
        result_layout.addWidget(self.result_text)
        result_group.setLayout(result_layout)
        
        # Кнопки действий
        action_layout = QHBoxLayout()
        
        btn_analyze = QPushButton("🔬 Анализировать")
        btn_analyze.clicked.connect(self.analyze_snoop)
        
        btn_save = QPushButton("💾 Сохранить")
        btn_save.clicked.connect(self.save_snoop)
        
        btn_clear = QPushButton("🗑️ Очистить")
        btn_clear.clicked.connect(self.clear_snoop)
        
        action_layout.addWidget(btn_analyze)
        action_layout.addWidget(btn_save)
        action_layout.addWidget(btn_clear)
        
        # Сборка
        layout.addWidget(control_group)
        layout.addWidget(settings_group)
        layout.addWidget(status_group)
        layout.addWidget(result_group)
        layout.addLayout(action_layout)
        
        self.setLayout(layout)
        
        self.packet_counter = 0
        self.snoop_thread = None
    
    def append_result(self, text, color=None):
        """Добавление текста в результат"""
        timestamp = QTime.currentTime().toString("hh:mm:ss.sss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.result_text.append(formatted)
        QApplication.processEvents()
    
    def start_snoop(self):
        """Начало перехвата"""
        self.append_result("👂 Начало перехвата LF сигналов...", "#4CAF50")
        self.append_result("Поднесите метку к ридеру или ридер к антенне")
        
        timeout = self.timeout_spin.value()
        trigger = self.trigger_spin.value()
        
        self.snoop_thread = SnoopThread(self.pm3, timeout, trigger)
        self.snoop_thread.data_received.connect(self.on_data_received)
        self.snoop_thread.snoop_finished.connect(self.on_snoop_finished)
        self.snoop_thread.start()
        
        self.is_snooping = True
        self.snoop_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.status_indicator.setText("🟡 Перехват...")
        self.packet_counter = 0
        self.packets_count.setText("Пакетов: 0")
    
    def stop_snoop(self):
        """Остановка перехвата"""
        if self.snoop_thread:
            self.snoop_thread.stop()
            self.append_result("⏹️ Перехват остановлен", "#FFC107")
        
        self.is_snooping = False
        self.snoop_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status_indicator.setText("🔴 Не активен")
    
    def on_data_received(self, data):
        """Обработка полученных данных"""
        self.packet_counter += 1
        self.packets_count.setText(f"Пакетов: {self.packet_counter}")
        
        # Ограничиваем количество отображаемых строк
        if self.packet_counter > 500:
            return
        
        self.append_result(data)
        
        # Автоматическое определение метки
        if "EM410x" in data or "EM4100" in data:
            self.append_result("🎯 Обнаружена EM4100 метка!", "#4CAF50")
        elif "HID" in data:
            self.append_result("🎯 Обнаружена HID метка!", "#4CAF50")
        elif "Indala" in data:
            self.append_result("🎯 Обнаружена Indala метка!", "#4CAF50")
        elif "FDX" in data:
            self.append_result("🎯 Обнаружена FDX-B метка!", "#4CAF50")
    
    def on_snoop_finished(self):
        """Завершение перехвата"""
        self.is_snooping = False
        self.snoop_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status_indicator.setText("🔴 Не активен")
        self.append_result("📊 Перехват завершён", "#4CAF50")
    
    def analyze_snoop(self):
        """Анализ перехваченных данных"""
        self.append_result("🔬 Анализ перехваченных данных...", "#4CAF50")
        
        text = self.result_text.toPlainText()
        
        if "EM410" in text:
            self.append_result("✅ В перехвате обнаружены EM4100 метки")
        if "HID" in text:
            self.append_result("✅ В перехвате обнаружены HID метки")
        if "Indala" in text:
            self.append_result("✅ В перехвате обнаружены Indala метки")
        if "FDX" in text:
            self.append_result("✅ В перехвате обнаружены FDX-B метки")
        
        self.append_result(f"📊 Всего пакетов: {self.packet_counter}")
    
    def save_snoop(self):
        """Сохранение перехвата в файл"""
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить перехват", "", 
                                                   "Text files (*.txt);;CSV files (*.csv);;All files (*.*)")
        if filename:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.result_text.toPlainText())
            self.append_result(f"💾 Перехват сохранён в {filename}", "#4CAF50")
    
    def clear_snoop(self):
        """Очистка перехвата"""
        self.result_text.clear()
        self.packet_counter = 0
        self.packets_count.setText("Пакетов: 0")
        self.append_result("Очищено", "#888888")


class SnoopThread(QThread):
    """Поток для перехвата LF сигналов"""
    
    data_received = Signal(str)
    snoop_finished = Signal()
    
    def __init__(self, pm3, timeout, trigger):
        super().__init__()
        self.pm3 = pm3
        self.timeout = timeout
        self.trigger = trigger
        self.running = True
    
    def run(self):
        try:
            cmd = f"lf snoop"
            if self.timeout:
                cmd += f" --timeout {self.timeout}"
            if self.trigger:
                cmd += f" --trigger {self.trigger}"
            
            self.data_received.emit(f"Выполнение: {cmd}")
            
            # Запускаем команду
            output = self.pm3.run_command(cmd)
            
            if output:
                for line in output.split('\n'):
                    if line.strip():
                        self.data_received.emit(line)
                    if not self.running:
                        break
            
        except Exception as e:
            self.data_received.emit(f"Ошибка: {str(e)}")
        
        self.snoop_finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")