# gui/lf/lf_cloning.py
"""
Панель клонирования LF меток на T55x7
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LFCloningPanel(QWidget):
    """Панель клонирования LF меток"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Группа: Тип клонирования
        type_group = QGroupBox("Тип клонирования")
        type_layout = QFormLayout()
        
        self.clone_type = QComboBox()
        self.clone_type.addItems([
            "EM4100 -> T55x7",
            "EM4100 -> T55x7 (с конфигом)",
            "HID Prox 26-bit -> T55x7",
            "HID Prox 35-bit -> T55x7",
            "HID Prox 37-bit -> T55x7",
            "Indala -> T55x7",
            "AWID -> T55x7",
            "Viking -> T55x7",
            "FDX-B -> T55x7",
            "Raw data -> T55x7",
            "Raw dump -> T55x7",
            "Custom T55x7 write"
        ])
        self.clone_type.currentIndexChanged.connect(self.on_type_changed)
        
        type_layout.addRow("Тип:", self.clone_type)
        type_group.setLayout(type_layout)
        
        # Группа: Данные для клонирования
        data_group = QGroupBox("Данные для клонирования")
        data_layout = QFormLayout()
        
        self.data_input = QLineEdit()
        self.data_input.setPlaceholderText("UID, Facility Code:Card Number, или сырые данные")
        self.data_input.setMinimumHeight(30)
        
        self.help_label = QLabel("")
        self.help_label.setStyleSheet("color: #888888; font-size: 10px;")
        
        data_layout.addRow("Данные:", self.data_input)
        data_layout.addRow("", self.help_label)
        data_group.setLayout(data_layout)
        
        # Группа: Конфигурация T55x7
        config_group = QGroupBox("Конфигурация T55x7")
        config_layout = QFormLayout()
        
        self.config_input = QLineEdit()
        self.config_input.setPlaceholderText("0x00088040 (стандарт)")
        self.config_input.setText("0x00088040")
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль (если установлен)")
        self.password_input.setEchoMode(QLineEdit.Password)
        
        config_layout.addRow("Конфигурация:", self.config_input)
        config_layout.addRow("Пароль:", self.password_input)
        config_group.setLayout(config_layout)
        
        # Группа: Опции
        options_group = QGroupBox("Опции")
        options_layout = QHBoxLayout()
        
        self.verify_check = QCheckBox("Проверить после записи")
        self.verify_check.setChecked(True)
        
        self.lock_check = QCheckBox("Заблокировать T55x7")
        self.lock_check.setToolTip("Запретить перезапись (необратимо!)")
        
        options_layout.addWidget(self.verify_check)
        options_layout.addWidget(self.lock_check)
        options_group.setLayout(options_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        # Кнопка клонирования
        self.clone_btn = QPushButton("📝 КЛОНИРОВАТЬ")
        self.clone_btn.clicked.connect(self.start_cloning)
        self.clone_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                padding: 12px;
                font-weight: bold;
                font-size: 14px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        
        # Область вывода
        output_group = QGroupBox("Результат клонирования")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(type_group)
        layout.addWidget(data_group)
        layout.addWidget(config_group)
        layout.addWidget(options_group)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.clone_btn)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
        
        # Инициализация
        self.on_type_changed()
    
    def on_type_changed(self):
        """Изменение типа клонирования"""
        clone_type = self.clone_type.currentText()
        
        if "EM4100" in clone_type:
            self.help_label.setText("Пример UID: 1A2B3C4D5E (10 символов HEX)")
            self.data_input.setPlaceholderText("1A2B3C4D5E")
        elif "HID" in clone_type:
            self.help_label.setText("Пример: FC:CN (например 123:4567)")
            self.data_input.setPlaceholderText("123:4567")
        elif "Indala" in clone_type:
            self.help_label.setText("Пример ID: 12345678")
            self.data_input.setPlaceholderText("12345678")
        elif "FDX-B" in clone_type:
            self.help_label.setText("Пример: 982000000000001")
            self.data_input.setPlaceholderText("982000000000001")
        else:
            self.help_label.setText("Введите сырые данные в HEX формате")
            self.data_input.setPlaceholderText("FFFFFFFFFFFF...")
    
    def append_output(self, text, color=None):
        """Добавление текста в вывод"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def start_cloning(self):
        """Запуск клонирования"""
        data = self.data_input.text().strip()
        if not data:
            QMessageBox.warning(self, "Ошибка", "Введите данные для клонирования")
            return
        
        clone_type = self.clone_type.currentText()
        config = self.config_input.text().strip()
        password = self.password_input.text().strip()
        
        self.append_output(f"📝 Начало клонирования: {clone_type}", "#4CAF50")
        self.append_output(f"Данные: {data}")
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(10)
        self.clone_btn.setEnabled(False)
        
        # Запуск в потоке
        self.clone_thread = CloneThread(self.pm3, clone_type, data, config, password)
        self.clone_thread.progress.connect(self.progress_bar.setValue)
        self.clone_thread.output.connect(self.append_output)
        self.clone_thread.finished.connect(self.on_cloning_finished)
        self.clone_thread.start()
    
    def on_cloning_finished(self, success):
        """Завершение клонирования"""
        self.progress_bar.setVisible(False)
        self.clone_btn.setEnabled(True)
        
        if success:
            self.append_output("✅ Клонирование завершено успешно!", "#4CAF50")
            
            if self.verify_check.isChecked():
                self.append_output("🔍 Проверка записи...")
                verify_output = self.pm3.run_command("lf t55xx dump")
                self.append_output(verify_output)
        else:
            self.append_output("❌ Ошибка при клонировании!", "#ff5555")


class CloneThread(QThread):
    """Поток для клонирования LF меток"""
    
    progress = Signal(int)
    output = Signal(str)
    finished = Signal(bool)
    
    def __init__(self, pm3, clone_type, data, config, password):
        super().__init__()
        self.pm3 = pm3
        self.clone_type = clone_type
        self.data = data
        self.config = config
        self.password = password
    
    def run(self):
        try:
            self.progress.emit(20)
            
            # Формируем команду
            if "EM4100" in self.clone_type:
                cmd = f"lf em 410x clone --uid {self.data}"
            elif "HID" in self.clone_type:
                if ":" in self.data:
                    fc, cn = self.data.split(":")
                    cmd = f"lf hid clone --fc {fc} --cn {cn}"
                else:
                    cmd = f"lf hid clone --raw {self.data}"
            elif "Indala" in self.clone_type:
                cmd = f"lf indala clone --id {self.data}"
            elif "AWID" in self.clone_type:
                cmd = f"lf awid clone --data {self.data}"
            elif "Viking" in self.clone_type:
                cmd = f"lf viking clone --data {self.data}"
            elif "FDX-B" in self.clone_type:
                cmd = f"lf fdx clone --data {self.data}"
            else:
                cmd = f"lf t55xx write --data {self.data}"
            
            # Добавляем конфигурацию
            if self.config and "0x" in self.config:
                cmd += f" --config {self.config}"
            
            # Добавляем пароль
            if self.password:
                cmd += f" --password {self.password}"
            
            # Добавляем блокировку
            if "lock" in self.clone_type.lower():
                cmd += " --lock"
            
            self.progress.emit(50)
            self.output.emit(f"Выполнение: {cmd}")
            
            result = self.pm3.run_command(cmd)
            self.output.emit(result)
            
            self.progress.emit(90)
            
            # Проверка успешности
            success = "failed" not in result.lower() and "error" not in result.lower()
            
            self.progress.emit(100)
            self.finished.emit(success)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False)