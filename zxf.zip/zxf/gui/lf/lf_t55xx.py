# gui/lf/lf_t55xx.py
"""
Панель конфигурации T55x7 меток
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LFT55xxPanel(QWidget):
    """Панель конфигурации T55x7"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Режимы T55x7
        mode_group = QGroupBox("Режим работы")
        mode_layout = QFormLayout()
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([
            "STM (стандартный)",
            "AOR",
            "HID",
            "EM",
            "Indala",
            "AWID",
            "Viking",
            "Custom"
        ])
        self.mode_combo.currentIndexChanged.connect(self.on_mode_changed)
        
        mode_layout.addRow("Режим:", self.mode_combo)
        mode_group.setLayout(mode_layout)
        
        # Конфигурация
        config_group = QGroupBox("Конфигурация")
        config_layout = QFormLayout()
        
        self.config_edit = QLineEdit()
        self.config_edit.setPlaceholderText("0x00088040")
        self.config_edit.setText("0x00088040")
        
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Пароль (если установлен)")
        self.password_edit.setEchoMode(QLineEdit.Password)
        
        config_layout.addRow("Block 0 (конфиг):", self.config_edit)
        config_layout.addRow("Пароль:", self.password_edit)
        config_group.setLayout(config_layout)
        
        # Работа с блоками
        blocks_group = QGroupBox("Работа с блоками")
        blocks_layout = QGridLayout()
        
        self.block_spin = QSpinBox()
        self.block_spin.setRange(0, 7)
        self.block_spin.setToolTip("Номер блока (0-7)")
        
        self.block_data = QLineEdit()
        self.block_data.setPlaceholderText("Данные блока (HEX)")
        self.block_data.setMaxLength(16)
        
        btn_read_block = QPushButton("📖 Прочитать блок")
        btn_read_block.clicked.connect(self.read_block)
        
        btn_write_block = QPushButton("✍️ Записать блок")
        btn_write_block.clicked.connect(self.write_block)
        
        blocks_layout.addWidget(QLabel("Блок:"), 0, 0)
        blocks_layout.addWidget(self.block_spin, 0, 1)
        blocks_layout.addWidget(QLabel("Данные:"), 1, 0)
        blocks_layout.addWidget(self.block_data, 1, 1, 1, 2)
        blocks_layout.addWidget(btn_read_block, 2, 1)
        blocks_layout.addWidget(btn_write_block, 2, 2)
        
        blocks_group.setLayout(blocks_layout)
        
        # Кнопки операций
        operations_group = QGroupBox("Операции")
        operations_layout = QGridLayout()
        
        btn_read_config = QPushButton("📖 Прочитать конфигурацию")
        btn_read_config.clicked.connect(self.read_config)
        
        btn_write_config = QPushButton("✍️ Записать конфигурацию")
        btn_write_config.clicked.connect(self.write_config)
        
        btn_detect = QPushButton("🔍 Определить конфигурацию")
        btn_detect.clicked.connect(self.detect_config)
        
        btn_reset = QPushButton("🔄 Сбросить T55x7")
        btn_reset.clicked.connect(self.reset_t55xx)
        
        btn_dump = QPushButton("💾 Сделать дамп")
        btn_dump.clicked.connect(self.dump_t55xx)
        
        operations_layout.addWidget(btn_read_config, 0, 0)
        operations_layout.addWidget(btn_write_config, 0, 1)
        operations_layout.addWidget(btn_detect, 1, 0)
        operations_layout.addWidget(btn_reset, 1, 1)
        operations_layout.addWidget(btn_dump, 2, 0, 1, 2)
        
        operations_group.setLayout(operations_layout)
        
        # Область вывода
        output_group = QGroupBox("Результат")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(mode_group)
        layout.addWidget(config_group)
        layout.addWidget(blocks_group)
        layout.addWidget(operations_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def on_mode_changed(self):
        """Изменение режима"""
        mode = self.mode_combo.currentText()
        
        configs = {
            "STM (стандартный)": "0x00088040",
            "AOR": "0x00148040",
            "HID": "0x00048040",
            "EM": "0x0008C040",
            "Indala": "0x0014C040",
            "AWID": "0x0004C040",
            "Viking": "0x0004C040",
        }
        
        if mode in configs:
            self.config_edit.setText(configs[mode])
    
    def append_output(self, text, color=None):
        """Добавление текста в вывод"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def run_t55xx_command(self, cmd, description):
        """Выполнение T55xx команды"""
        if self.password_edit.text():
            cmd += f" --password {self.password_edit.text()}"
        
        self.append_output(f"{description}...", "#4CAF50")
        output = self.pm3.run_command(cmd)
        self.append_output(output)
        return output
    
    def read_config(self):
        self.run_t55xx_command("lf t55xx read", "Чтение конфигурации T55x7")
    
    def write_config(self):
        config = self.config_edit.text()
        if not config:
            QMessageBox.warning(self, "Ошибка", "Введите конфигурацию")
            return
        self.run_t55xx_command(f"lf t55xx write --config {config}", "Запись конфигурации")
    
    def detect_config(self):
        self.run_t55xx_command("lf t55xx detect", "Определение конфигурации")
    
    def reset_t55xx(self):
        reply = QMessageBox.question(self, "Сброс", "Сбросить T55x7 в состояние по умолчанию?",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.run_t55xx_command("lf t55xx wipe", "Сброс T55x7")
    
    def dump_t55xx(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп T55x7", "", "Dump files (*.dump)")
        if filename:
            self.run_t55xx_command(f"lf t55xx dump --file {filename}", f"Сохранение дампа в {filename}")
    
    def read_block(self):
        block = self.block_spin.value()
        self.run_t55xx_command(f"lf t55xx readblock --block {block}", f"Чтение блока {block}")
    
    def write_block(self):
        block = self.block_spin.value()
        data = self.block_data.text()
        if not data:
            QMessageBox.warning(self, "Ошибка", "Введите данные блока")
            return
        self.run_t55xx_command(f"lf t55xx writeblock --block {block} --data {data}", f"Запись блока {block}")