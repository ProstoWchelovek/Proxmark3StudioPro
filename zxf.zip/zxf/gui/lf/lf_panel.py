# gui/lf/lf_panel.py
"""
Главная панель низкочастотного модуля
Объединяет все подпанели LF
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

from gui.lf.lf_search import LFSearchPanel
from gui.lf.lf_protocols import LFProtocolsPanel
from gui.lf.lf_cloning import LFCloningPanel
from gui.lf.lf_emulation import LFEmulationPanel
from gui.lf.lf_t55xx import LFT55xxPanel
from gui.lf.lf_snoop import LFSnoopPanel
from gui.lf.lf_analyzer import LFAnalyzerPanel


class LFPanel(QWidget):
    """Главная панель LF модуля"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Заголовок
        header = QLabel("🔽 НИЗКИЕ ЧАСТОТЫ (125kHz / 134kHz)")
        header.setStyleSheet("""
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #3c3c3c;
            border-radius: 5px;
        """)
        layout.addWidget(header)
        
        # Вкладки для разных режимов LF
        tabs = QTabWidget()
        tabs.setTabPosition(QTabWidget.TabPosition.North)
        tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #555;
                border-radius: 5px;
            }
            QTabBar::tab {
                padding: 8px 15px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #4CAF50;
            }
        """)
        
        # Добавляем все подпанели
        tabs.addTab(LFSearchPanel(self.pm3), "🔍 ПОИСК/ЧТЕНИЕ")
        tabs.addTab(LFProtocolsPanel(self.pm3), "📋 ПРОТОКОЛЫ")
        tabs.addTab(LFCloningPanel(self.pm3), "📝 КЛОНИРОВАНИЕ")
        tabs.addTab(LFEmulationPanel(self.pm3), "🔄 ЭМУЛЯЦИЯ")
        tabs.addTab(LFT55xxPanel(self.pm3), "⚙️ T55xx КОНФИГ")
        tabs.addTab(LFSnoopPanel(self.pm3), "👂 ПЕРЕХВАТ")
        tabs.addTab(LFAnalyzerPanel(self.pm3), "📊 АНАЛИЗ")
        
        layout.addWidget(tabs)
        self.setLayout(layout)