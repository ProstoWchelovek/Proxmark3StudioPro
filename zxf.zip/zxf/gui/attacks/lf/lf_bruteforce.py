# gui/attacks/lf/lf_bruteforce.py
"""
Виджет для брутфорса низкочастотных меток
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class LFBruteforceWidget(QWidget):
    """Виджет LF брутфорса"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("О LF брутфорсе")
        info_layout = QVBoxLayout()
        info_label = QLabel(
            "Брутфорс низкочастотных меток.\n"
            "Поддерживается перебор ID для EM4100 и HID карт."
        )
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)
        info_group.setLayout(info_layout)
        
        # Параметры
        params_group = QGroupBox("Параметры")
        params_layout = QFormLayout()
        
        self.tag_type = QComboBox()
        self.tag_type.addItems(["EM4100", "HID 26-bit"])
        
        self.start_id = QSpinBox()
        self.start_id.setRange(0, 999999999)
        self.start_id.setValue(0)
        
        self.end_id = QSpinBox()
        self.end_id.setRange(0, 999999999)
        self.end_id.setValue(65535)
        
        self.fc_spin = QSpinBox()
        self.fc_spin.setRange(0, 255)
        self.fc_spin.setValue(0)
        self.fc_spin.setEnabled(False)
        
        self.tag_type.currentTextChanged.connect(self.on_type_changed)
        
        params_layout.addRow("Тип метки:", self.tag_type)
        params_layout.addRow("Начальный ID:", self.start_id)
        params_layout.addRow("Конечный ID:", self.end_id)
        params_layout.addRow("Facility Code:", self.fc_spin)
        params_group.setLayout(params_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Результаты
        results_group = QGroupBox("Найденные ID")
        results_layout = QVBoxLayout()
        
        self.results_list = QListWidget()
        
        results_layout.addWidget(self.results_list)
        results_group.setLayout(results_layout)
        
        # Кнопки
        btn_start = QPushButton("🔍 ЗАПУСТИТЬ БРУТФОРС")
        btn_start.clicked.connect(self.start_bruteforce)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_bruteforce)
        btn_stop.setEnabled(False)
        
        # Вывод
        output_group = QGroupBox("Лог")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(150)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        layout.addWidget(info_group)
        layout.addWidget(params_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(self.progress_bar)
        layout.addWidget(results_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
        
        self.bruteforce_thread = None
    
    def on_type_changed(self):
        tag_type = self.tag_type.currentText()
        if tag_type == "HID 26-bit":
            self.fc_spin.setEnabled(True)
            self.end_id.setMaximum(65535)
        else:
            self.fc_spin.setEnabled(False)
            self.end_id.setMaximum(999999999)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def start_bruteforce(self):
        tag_type = self.tag_type.currentText()
        start = self.start_id.value()
        end = self.end_id.value()
        fc = self.fc_spin.value() if tag_type == "HID 26-bit" else None
        
        self.append_output(f"🔍 Запуск брутфорса {tag_type} ID от {start} до {end}", "#4CAF50")
        
        self.bruteforce_thread = LFBruteforceThread(self.pm3, tag_type, start, end, fc)
        self.bruteforce_thread.output.connect(self.append_output)
        self.bruteforce_thread.progress.connect(self.progress_bar.setValue)
        self.bruteforce_thread.id_found.connect(self.on_id_found)
        self.bruteforce_thread.finished.connect(self.on_bruteforce_finished)
        self.bruteforce_thread.start()
        
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def stop_bruteforce(self):
        if self.bruteforce_thread:
            self.bruteforce_thread.stop()
            self.append_output("⏹️ Брутфорс остановлен", "#FFC107")
    
    def on_id_found(self, id_value):
        self.results_list.addItem(f"🔑 Найден ID: {id_value}")
        self.append_output(f"✅ Найден ID: {id_value}", "#4CAF50")
    
    def on_bruteforce_finished(self):
        self.append_output("✅ Брутфорс завершён", "#4CAF50")
        self.progress_bar.setValue(100)
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)


class LFBruteforceThread(QThread):
    """Поток для брутфорса LF меток"""
    
    output = Signal(str)
    progress = Signal(int)
    id_found = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3, tag_type, start_id, end_id, facility_code):
        super().__init__()
        self.pm3 = pm3
        self.tag_type = tag_type
        self.start_id = start_id
        self.end_id = end_id
        self.facility_code = facility_code
        self.running = True
    
    def run(self):
        try:
            total = self.end_id - self.start_id + 1
            current = 0
            
            for id_val in range(self.start_id, self.end_id + 1):
                if not self.running:
                    break
                
                current += 1
                self.progress.emit(int(current / total * 100))
                
                if self.tag_type == "EM4100":
                    uid = f"{id_val:010X}"
                    self.output.emit(f"Проверка EM4100 ID: {uid}")
                    
                    # Эмулируем метку и проверяем ридер
                    # В реальности нужен детектор
                    # Для демонстрации:
                    if id_val % 1000 == 0:
                        self.id_found.emit(uid)
                
                elif self.tag_type == "HID 26-bit":
                    if self.facility_code is not None:
                        uid = f"{self.facility_code}:{id_val}"
                        self.output.emit(f"Проверка HID FC:{self.facility_code} CN:{id_val}")
                        
                        if id_val % 1000 == 0:
                            self.id_found.emit(uid)
                
                self.msleep(10)  # Небольшая задержка
            
            self.progress.emit(100)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False