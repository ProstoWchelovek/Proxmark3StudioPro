# gui/attacks/mifare/sniff_attack.py
"""
Sniff атака - перехват обмена между ридером и картой
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class SniffAttackWidget(QWidget):
    """Виджет Sniff атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.is_sniffing = False
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("О Sniff атаке")
        info_layout = QVBoxLayout()
        info_label = QLabel(
            "Sniff атака перехватывает обмен между ридером и картой.\n"
            "Позволяет извлечь ключи из трафика.\n\n"
            "Инструкция:\n"
            "1. Подключите антенну Proxmark3 между ридером и картой\n"
            "2. Нажмите 'Начать перехват'\n"
            "3. Приложите карту к ридеру\n"
            "4. Дождитесь завершения перехвата"
        )
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)
        info_group.setLayout(info_layout)
        
        # Кнопки
        btn_start = QPushButton("👂 НАЧАТЬ ПЕРЕХВАТ")
        btn_start.clicked.connect(self.start_sniff)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 15px; font-size: 14px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_sniff)
        btn_stop.setEnabled(False)
        
        # Статус
        self.status_label = QLabel("🔴 Не активен")
        self.status_label.setStyleSheet("font-weight: bold;")
        
        # Трассировка
        trace_group = QGroupBox("Перехваченные данные")
        trace_layout = QVBoxLayout()
        
        self.trace_text = QTextEdit()
        self.trace_text.setReadOnly(True)
        self.trace_text.setFont(QFont("Courier New", 10))
        
        trace_layout.addWidget(self.trace_text)
        trace_group.setLayout(trace_layout)
        
        # Ключи
        keys_group = QGroupBox("Найденные ключи")
        keys_layout = QVBoxLayout()
        
        self.keys_list = QListWidget()
        
        btn_save_key = QPushButton("💾 Сохранить выбранный ключ")
        btn_save_key.clicked.connect(self.save_selected_key)
        
        keys_layout.addWidget(self.keys_list)
        keys_layout.addWidget(btn_save_key)
        keys_group.setLayout(keys_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(self.status_label)
        layout.addWidget(trace_group)
        layout.addWidget(keys_group)
        
        self.setLayout(layout)
        
        self.sniff_thread = None
        self.found_keys = set()
    
    def append_trace(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.trace_text.append(formatted)
        QApplication.processEvents()
    
    def start_sniff(self):
        self.append_trace("👂 Начало перехвата...", "#4CAF50")
        self.append_trace("Поднесите карту к ридеру")
        
        self.sniff_thread = SniffThread(self.pm3)
        self.sniff_thread.data_received.connect(self.on_data_received)
        self.sniff_thread.key_found.connect(self.on_key_found)
        self.sniff_thread.finished.connect(self.on_sniff_finished)
        self.sniff_thread.start()
        
        self.is_sniffing = True
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
        self.status_label.setText("🟡 Перехват...")
    
    def stop_sniff(self):
        if self.sniff_thread:
            self.sniff_thread.stop()
            self.append_trace("⏹️ Перехват остановлен", "#FFC107")
    
    def on_data_received(self, data):
        self.append_trace(data)
        
        # Ищем ключи в трафике
        key_match = re.search(r'[0-9A-F]{12}', data, re.IGNORECASE)
        if key_match:
            key = key_match.group(0).upper()
            if key not in self.found_keys:
                self.on_key_found(key)
    
    def on_key_found(self, key):
        if key not in self.found_keys:
            self.found_keys.add(key)
            self.keys_list.addItem(f"🔑 {key}")
            self.append_trace(f"✅ Найден ключ: {key}", "#4CAF50")
    
    def on_sniff_finished(self):
        self.is_sniffing = False
        self.status_label.setText("🔴 Не активен")
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)
        self.append_trace("✅ Перехват завершён", "#4CAF50")
    
    def save_selected_key(self):
        current = self.keys_list.currentItem()
        if current:
            key = current.text().replace("🔑 ", "")
            self.key_repo.add_key(key, key_type="sniff", tags="sniff_attack")
            QMessageBox.information(self, "Сохранение", f"Ключ {key} сохранён в БД")


class SniffThread(QThread):
    """Поток для перехвата"""
    
    data_received = Signal(str)
    key_found = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        try:
            output = self.pm3.run_command("hf mf sniff")
            
            if output:
                lines = output.split('\n')
                for line in lines:
                    if not self.running:
                        break
                    if line.strip():
                        self.data_received.emit(line)
            
        except Exception as e:
            self.data_received.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")