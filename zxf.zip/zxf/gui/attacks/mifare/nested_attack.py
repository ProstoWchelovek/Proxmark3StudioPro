# gui/attacks/mifare/nested_attack.py
"""
Виджет для Nested атаки на Mifare Classic
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class NestedAttackWidget(QWidget):
    """Виджет Nested атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Параметры атаки
        params_group = QGroupBox("Параметры атаки")
        params_layout = QFormLayout()
        
        self.known_key = QLineEdit()
        self.known_key.setPlaceholderText("FFFFFFFFFFFF")
        self.known_key.setMaxLength(12)
        
        self.known_sector = QSpinBox()
        self.known_sector.setRange(0, 39)
        self.known_sector.setValue(0)
        
        self.key_type = QComboBox()
        self.key_type.addItems(["Key A", "Key B"])
        
        self.target_sectors = QLineEdit()
        self.target_sectors.setPlaceholderText("0-15,20,30-39 (оставьте пустым для всех)")
        
        params_layout.addRow("Известный ключ:", self.known_key)
        params_layout.addRow("Сектор с ключом:", self.known_sector)
        params_layout.addRow("Тип ключа:", self.key_type)
        params_layout.addRow("Целевые сектора:", self.target_sectors)
        params_group.setLayout(params_layout)
        
        # Кнопки управления
        btn_start = QPushButton("🚀 ЗАПУСТИТЬ NESTED ATTACK")
        btn_start.clicked.connect(self.start_attack)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_attack)
        btn_stop.setEnabled(False)
        
        # Таблица результатов
        results_group = QGroupBox("Результаты атаки")
        results_layout = QVBoxLayout()
        
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["Сектор", "Key A", "Key B", "Статус"])
        
        results_layout.addWidget(self.results_table)
        results_group.setLayout(results_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Вывод
        output_group = QGroupBox("Лог атаки")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(200)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(params_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(self.progress_bar)
        layout.addWidget(results_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
        
        self.attack_thread = None
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def start_attack(self):
        key = self.known_key.text().upper()
        sector = self.known_sector.value()
        key_type = "A" if self.key_type.currentText() == "Key A" else "B"
        
        if len(key) != 12:
            QMessageBox.warning(self, "Ошибка", "Введите корректный ключ (12 HEX символов)")
            return
        
        target = self.target_sectors.text().strip()
        
        self.append_output(f"🎯 Запуск Nested атаки с ключом {key} на секторе {sector} ({key_type})", "#4CAF50")
        
        self.attack_thread = NestedAttackThread(self.pm3, key, sector, key_type, target)
        self.attack_thread.output.connect(self.append_output)
        self.attack_thread.progress.connect(self.progress_bar.setValue)
        self.attack_thread.key_found.connect(self.on_key_found)
        self.attack_thread.finished.connect(self.on_attack_finished)
        self.attack_thread.start()
        
        # Обновляем UI
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def stop_attack(self):
        if self.attack_thread:
            self.attack_thread.stop()
            self.append_output("⏹️ Атака остановлена пользователем", "#FFC107")
    
    def on_key_found(self, sector, key_a, key_b):
        # Добавляем в таблицу
        if sector >= self.results_table.rowCount():
            self.results_table.setRowCount(sector + 1)
        
        self.results_table.setItem(sector, 0, QTableWidgetItem(str(sector)))
        self.results_table.setItem(sector, 1, QTableWidgetItem(key_a[:12] if key_a else "?"))
        self.results_table.setItem(sector, 2, QTableWidgetItem(key_b[:12] if key_b else "?"))
        self.results_table.setItem(sector, 3, QTableWidgetItem("✅ Найден"))
        
        # Сохраняем ключ в БД
        if key_a and key_a != "????????????":
            self.key_repo.add_or_update(key_a, key_type="nested_attack", tags="nested_attack")
        if key_b and key_b != "????????????":
            self.key_repo.add_or_update(key_b, key_type="nested_attack", tags="nested_attack")
    
    def on_attack_finished(self):
        self.append_output("✅ Nested атака завершена", "#4CAF50")
        self.progress_bar.setValue(100)
        
        # Восстанавливаем UI
        for btn in self.findChildren(QPushButton):
            if "ЗАПУСТИТЬ" in btn.text():
                btn.setEnabled(True)
            if "ОСТАНОВИТЬ" in btn.text():
                btn.setEnabled(False)


class NestedAttackThread(QThread):
    """Поток для выполнения Nested атаки"""
    
    output = Signal(str)
    progress = Signal(int)
    key_found = Signal(int, str, str)
    finished = Signal()
    
    def __init__(self, pm3, known_key, known_sector, known_key_type, target_sectors):
        super().__init__()
        self.pm3 = pm3
        self.known_key = known_key
        self.known_sector = known_sector
        self.known_key_type = known_key_type
        self.target_sectors = target_sectors
        self.running = True
    
    def run(self):
        try:
            self.progress.emit(10)
            
            # Формируем команду
            cmd = f"hf mf nested 1 0 {self.known_key} {self.known_sector} {self.known_key_type}"
            
            if self.target_sectors:
                cmd += f" t {self.target_sectors}"
            else:
                cmd += " t"
            
            self.output.emit(f"Выполнение: {cmd}")
            
            output = self.pm3.run_command(cmd)
            
            if not self.running:
                return
            
            self.progress.emit(50)
            
            # Парсим результат
            self.output.emit(output)
            
            # Ищем найденные ключи
            pattern = r'Sector\s+(\d+).*?Key A:\s*([0-9A-F?]+).*?Key B:\s*([0-9A-F?]+)'
            matches = re.findall(pattern, output, re.DOTALL)
            
            for match in matches:
                sector = int(match[0])
                key_a = match[1].strip()
                key_b = match[2].strip()
                self.key_found.emit(sector, key_a, key_b)
            
            self.progress.emit(100)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")