# gui/attacks/mifare/hardnested_attack.py
"""
Виджет для Hardnested атаки на Mifare Classic
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class HardnestedAttackWidget(QWidget):
    """Виджет Hardnested атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("О Hardnested атаке")
        info_layout = QVBoxLayout()
        info_label = QLabel(
            "Hardnested атака - оптимизированная версия Nested атаки.\n"
            "Требуется один известный ключ. Поддерживает многопоточность.\n"
            "Рекомендуется для карт с большим количеством неизвестных секторов."
        )
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)
        info_group.setLayout(info_layout)
        
        # Параметры атаки
        params_group = QGroupBox("Параметры атаки")
        params_layout = QFormLayout()
        
        self.known_key = QLineEdit()
        self.known_key.setPlaceholderText("FFFFFFFFFFFF")
        self.known_key.setMaxLength(12)
        
        self.known_sector = QSpinBox()
        self.known_sector.setRange(0, 39)
        self.known_sector.setValue(0)
        
        self.key_type = QComboBox()
        self.key_type.addItems(["Key A", "Key B"])
        
        self.target_sector = QSpinBox()
        self.target_sector.setRange(-1, 39)
        self.target_sector.setValue(-1)
        self.target_sector.setSpecialValueText("Все")
        
        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 8)
        self.threads_spin.setValue(4)
        
        params_layout.addRow("Известный ключ:", self.known_key)
        params_layout.addRow("Сектор с ключом:", self.known_sector)
        params_layout.addRow("Тип ключа:", self.key_type)
        params_layout.addRow("Целевой сектор:", self.target_sector)
        params_layout.addRow("Потоков:", self.threads_spin)
        params_group.setLayout(params_layout)
        
        # Кнопки
        btn_start = QPushButton("⚡ ЗАПУСТИТЬ HARDNESTED ATTACK")
        btn_start.clicked.connect(self.start_attack)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_attack)
        btn_stop.setEnabled(False)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Таблица результатов
        results_group = QGroupBox("Результаты атаки")
        results_layout = QVBoxLayout()
        
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["Сектор", "Key A", "Key B", "Статус"])
        
        results_layout.addWidget(self.results_table)
        results_group.setLayout(results_layout)
        
        # Вывод
        output_group = QGroupBox("Лог атаки")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        self.output_text.setMaximumHeight(150)
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(params_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(self.progress_bar)
        layout.addWidget(results_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
        
        self.attack_thread = None
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def start_attack(self):
        key = self.known_key.text().upper()
        sector = self.known_sector.value()
        key_type = "A" if self.key_type.currentText() == "Key A" else "B"
        target = self.target_sector.value() if self.target_sector.value() >= 0 else None
        threads = self.threads_spin.value()
        
        if len(key) != 12:
            QMessageBox.warning(self, "Ошибка", "Введите корректный ключ (12 HEX символов)")
            return
        
        self.append_output(f"⚡ Запуск Hardnested атаки с ключом {key}", "#4CAF50")
        self.append_output(f"Сектор с ключом: {sector} ({key_type}), потоков: {threads}")
        if target:
            self.append_output(f"Целевой сектор: {target}")
        
        self.attack_thread = HardnestedThread(self.pm3, key, sector, key_type, target, threads)
        self.attack_thread.output.connect(self.append_output)
        self.attack_thread.progress.connect(self.progress_bar.setValue)
        self.attack_thread.key_found.connect(self.on_key_found)
        self.attack_thread.finished.connect(self.on_attack_finished)
        self.attack_thread.start()
        
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def stop_attack(self):
        if self.attack_thread:
            self.attack_thread.stop()
            self.append_output("⏹️ Атака остановлена пользователем", "#FFC107")
    
    def on_key_found(self, sector, key, key_type):
        if sector >= self.results_table.rowCount():
            self.results_table.setRowCount(sector + 1)
        
        existing = self.results_table.item(sector, 1) or self.results_table.item(sector, 2)
        
        if key_type == "A":
            self.results_table.setItem(sector, 0, QTableWidgetItem(str(sector)))
            self.results_table.setItem(sector, 1, QTableWidgetItem(key))
            self.results_table.setItem(sector, 3, QTableWidgetItem("✅ Найден"))
        else:
            self.results_table.setItem(sector, 0, QTableWidgetItem(str(sector)))
            self.results_table.setItem(sector, 2, QTableWidgetItem(key))
            self.results_table.setItem(sector, 3, QTableWidgetItem("✅ Найден"))
        
        if existing is None:
            self.key_repo.add_key(key, key_type="hardnested", tags="hardnested_attack")
    
    def on_attack_finished(self):
        self.append_output("✅ Hardnested атака завершена", "#4CAF50")
        self.progress_bar.setValue(100)
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)


class HardnestedThread(QThread):
    """Поток для выполнения Hardnested атаки"""
    
    output = Signal(str)
    progress = Signal(int)
    key_found = Signal(int, str, str)
    finished = Signal()
    
    def __init__(self, pm3, known_key, known_sector, known_key_type, target_sector, threads):
        super().__init__()
        self.pm3 = pm3
        self.known_key = known_key
        self.known_sector = known_sector
        self.known_key_type = known_key_type
        self.target_sector = target_sector
        self.threads = threads
        self.running = True
    
    def run(self):
        try:
            self.progress.emit(10)
            
            cmd = f"hf mf hardnested --key {self.known_key} --sector {self.known_sector} --keytype {self.known_key_type} --threads {self.threads}"
            if self.target_sector is not None:
                cmd += f" --targsec {self.target_sector}"
            
            self.output.emit(f"Выполнение: {cmd}")
            
            output = self.pm3.run_command(cmd)
            
            if not self.running:
                return
            
            self.progress.emit(50)
            self.output.emit(output)
            
            # Парсим найденные ключи
            pattern = r'Key\s+found:\s+sector\s+(\d+),\s+key\s+([AB]):\s*([0-9A-F]{12})'
            matches = re.findall(pattern, output, re.IGNORECASE)
            
            for match in matches:
                sector = int(match[0])
                key_type = match[1].upper()
                key = match[2].upper()
                self.key_found.emit(sector, key, key_type)
            
            self.progress.emit(100)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")