# gui/attacks/mifare/darkside_attack.py
"""
Darkside атака на Mifare Classic
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class DarksideAttackWidget(QWidget):
    """Виджет Darkside атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("О Darkside атаке")
        info_layout = QVBoxLayout()
        info_label = QLabel(
            "Darkside атака использует уязвимость в проверке CRC.\n"
            "Подходит для карт с известным слабым случайным числом.\n"
            "Требуется: карта Mifare Classic 1K/4K"
        )
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)
        info_group.setLayout(info_layout)
        
        # Кнопки
        btn_start = QPushButton("🌑 ЗАПУСТИТЬ DARKSIDE ATTACK")
        btn_start.clicked.connect(self.start_attack)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 15px; font-size: 14px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_attack)
        btn_stop.setEnabled(False)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Результат
        result_group = QGroupBox("Результат атаки")
        result_layout = QVBoxLayout()
        
        self.key_found_label = QLabel("Ключ: ---")
        self.key_found_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #4CAF50;")
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setFont(QFont("Courier New", 10))
        
        btn_save = QPushButton("💾 Сохранить ключ")
        btn_save.clicked.connect(self.save_key)
        
        result_layout.addWidget(self.key_found_label)
        result_layout.addWidget(self.result_text)
        result_layout.addWidget(btn_save)
        result_group.setLayout(result_layout)
        
        # Сборка
        layout.addWidget(info_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(self.progress_bar)
        layout.addWidget(result_group)
        
        self.setLayout(layout)
        
        self.attack_thread = None
        self.found_key = None
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.result_text.append(formatted)
        QApplication.processEvents()
    
    def start_attack(self):
        self.append_output("🌑 Запуск Darkside атаки...", "#4CAF50")
        self.append_output("Атака может занять несколько минут")
        
        self.attack_thread = DarksideThread(self.pm3)
        self.attack_thread.progress.connect(self.progress_bar.setValue)
        self.attack_thread.output.connect(self.append_output)
        self.attack_thread.key_found.connect(self.on_key_found)
        self.attack_thread.finished.connect(self.on_attack_finished)
        self.attack_thread.start()
        
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def stop_attack(self):
        if self.attack_thread:
            self.attack_thread.stop()
            self.append_output("⏹️ Атака остановлена", "#FFC107")
    
    def on_key_found(self, key):
        self.found_key = key
        self.key_found_label.setText(f"🔑 Найден ключ: {key}")
        self.append_output(f"✅ Найден ключ: {key}", "#4CAF50")
    
    def on_attack_finished(self):
        self.append_output("✅ Darkside атака завершена", "#4CAF50")
        self.progress_bar.setValue(100)
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)
    
    def save_key(self):
        if self.found_key:
            self.key_repo.add_key(self.found_key, key_type="darkside", tags="darkside_attack")
            QMessageBox.information(self, "Сохранение", f"Ключ {self.found_key} сохранён в БД")
        else:
            QMessageBox.warning(self, "Ошибка", "Ключ не найден")


class DarksideThread(QThread):
    """Поток для Darkside атаки"""
    
    progress = Signal(int)
    output = Signal(str)
    key_found = Signal(str)
    finished = Signal()
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        try:
            self.progress.emit(10)
            self.output.emit("Выполнение команды: hf mf darkside")
            
            output = self.pm3.run_command("hf mf darkside")
            
            if not self.running:
                return
            
            self.progress.emit(50)
            self.output.emit(output)
            
            # Парсим ключ
            key_match = re.search(r'Found\s+key:\s*([0-9A-F]{12})', output, re.IGNORECASE)
            if key_match:
                self.key_found.emit(key_match.group(1).upper())
            
            self.progress.emit(100)
            
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
        self.pm3.send_command("\x03")