# gui/attacks/mifare/dictionary_attack.py
"""
Словарная атака - проверка ключей из словаря
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class DictionaryAttackWidget(QWidget):
    """Виджет словарной атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Выбор словаря
        dict_group = QGroupBox("Словарь ключей")
        dict_layout = QHBoxLayout()
        
        self.dict_file = QLineEdit()
        self.dict_file.setPlaceholderText("Выберите файл словаря...")
        
        btn_browse = QPushButton("📁 Обзор...")
        btn_browse.clicked.connect(self.browse_dict)
        
        dict_layout.addWidget(self.dict_file)
        dict_layout.addWidget(btn_browse)
        dict_group.setLayout(dict_layout)
        
        # Параметры
        params_group = QGroupBox("Параметры")
        params_layout = QFormLayout()
        
        self.sectors_input = QLineEdit()
        self.sectors_input.setPlaceholderText("0-15,20,30-39 (оставьте пустым для всех)")
        
        self.key_type_combo = QComboBox()
        self.key_type_combo.addItems(["Key A", "Key B", "Оба"])
        
        params_layout.addRow("Сектора:", self.sectors_input)
        params_layout.addRow("Тип ключа:", self.key_type_combo)
        params_group.setLayout(params_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Результаты
        results_group = QGroupBox("Результаты")
        results_layout = QVBoxLayout()
        
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(3)
        self.results_table.setHorizontalHeaderLabels(["Сектор", "Найденный ключ", "Тип"])
        
        results_layout.addWidget(self.results_table)
        results_group.setLayout(results_layout)
        
        # Кнопки
        btn_start = QPushButton("🔑 ЗАПУСТИТЬ СЛОВАРНУЮ АТАКУ")
        btn_start.clicked.connect(self.start_attack)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        btn_stop = QPushButton("⏹️ ОСТАНОВИТЬ")
        btn_stop.clicked.connect(self.stop_attack)
        btn_stop.setEnabled(False)
        
        btn_save = QPushButton("💾 СОХРАНИТЬ НАЙДЕННЫЕ КЛЮЧИ")
        btn_save.clicked.connect(self.save_keys)
        
        # Сборка
        layout.addWidget(dict_group)
        layout.addWidget(params_group)
        layout.addWidget(self.progress_bar)
        layout.addWidget(results_group)
        layout.addWidget(btn_start)
        layout.addWidget(btn_stop)
        layout.addWidget(btn_save)
        
        self.setLayout(layout)
        
        self.attack_thread = None
        self.found_keys = []
    
    def browse_dict(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите словарь ключей", "", 
                                                   "Dictionary files (*.dic *.txt);;All files (*.*)")
        if filename:
            self.dict_file.setText(filename)
            self.load_dictionary(filename)
    
    def load_dictionary(self, filename):
        with open(filename, 'r') as f:
            keys = [line.strip() for line in f if line.strip()]
        self.progress_bar.setMaximum(len(keys))
        self.statusBar().showMessage(f"Загружено {len(keys)} ключей")
    
    def start_attack(self):
        dict_file = self.dict_file.text()
        if not dict_file:
            QMessageBox.warning(self, "Ошибка", "Выберите словарь ключей")
            return
        
        self.append_output("🔑 Запуск словарной атаки...", "#4CAF50")
        
        self.attack_thread = DictionaryThread(self.pm3, dict_file, self.sectors_input.text())
        self.attack_thread.progress.connect(self.progress_bar.setValue)
        self.attack_thread.key_found.connect(self.on_key_found)
        self.attack_thread.finished.connect(self.on_attack_finished)
        self.attack_thread.start()
        
        self.sender().setEnabled(False)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(True)
    
    def stop_attack(self):
        if self.attack_thread:
            self.attack_thread.stop()
    
    def on_key_found(self, sector, key, key_type):
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)
        self.results_table.setItem(row, 0, QTableWidgetItem(str(sector)))
        self.results_table.setItem(row, 1, QTableWidgetItem(key))
        self.results_table.setItem(row, 2, QTableWidgetItem(key_type))
        self.found_keys.append({"sector": sector, "key": key, "type": key_type})
    
    def on_attack_finished(self):
        self.sender().setEnabled(True)
        self.findChild(QPushButton, "⏹️ ОСТАНОВИТЬ").setEnabled(False)
        self.append_output("✅ Словарная атака завершена", "#4CAF50")
    
    def save_keys(self):
        if not self.found_keys:
            QMessageBox.warning(self, "Ошибка", "Нет найденных ключей")
            return
        
        for key_info in self.found_keys:
            self.key_repo.add_key(key_info["key"], key_type="dictionary", tags=f"sector_{key_info['sector']}")
        
        QMessageBox.information(self, "Сохранение", f"Сохранено {len(self.found_keys)} ключей")


class DictionaryThread(QThread):
    """Поток для словарной атаки"""
    
    progress = Signal(int)
    key_found = Signal(int, str, str)
    finished = Signal()
    
    def __init__(self, pm3, dict_file, sectors):
        super().__init__()
        self.pm3 = pm3
        self.dict_file = dict_file
        self.sectors = sectors
        self.running = True
    
    def run(self):
        try:
            cmd = f"hf mf chk --dict {self.dict_file}"
            if self.sectors:
                cmd += f" --sectors {self.sectors}"
            
            output = self.pm3.run_command(cmd)
            
            # Парсим результат
            import re
            matches = re.findall(r'Sector\s+(\d+).*?key\s*[AB]:\s*([0-9A-F]{12})', output, re.IGNORECASE)
            for match in matches:
                if not self.running:
                    break
                sector = int(match[0])
                key = match[1].upper()
                self.key_found.emit(sector, key, "Key A")
            
        except Exception as e:
            print(f"Ошибка: {e}")
        
        self.finished.emit()
    
    def stop(self):
        self.running = False