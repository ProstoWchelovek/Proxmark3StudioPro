# gui/attacks/__init__.py
"""
Модуль атак Proxmark3 Studio Pro
"""

from gui.attacks.attack_manager import AttackManager
from gui.attacks.attack_config import AttackConfig
from gui.attacks.mifare.nested_attack import NestedAttackWidget
from gui.attacks.mifare.hardnested_attack import HardnestedAttackWidget
from gui.attacks.mifare.darkside_attack import DarksideAttackWidget
from gui.attacks.mifare.sniff_attack import SniffAttackWidget
from gui.attacks.mifare.dictionary_attack import DictionaryAttackWidget
from gui.attacks.iclass.iclass_attack import iClassAttackWidget
from gui.attacks.lf.lf_bruteforce import LFBruteforceWidget

__all__ = [
    'AttackManager',
    'AttackConfig',
    'NestedAttackWidget',
    'HardnestedAttackWidget',
    'DarksideAttackWidget',
    'SniffAttackWidget',
    'DictionaryAttackWidget',
    'iClassAttackWidget',
    'LFBruteforceWidget'
]