# gui/attacks/attack_config.py
"""
Конфигурация атак - настройки параметров для различных типов атак
"""

from dataclasses import dataclass, field
from typing import Optional, List
from enum import Enum


class KeyType(Enum):
    KEY_A = "A"
    KEY_B = "B"


class AttackType(Enum):
    NESTED = "nested"
    HARDNESTED = "hardnested"
    DARKSIDE = "darkside"
    SNIFF = "sniff"
    DICTIONARY = "dictionary"
    ICLASS = "iclass"
    LF_BRUTEFORCE = "lf_bruteforce"


@dataclass
class NestedAttackConfig:
    """Конфигурация Nested атаки"""
    known_key: str = "FFFFFFFFFFFF"
    known_sector: int = 0
    known_key_type: KeyType = KeyType.KEY_A
    target_sectors: Optional[str] = None
    timeout: int = 300
    save_found_keys: bool = True


@dataclass
class HardnestedAttackConfig:
    """Конфигурация Hardnested атаки"""
    known_key: str = "FFFFFFFFFFFF"
    known_sector: int = 0
    known_key_type: KeyType = KeyType.KEY_A
    target_sector: Optional[int] = None
    threads: int = 4
    timeout: int = 600
    save_found_keys: bool = True


@dataclass
class DarksideAttackConfig:
    """Конфигурация Darkside атаки"""
    timeout: int = 120
    save_found_keys: bool = True


@dataclass
class SniffAttackConfig:
    """Конфигурация Sniff атаки"""
    timeout: int = 60
    save_found_keys: bool = True


@dataclass
class DictionaryAttackConfig:
    """Конфигурация словарной атаки"""
    dict_file: str = ""
    sectors: Optional[str] = None
    key_type: str = "both"  # A, B, both
    timeout: int = 300
    save_found_keys: bool = True


@dataclass
class iClassAttackConfig:
    """Конфигурация iClass атаки"""
    target: str = "all"  # all, csn, config, etc.
    timeout: int = 120
    save_found_keys: bool = True


@dataclass
class LFBruteforceConfig:
    """Конфигурация LF брутфорса"""
    tag_type: str = "em4100"  # em4100, hid, indala
    start_id: int = 0
    end_id: int = 65535
    facility_code: Optional[int] = None
    timeout: int = 300


class AttackConfig:
    """Центральная конфигурация атак"""
    
    def __init__(self):
        self.nested = NestedAttackConfig()
        self.hardnested = HardnestedAttackConfig()
        self.darkside = DarksideAttackConfig()
        self.sniff = SniffAttackConfig()
        self.dictionary = DictionaryAttackConfig()
        self.iclass = iClassAttackConfig()
        self.lf_bruteforce = LFBruteforceConfig()
    
    def get_config(self, attack_type: AttackType):
        """Получение конфигурации по типу атаки"""
        configs = {
            AttackType.NESTED: self.nested,
            AttackType.HARDNESTED: self.hardnested,
            AttackType.DARKSIDE: self.darkside,
            AttackType.SNIFF: self.sniff,
            AttackType.DICTIONARY: self.dictionary,
            AttackType.ICLASS: self.iclass,
            AttackType.LF_BRUTEFORCE: self.lf_bruteforce,
        }
        return configs.get(attack_type)
    
    def to_dict(self) -> dict:
        """Конвертация в словарь для сохранения"""
        return {
            'nested': {
                'known_key': self.nested.known_key,
                'known_sector': self.nested.known_sector,
                'known_key_type': self.nested.known_key_type.value,
                'target_sectors': self.nested.target_sectors,
                'timeout': self.nested.timeout,
                'save_found_keys': self.nested.save_found_keys,
            },
            'hardnested': {
                'known_key': self.hardnested.known_key,
                'known_sector': self.hardnested.known_sector,
                'known_key_type': self.hardnested.known_key_type.value,
                'target_sector': self.hardnested.target_sector,
                'threads': self.hardnested.threads,
                'timeout': self.hardnested.timeout,
                'save_found_keys': self.hardnested.save_found_keys,
            },
            'darkside': {
                'timeout': self.darkside.timeout,
                'save_found_keys': self.darkside.save_found_keys,
            },
            'sniff': {
                'timeout': self.sniff.timeout,
                'save_found_keys': self.sniff.save_found_keys,
            },
            'dictionary': {
                'dict_file': self.dictionary.dict_file,
                'sectors': self.dictionary.sectors,
                'key_type': self.dictionary.key_type,
                'timeout': self.dictionary.timeout,
                'save_found_keys': self.dictionary.save_found_keys,
            },
        }
    
    def from_dict(self, data: dict):
        """Загрузка из словаря"""
        if 'nested' in data:
            self.nested.known_key = data['nested'].get('known_key', self.nested.known_key)
            self.nested.known_sector = data['nested'].get('known_sector', self.nested.known_sector)
            self.nested.target_sectors = data['nested'].get('target_sectors')
            self.nested.timeout = data['nested'].get('timeout', self.nested.timeout)
            self.nested.save_found_keys = data['nested'].get('save_found_keys', self.nested.save_found_keys)
        
        if 'hardnested' in data:
            self.hardnested.known_key = data['hardnested'].get('known_key', self.hardnested.known_key)
            self.hardnested.known_sector = data['hardnested'].get('known_sector', self.hardnested.known_sector)
            self.hardnested.target_sector = data['hardnested'].get('target_sector')
            self.hardnested.threads = data['hardnested'].get('threads', self.hardnested.threads)
            self.hardnested.timeout = data['hardnested'].get('timeout', self.hardnested.timeout)
            self.hardnested.save_found_keys = data['hardnested'].get('save_found_keys', self.hardnested.save_found_keys)
        
        if 'dictionary' in data:
            self.dictionary.dict_file = data['dictionary'].get('dict_file', self.dictionary.dict_file)
            self.dictionary.sectors = data['dictionary'].get('sectors')
            self.dictionary.key_type = data['dictionary'].get('key_type', self.dictionary.key_type)