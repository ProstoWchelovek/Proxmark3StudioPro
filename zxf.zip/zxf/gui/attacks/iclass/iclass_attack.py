# gui/attacks/iclass/iclass_attack.py
"""
Виджет для атак на iClass карты
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class iClassAttackWidget(QWidget):
    """Виджет iClass атаки"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Информация
        info_group = QGroupBox("О iClass атаке")
        info_layout = QVBoxLayout()
        info_label = QLabel(
            "Атаки на iClass карты.\n"
            "Поддерживается чтение CSN, дамп памяти и клонирование."
        )
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)
        info_group.setLayout(info_layout)
        
        # Кнопки действий
        actions_group = QGroupBox("Действия")
        actions_layout = QGridLayout()
        
        btn_read = QPushButton("📖 Прочитать iClass")
        btn_read.clicked.connect(self.read_card)
        
        btn_dump = QPushButton("💾 Дамп iClass")
        btn_dump.clicked.connect(self.dump_card)
        
        btn_sim = QPushButton("🎭 Эмулировать iClass")
        btn_sim.clicked.connect(self.simulate_card)
        
        btn_clone = QPushButton("📝 Клонировать iClass")
        btn_clone.clicked.connect(self.clone_card)
        
        actions_layout.addWidget(btn_read, 0, 0)
        actions_layout.addWidget(btn_dump, 0, 1)
        actions_layout.addWidget(btn_sim, 1, 0)
        actions_layout.addWidget(btn_clone, 1, 1)
        actions_group.setLayout(actions_layout)
        
        # Вывод
        output_group = QGroupBox("Вывод")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Courier New", 10))
        
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        
        layout.addWidget(info_group)
        layout.addWidget(actions_group)
        layout.addWidget(output_group)
        
        self.setLayout(layout)
    
    def append_output(self, text, color=None):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        self.output_text.append(formatted)
        QApplication.processEvents()
    
    def read_card(self):
        self.append_output("📖 Чтение iClass карты...", "#4CAF50")
        output = self.pm3.run_command("hf iclass read")
        self.append_output(output)
    
    def dump_card(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить дамп iClass", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"💾 Дамп iClass в {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass dump --file {filename}")
            self.append_output(output)
    
    def simulate_card(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп для эмуляции", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"🎭 Эмуляция iClass из {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass sim --file {filename}")
            self.append_output(output)
    
    def clone_card(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп для клонирования", "", "Dump files (*.dump)")
        if filename:
            self.append_output(f"📝 Клонирование iClass из {filename}...", "#4CAF50")
            output = self.pm3.run_command(f"hf iclass clone --file {filename}")
            self.append_output(output)