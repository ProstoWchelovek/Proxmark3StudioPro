# gui/attacks/attack_manager.py
"""
Менеджер атак - центральная панель для управления всеми типами атак
"""

from PySide6.QtWidgets import *

from gui.attacks.mifare.nested_attack import NestedAttackWidget
from gui.attacks.mifare.hardnested_attack import HardnestedAttackWidget
from gui.attacks.mifare.darkside_attack import DarksideAttackWidget
from gui.attacks.mifare.sniff_attack import SniffAttackWidget
from gui.attacks.mifare.dictionary_attack import DictionaryAttackWidget
from gui.attacks.iclass.iclass_attack import iClassAttackWidget
from gui.attacks.lf.lf_bruteforce import LFBruteforceWidget


class AttackManager(QWidget):
    """Менеджер атак - объединяет все виды атак"""
    
    def __init__(self, pm3_client, key_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.key_repo = key_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        header = QLabel("⚔️ СИСТЕМА АТАК")
        header.setStyleSheet("""
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #3c3c3c;
            border-radius: 5px;
        """)
        layout.addWidget(header)
        
        # Вкладки для разных типов атак
        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #555; border-radius: 5px; }
            QTabBar::tab { padding: 8px 15px; margin-right: 2px; }
            QTabBar::tab:selected { background-color: #4CAF50; }
        """)
        
        # Mifare атаки
        tabs.addTab(NestedAttackWidget(self.pm3, self.key_repo), "🎯 Nested Attack")
        tabs.addTab(HardnestedAttackWidget(self.pm3, self.key_repo), "⚡ Hardnested Attack")
        tabs.addTab(DarksideAttackWidget(self.pm3, self.key_repo), "🌑 Darkside Attack")
        tabs.addTab(SniffAttackWidget(self.pm3, self.key_repo), "👂 Sniff Attack")
        tabs.addTab(DictionaryAttackWidget(self.pm3, self.key_repo), "📚 Dictionary Attack")
        
        # Другие атаки
        tabs.addTab(iClassAttackWidget(self.pm3, self.key_repo), "📇 iClass Attack")
        tabs.addTab(LFBruteforceWidget(self.pm3, self.key_repo), "🔽 LF Bruteforce")
        
        layout.addWidget(tabs)
        self.setLayout(layout)