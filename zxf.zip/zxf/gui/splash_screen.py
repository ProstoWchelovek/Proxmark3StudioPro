# gui/splash_screen.py
"""
Заставка при загрузке приложения
"""

from PySide6.QtWidgets import QSplashScreen
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QPainter, QColor, QFont


class SplashScreen(QSplashScreen):
    """Заставка приложения"""
    
    def __init__(self):
        # Создаём заставку программно
        pixmap = QPixmap(600, 400)
        pixmap.fill(QColor(30, 30, 30))
        
        super().__init__(pixmap)
        
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        self.setEnabled(False)
        
        # Таймер для обновления сообщений
        self.message_timer = QTimer()
        self.message_timer.timeout.connect(self.update_message)
        self.message_index = 0
        
        self.messages = [
            "Инициализация Proxmark3 Studio Pro...",
            "Загрузка модулей...",
            "Подключение к базе данных...",
            "Загрузка GUI компонентов...",
            "Почти готово...",
            "Добро пожаловать!"
        ]
    
    def showEvent(self, event):
        """При показе заставки"""
        super().showEvent(event)
        self.message_timer.start(800)
        self.show_message(self.messages[0])
    
    def update_message(self):
        """Обновление сообщения на заставке"""
        if self.message_index < len(self.messages):
            self.show_message(self.messages[self.message_index])
            self.message_index += 1
        else:
            self.message_timer.stop()
    
    def show_message(self, message):
        """Отображение сообщения"""
        self.show()
        self.showMessage(
            message,
            Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
            QColor(200, 200, 200)
        )
        QTimer.singleShot(100, self.repaint)
    
    def drawContents(self, painter):
        """Отрисовка содержимого заставки"""
        painter.setPen(Qt.white)
        
        # Заголовок
        font = QFont("Arial", 24, QFont.Weight.Bold)
        painter.setFont(font)
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Proxmark3 Studio Pro")
        
        # Подзаголовок
        font = QFont("Arial", 10)
        painter.setFont(font)
        painter.drawText(
            self.rect().adjusted(0, 60, 0, 0),
            Qt.AlignmentFlag.AlignCenter,
            "Professional GUI for Proxmark3"
        )
        
        # Версия
        font = QFont("Arial", 8)
        painter.setFont(font)
        painter.setPen(QColor(150, 150, 150))
        painter.drawText(
            self.rect().adjusted(0, 350, 0, 0),
            Qt.AlignmentFlag.AlignCenter,
            "Version 2.0.0"
        )