# gui/navigation_panel.py
"""
Левая панель навигации с категориями и сворачиваемыми группами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class NavigationPanel(QFrame):
    """Левая панель навигации"""
    
    page_selected = Signal(int)
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.current_page = 0
    
    def setup_ui(self):
        self.setMaximumWidth(280)
        self.setMinimumWidth(250)
        self.setStyleSheet("""
            NavigationPanel {
                background-color: #2b2b2b;
                border-right: 1px solid #3c3c3c;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Заголовок с логотипом
        header = QWidget()
        header.setStyleSheet("background-color: #1e1e1e; border-bottom: 1px solid #3c3c3c;")
        header_layout = QVBoxLayout(header)
        
        logo_label = QLabel("PROXMARK3")
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_label.setStyleSheet("""
            font-size: 18px;
            font-weight: bold;
            color: #4CAF50;
            padding: 15px;
            letter-spacing: 2px;
        """)
        
        subtitle = QLabel("STUDIO PRO")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("""
            font-size: 10px;
            color: #888888;
            padding-bottom: 10px;
            letter-spacing: 3px;
        """)
        
        header_layout.addWidget(logo_label)
        header_layout.addWidget(subtitle)
        layout.addWidget(header)
        
        # Область прокрутки для навигации
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        scroll_area.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        nav_container = QWidget()
        nav_layout = QVBoxLayout(nav_container)
        nav_layout.setContentsMargins(0, 10, 0, 10)
        nav_layout.setSpacing(5)
        
        # Создание групп навигации
        self.nav_groups = []
        
        # Группа: Частоты
        freq_group = NavGroup("ЧАСТОТЫ", "📡")
        freq_group.add_item("🔽 НИЗКАЯ (LF)", 0, "125-134 kHz")
        freq_group.add_item("🔼 ВЫСОКАЯ (HF)", 1, "13.56 MHz")
        self.nav_groups.append(freq_group)
        
        # Группа: Атаки
        attacks_group = NavGroup("АТАКИ", "⚔️")
        attacks_group.add_item("🎯 Nested Attack", 2, "Атака вложенности")
        attacks_group.add_item("⚡ Hardnested", 2, "Оптимизированная")
        attacks_group.add_item("🌑 Darkside", 2, "Классическая")
        attacks_group.add_item("👂 Sniff", 2, "Перехват обмена")
        attacks_group.add_item("📚 Словарная", 2, "По словарю ключей")
        self.nav_groups.append(attacks_group)
        
        # Группа: Анализ
        analysis_group = NavGroup("АНАЛИЗ", "🔬")
        analysis_group.add_item("📊 Сигналы", 3, "Визуализация сигналов")
        analysis_group.add_item("📋 Трассировка", 4, "Анализ протоколов")
        self.nav_groups.append(analysis_group)
        
        # Группа: Управление
        management_group = NavGroup("УПРАВЛЕНИЕ", "📁")
        management_group.add_item("🔑 Ключи доступа", 5, "База ключей")
        management_group.add_item("📜 Скрипты", 6, "Lua/Python скрипты")
        management_group.add_item("💾 Дампы карт", 7, "Сохранённые дампы")
        self.nav_groups.append(management_group)
        
        # Группа: Инструменты
        tools_group = NavGroup("ИНСТРУМЕНТЫ", "🛠️")
        tools_group.add_item("🖥️ Консоль", 8, "Прямые команды")
        tools_group.add_item("⚙️ Настройки", 9, "Настройки приложения")
        tools_group.add_item("🔧 Тестирование", 9, "Диагностика")
        tools_group.add_item("📦 Пакетная обработка", 9, "Batch mode")
        self.nav_groups.append(tools_group)
        
        # Добавляем все группы в layout
        for group in self.nav_groups:
            nav_layout.addWidget(group)
            group.item_selected.connect(self.on_item_selected)
        
        nav_layout.addStretch()
        scroll_area.setWidget(nav_container)
        layout.addWidget(scroll_area)
        
        # Нижняя панель с информацией
        info_frame = QFrame()
        info_frame.setStyleSheet("""
            QFrame {
                background-color: #1e1e1e;
                border-top: 1px solid #3c3c3c;
            }
        """)
        info_layout = QVBoxLayout(info_frame)
        
        self.device_status = QLabel("⚫ Не подключён")
        self.device_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.device_status.setStyleSheet("padding: 5px; font-size: 11px;")
        
        self.version_label = QLabel("Proxmark3 Studio Pro v2.0")
        self.version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.version_label.setStyleSheet("font-size: 9px; color: #666666; padding: 5px;")
        
        info_layout.addWidget(self.device_status)
        info_layout.addWidget(self.version_label)
        
        layout.addWidget(info_frame)
    
    def on_item_selected(self, page_id, item_text):
        """Обработка выбора элемента"""
        self.page_selected.emit(page_id)
        self.current_page = page_id
    
    def set_active_page(self, page_id):
        """Установка активной страницы"""
        self.current_page = page_id
        for group in self.nav_groups:
            group.set_active(page_id)


class NavGroup(QWidget):
    """Группа навигации с возможностью сворачивания"""
    
    item_selected = Signal(int, str)
    
    def __init__(self, title, icon="📁"):
        super().__init__()
        self.title = title
        self.icon = icon
        self.is_expanded = True
        self.items = []
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Заголовок группы
        self.header_btn = QPushButton(f"{self.icon}  {self.title}")
        self.header_btn.setStyleSheet("""
            QPushButton {
                text-align: left;
                background-color: #3c3c3c;
                border: none;
                padding: 10px 15px;
                font-weight: bold;
                font-size: 11px;
                letter-spacing: 1px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
        """)
        self.header_btn.clicked.connect(self.toggle)
        layout.addWidget(self.header_btn)
        
        # Контейнер для элементов
        self.items_container = QWidget()
        self.items_layout = QVBoxLayout(self.items_container)
        self.items_layout.setContentsMargins(5, 5, 5, 5)
        self.items_layout.setSpacing(2)
        
        layout.addWidget(self.items_container)
        self.update_arrow()
    
    def add_item(self, name, page_id, tooltip=""):
        """Добавление элемента навигации"""
        btn = NavButton(name, page_id, tooltip)
        btn.clicked.connect(lambda: self.item_selected.emit(page_id, name))
        self.items_layout.addWidget(btn)
        self.items.append(btn)
    
    def toggle(self):
        """Сворачивание/разворачивание группы"""
        self.is_expanded = not self.is_expanded
        self.items_container.setVisible(self.is_expanded)
        self.update_arrow()
    
    def update_arrow(self):
        """Обновление стрелки в заголовке"""
        arrow = "▼" if self.is_expanded else "▶"
        self.header_btn.setText(f"{arrow}  {self.icon}  {self.title}")
    
    def set_active(self, page_id):
        """Установка активного элемента"""
        for item in self.items:
            item.set_active(item.page_id == page_id)


class NavButton(QPushButton):
    """Кнопка навигации"""
    
    def __init__(self, text, page_id, tooltip=""):
        super().__init__(text)
        self.page_id = page_id
        self.setCheckable(True)
        self.setToolTip(tooltip)
        self.setStyleSheet("""
            NavButton {
                text-align: left;
                background-color: transparent;
                border: none;
                padding: 8px 8px 8px 25px;
                border-radius: 4px;
                font-size: 11px;
            }
            NavButton:hover {
                background-color: #3c3c3c;
            }
            NavButton:checked {
                background-color: #4CAF50;
                color: white;
            }
        """)
    
    def set_active(self, active):
        """Установка активного состояния"""
        self.setChecked(active)