# gui/main_window.py
"""
Главное окно приложения Proxmark3 Studio Pro
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

import sys
from pathlib import Path

# Добавляем путь для импорта модулей
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.pm3_client import PM3Client
from core.script_engine import ScriptEngine
from core.hardware_detector import HardwareDetector
from database.db_manager import DatabaseManager
from database.card_repository import CardRepository
from database.key_repository import KeyRepository

from gui.navigation_panel import NavigationPanel
from gui.lf.lf_panel import LFPanel
from gui.hf.hf_panel import HFPanel
from gui.attacks.attack_manager import AttackManager
from gui.analysis.signal_viewer import SignalViewer
from gui.analysis.trace_viewer import TraceViewer
from gui.keys.key_manager import KeyManager
from gui.scripts.script_manager import ScriptManager
from gui.dumps.dump_manager import DumpManager
from gui.tools.console import ConsoleWidget
from gui.tools.firmware_updater import FirmwareUpdater
from gui.tools.hardware_test import HardwareTestDialog


class MainWindow(QMainWindow):
    """Главное окно приложения"""
    
    def __init__(self):
        super().__init__()
        
        # Инициализация ядра
        self.pm3 = PM3Client()
        self.db_manager = DatabaseManager()
        self.db_session = self.db_manager.get_session()
        self.card_repo = CardRepository(self.db_session)
        self.key_repo = KeyRepository(self.db_session)
        self.script_engine = ScriptEngine(self.pm3)
        self.hardware_detector = HardwareDetector()
        
        self.init_ui()
        self.init_connections()
        self.check_hardware()
        self.load_settings()
    
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("Proxmark3 Studio Pro v2.0")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
        
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной горизонтальный layout
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Левая панель навигации
        self.nav_panel = NavigationPanel()
        self.nav_panel.page_selected.connect(self.switch_page)
        main_layout.addWidget(self.nav_panel)
        
        # Центральная область с вкладками
        self.content_stack = QStackedWidget()
        main_layout.addWidget(self.content_stack, 1)
        
        # Создаём все панели
        self.create_panels()
        
        # Статусбар
        self.create_statusbar()
        
        # Меню
        self.create_menu()
        
        # Горячие клавиши
        self.create_shortcuts()
    
    def create_panels(self):
        """Создание всех рабочих панелей"""
        
        # Основные панели
        self.lf_panel = LFPanel(self.pm3)
        self.hf_panel = HFPanel(self.pm3)
        
        # Панели атак
        self.attack_manager = AttackManager(self.pm3, self.key_repo)
        
        # Панели анализа
        self.signal_viewer = SignalViewer(self.pm3)
        self.trace_viewer = TraceViewer(self.pm3)
        
        # Панели управления
        self.key_manager = KeyManager(self.pm3, self.key_repo)
        self.script_manager = ScriptManager(self.pm3, self.script_engine)
        self.dump_manager = DumpManager(self.pm3, self.card_repo)
        
        # Инструменты
        self.console = ConsoleWidget(self.pm3)
        
        # Добавляем в стек
        panels = [
            ("lf", self.lf_panel, "Низкая частота"),
            ("hf", self.hf_panel, "Высокая частота"),
            ("attacks", self.attack_manager, "Атаки"),
            ("signal", self.signal_viewer, "Сигналы"),
            ("trace", self.trace_viewer, "Трассировка"),
            ("keys", self.key_manager, "Ключи"),
            ("scripts", self.script_manager, "Скрипты"),
            ("dumps", self.dump_manager, "Дампы"),
            ("console", self.console, "Консоль"),
        ]
        
        for name, panel, title in panels:
            self.content_stack.addWidget(panel)
        
        # Устанавливаем первую панель
        self.content_stack.setCurrentWidget(self.lf_panel)
    
    def create_statusbar(self):
        """Создание статусбара"""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        
        # Статус подключения
        self.connection_status = QLabel("⚫ НЕ ПОДКЛЮЧЕН")
        self.connection_status.setStyleSheet("padding: 3px;")
        
        # Статус устройства
        self.device_info = QLabel("🔌 Proxmark3 не обнаружен")
        
        # Частота/режим
        self.frequency_status = QLabel("📡 -")
        
        # Индикатор занятости
        self.busy_indicator = QLabel("🟢")
        self.busy_indicator.setToolTip("Готов")
        
        # Прогрессбар для длительных операций
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setVisible(False)
        
        self.statusbar.addWidget(self.connection_status)
        self.statusbar.addWidget(self.device_info)
        self.statusbar.addWidget(self.frequency_status)
        self.statusbar.addPermanentWidget(self.busy_indicator)
        self.statusbar.addPermanentWidget(self.progress_bar)
    
    def create_menu(self):
        """Создание главного меню"""
        menubar = self.menuBar()
        
        # Файл
        file_menu = menubar.addMenu("📁 Файл")
        file_menu.addAction("📂 Импорт дампа", self.import_dump, "Ctrl+I")
        file_menu.addAction("💾 Экспорт дампа", self.export_dump, "Ctrl+E")
        file_menu.addSeparator()
        file_menu.addAction("📊 Импорт словаря ключей", self.import_dictionary)
        file_menu.addAction("💿 Экспорт базы ключей", self.export_key_database)
        file_menu.addSeparator()
        file_menu.addAction("🔄 Экспорт в JSON", self.export_to_json)
        file_menu.addAction("📥 Импорт из JSON", self.import_from_json)
        file_menu.addSeparator()
        file_menu.addAction("🚪 Выход", self.close, "Ctrl+Q")
        
        # Устройство
        device_menu = menubar.addMenu("🔌 Устройство")
        device_menu.addAction("🔍 Поиск Proxmark3", self.find_device)
        device_menu.addAction("🔄 Переподключить", self.reconnect_device, "F5")
        device_menu.addSeparator()
        device_menu.addAction("⚡ Обновить прошивку", self.update_firmware)
        device_menu.addAction("🧪 Тестирование железа", self.test_hardware)
        device_menu.addAction("ℹ️ Информация об устройстве", self.device_info_dialog)
        
        # Инструменты
        tools_menu = menubar.addMenu("🛠️ Инструменты")
        tools_menu.addAction("🔑 Генератор ключей", self.key_generator)
        tools_menu.addAction("📊 Анализатор дампов", self.dump_analyzer)
        tools_menu.addAction("🔄 Конвертер форматов", self.format_converter)
        tools_menu.addSeparator()
        tools_menu.addAction("📝 Пакетная обработка", self.batch_processor)
        
        # Вид
        view_menu = menubar.addMenu("👁️ Вид")
        view_menu.addAction("🌙 Тёмная тема", lambda: self.change_theme("dark"))
        view_menu.addAction("☀️ Светлая тема", lambda: self.change_theme("light"))
        view_menu.addSeparator()
        view_menu.addAction("🖥️ Полноэкранный режим", self.toggle_fullscreen, "F11")
        view_menu.addAction("🔄 Сбросить layout", self.reset_layout)
        
        # База данных
        db_menu = menubar.addMenu("🗄️ База данных")
        db_menu.addAction("💾 Создать резервную копию", self.backup_database)
        db_menu.addAction("📀 Восстановить из копии", self.restore_database)
        db_menu.addAction("🧹 Оптимизировать БД", self.vacuum_database)
        db_menu.addSeparator()
        db_menu.addAction("📊 Статистика БД", self.db_statistics)
        
        # Помощь
        help_menu = menubar.addMenu("❓ Помощь")
        help_menu.addAction("📖 Документация", self.show_documentation, "F1")
        help_menu.addAction("💬 О программе", self.show_about)
    
    def create_shortcuts(self):
        """Создание горячих клавиш"""
        shortcuts = {
            "Ctrl+I": self.import_dump,
            "Ctrl+E": self.export_dump,
            "Ctrl+Q": self.close,
            "F5": self.reconnect_device,
            "Ctrl+F": self.find_device,
            "F1": self.show_documentation,
            "F11": self.toggle_fullscreen,
        }
        
        for key, func in shortcuts.items():
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.activated.connect(func)
    
    def init_connections(self):
        """Инициализация соединений сигналов"""
        # Подключаем статусбар к панелям
        self.pm3.status_changed.connect(self.on_device_status_changed)
        self.pm3.progress_changed.connect(self.on_progress_changed)
    
    def switch_page(self, page_id):
        """Переключение страницы по ID"""
        # page_id соответствует индексу в content_stack
        if 0 <= page_id < self.content_stack.count():
            self.content_stack.setCurrentIndex(page_id)
            self.nav_panel.set_active_page(page_id)
    
    def check_hardware(self):
        """Проверка подключения Proxmark3"""
        if self.pm3.connect():
            self.on_device_status_changed(True)
            try:
                info = self.hardware_detector.detect(self.pm3)
                self.device_info.setText(f"🔌 {info.model.value} v{info.firmware_version}")
                self.statusbar.showMessage(f"Устройство подключено: {info.model.value}", 3000)
            except:
                self.device_info.setText("🔌 Proxmark3 (версия неизвестна)")
        else:
            self.on_device_status_changed(False)
    
    def on_device_status_changed(self, connected):
        """Обработка изменения статуса устройства"""
        if connected:
            self.connection_status.setText("🟢 ПОДКЛЮЧЕН")
            self.connection_status.setStyleSheet("color: #4CAF50; padding: 3px;")
            self.busy_indicator.setText("🟢")
            self.busy_indicator.setToolTip("Готов")
        else:
            self.connection_status.setText("🔴 НЕ ПОДКЛЮЧЕН")
            self.connection_status.setStyleSheet("color: #ff5555; padding: 3px;")
            self.device_info.setText("🔌 Proxmark3 не обнаружен")
            self.busy_indicator.setText("🔴")
            self.busy_indicator.setToolTip("Устройство не подключено")
    
    def on_progress_changed(self, value, message):
        """Обработка изменения прогресса"""
        if value > 0:
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(value)
            self.busy_indicator.setText("🟡")
            self.busy_indicator.setToolTip(message)
            
            if value >= 100:
                QTimer.singleShot(1000, lambda: self.progress_bar.setVisible(False))
                QTimer.singleShot(1000, lambda: self.busy_indicator.setText("🟢"))
        else:
            self.progress_bar.setVisible(False)
    
    def find_device(self):
        """Поиск устройства"""
        self.statusbar.showMessage("Поиск Proxmark3...")
        self.check_hardware()
    
    def reconnect_device(self):
        """Переподключение"""
        self.pm3.disconnect()
        self.check_hardware()
    
    def update_firmware(self):
        """Обновление прошивки"""
        dialog = FirmwareUpdater(self.pm3, self)
        dialog.exec()
    
    def test_hardware(self):
        """Тестирование железа"""
        dialog = HardwareTestDialog(self.pm3, self)
        dialog.exec()
    
    def device_info_dialog(self):
        """Диалог информации об устройстве"""
        if not self.pm3.is_connected:
            QMessageBox.warning(self, "Ошибка", "Устройство не подключено")
            return
        
        info = self.hardware_detector.detect(self.pm3)
        
        message = f"""
        <h3>Информация об устройстве</h3>
        <table>
        <tr><td><b>Модель:</b></td><td>{info.model.value}</td></tr>
        <tr><td><b>Версия прошивки:</b></td><td>{info.firmware_version}</td></tr>
        <tr><td><b>Commit:</b></td><td>{info.firmware_commit}</td></tr>
        <tr><td><b>Дата сборки:</b></td><td>{info.firmware_date}</td></tr>
        <tr><td><b>Flash:</b></td><td>{info.flash_size} KB</td></tr>
        <tr><td><b>RAM:</b></td><td>{info.ram_size} KB</td></tr>
        <tr><td><b>Bluetooth:</b></td><td>{"Да" if info.has_bluetooth else "Нет"}</td></tr>
        <tr><td><b>Uptime:</b></td><td>{info.uptime:.1f} сек</td></tr>
        </table>
        """
        
        QMessageBox.information(self, "Информация об устройстве", message)
    
    def import_dump(self):
        """Импорт дампа"""
        self.dump_manager.import_dump()
    
    def export_dump(self):
        """Экспорт дампа"""
        self.dump_manager.export_dump()
    
    def import_dictionary(self):
        """Импорт словаря ключей"""
        self.key_manager.import_dictionary()
    
    def export_key_database(self):
        """Экспорт базы ключей"""
        self.key_manager.export_keys()
    
    def export_to_json(self):
        """Экспорт всей БД в JSON"""
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт БД в JSON", "", "JSON files (*.json)")
        if filename:
            if self.db_manager.export_to_json(filename):
                QMessageBox.information(self, "Успех", f"База данных экспортирована в {filename}")
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось экспортировать базу данных")
    
    def import_from_json(self):
        """Импорт БД из JSON"""
        filename, _ = QFileDialog.getOpenFileName(self, "Импорт БД из JSON", "", "JSON files (*.json)")
        if filename:
            reply = QMessageBox.question(self, "Подтверждение", 
                "Импорт заменит текущие данные. Продолжить?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                if self.db_manager.import_from_json(filename):
                    QMessageBox.information(self, "Успех", "База данных импортирована")
                else:
                    QMessageBox.warning(self, "Ошибка", "Не удалось импортировать базу данных")
    
    def backup_database(self):
        """Резервное копирование БД"""
        backup_path = self.db_manager.backup()
        QMessageBox.information(self, "Резервная копия", f"Создана копия:\n{backup_path}")
    
    def restore_database(self):
        """Восстановление БД из копии"""
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите резервную копию", "", "Database files (*.db)")
        if filename:
            reply = QMessageBox.question(self, "Подтверждение", 
                "Восстановление заменит текущую базу данных. Продолжить?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                if self.db_manager.restore(filename):
                    QMessageBox.information(self, "Успех", "База данных восстановлена")
                    # Перезагружаем приложение
                    QMessageBox.information(self, "Внимание", "Перезапустите приложение для применения изменений")
                else:
                    QMessageBox.warning(self, "Ошибка", "Не удалось восстановить базу данных")
    
    def vacuum_database(self):
        """Оптимизация БД"""
        self.db_manager.vacuum()
        QMessageBox.information(self, "Оптимизация", "База данных оптимизирована")
    
    def db_statistics(self):
        """Статистика БД"""
        size = self.db_manager.get_size()
        cards_count = self.card_repo.count()
        keys_count = self.key_repo.count()
        
        message = f"""
        <h3>Статистика базы данных</h3>
        <table>
        <tr><td><b>Размер БД:</b></td><td>{size / 1024:.1f} KB</td></tr>
        <tr><td><b>Карт в базе:</b></td><td>{cards_count}</td></tr>
        <tr><td><b>Ключей в базе:</b></td><td>{keys_count}</td></tr>
        </table>
        """
        
        QMessageBox.information(self, "Статистика БД", message)
    
    def key_generator(self):
        """Генератор ключей"""
        self.key_manager.show_key_generator()
    
    def dump_analyzer(self):
        """Анализатор дампов"""
        self.dump_manager.show_analyzer()
    
    def format_converter(self):
        """Конвертер форматов"""
        # TODO: реализовать конвертер форматов
        QMessageBox.information(self, "Конвертер", "Функция в разработке")
    
    def batch_processor(self):
        """Пакетная обработка"""
        # TODO: реализовать пакетную обработку
        QMessageBox.information(self, "Пакетная обработка", "Функция в разработке")
    
    def change_theme(self, theme_name):
        """Смена темы оформления"""
        try:
            theme_path = Path(__file__).parent.parent / "resources" / "styles" / f"{theme_name}_theme.qss"
            if theme_path.exists():
                with open(theme_path, "r") as f:
                    self.setStyleSheet(f.read())
                self.statusbar.showMessage(f"Тема изменена на {theme_name}", 2000)
            else:
                # Встроенная тёмная тема
                if theme_name == "dark":
                    self.setStyleSheet("""
                        QMainWindow { background-color: #2b2b2b; }
                        QWidget { background-color: #2b2b2b; color: #d4d4d4; }
                        QPushButton { background-color: #3c3c3c; border: 1px solid #555; border-radius: 3px; padding: 5px; }
                        QPushButton:hover { background-color: #4a4a4a; }
                        QLineEdit, QTextEdit, QPlainTextEdit { background-color: #1e1e1e; border: 1px solid #555; }
                        QTableWidget { background-color: #1e1e1e; alternate-background-color: #2a2a2a; }
                        QHeaderView::section { background-color: #3c3c3c; }
                        QTabWidget::pane { border: 1px solid #555; }
                        QTabBar::tab { background-color: #3c3c3c; padding: 8px; }
                        QTabBar::tab:selected { background-color: #4CAF50; }
                        QMenuBar { background-color: #3c3c3c; }
                        QMenu { background-color: #3c3c3c; }
                        QMenu::item:selected { background-color: #4CAF50; }
                        QStatusBar { background-color: #1e1e1e; }
                        QScrollBar:vertical { background-color: #1e1e1e; width: 12px; }
                        QScrollBar::handle:vertical { background-color: #555; border-radius: 6px; }
                    """)
        except Exception as e:
            print(f"Ошибка загрузки темы: {e}")
    
    def toggle_fullscreen(self):
        """Полноэкранный режим"""
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()
    
    def reset_layout(self):
        """Сброс layout'а"""
        # TODO: сброс расположения панелей
        QMessageBox.information(self, "Сброс", "Layout сброшен")
    
    def show_documentation(self):
        """Показать документацию"""
        QMessageBox.information(self, "Документация", 
            "Документация доступна по адресу:\nhttps://github.com/yourname/proxmark3-studio-pro")
    
    def show_about(self):
        """О программе"""
        QMessageBox.about(self, "О программе",
            "<h2>Proxmark3 Studio Pro v2.0</h2>"
            "<p>Профессиональный GUI для Proxmark3</p>"
            "<p>Поддерживает все функции устройства:<br>"
            "• Низкие частоты (125kHz, 134kHz)<br>"
            "• Высокие частоты (13.56MHz)<br>"
            "• Все типы атак<br>"
            "• Анализ сигналов и трассировки<br>"
            "• Lua скрипты<br>"
            "• Управление ключами и дампами</p>"
            "<p>© 2024 Proxmark Studio Team</p>"
            "<p>Лицензия: MIT</p>")
    
    def load_settings(self):
        """Загрузка настроек"""
        settings_file = Path.home() / ".proxmark3_studio" / "settings.json"
        if settings_file.exists():
            try:
                import json
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                
                # Применяем тему
                theme = settings.get("appearance", {}).get("theme", "dark")
                self.change_theme(theme.lower())
                
            except Exception as e:
                print(f"Ошибка загрузки настроек: {e}")
        else:
            # Тема по умолчанию
            self.change_theme("dark")
    
    def closeEvent(self, event):
        """Обработка закрытия окна"""
        # Отключаемся от устройства
        if self.pm3.is_connected:
            self.pm3.disconnect()
        
        # Закрываем сессию БД
        self.db_session.close()
        
        event.accept()