# gui/dumps/dump_viewer.py
from PySide6.QtWidgets import *
from PySide6.QtGui import *
import os

class DumpViewer(QDialog):
    """Просмотр содержимого дампа карты"""
    
    def __init__(self, dump_path, parent=None):
        super().__init__(parent)
        self.dump_path = dump_path
        self.data = None
        self.init_ui()
        self.load_dump()
    
    def init_ui(self):
        self.setWindowTitle(f"Просмотр дампа: {os.path.basename(self.dump_path)}")
        self.setGeometry(200, 200, 1000, 700)
        
        layout = QVBoxLayout(self)
        
        # Панель инструментов
        toolbar = QHBoxLayout()
        
        self.offset_spin = QSpinBox()
        self.offset_spin.setRange(0, 0)
        self.offset_spin.setPrefix("Смещение: ")
        self.offset_spin.valueChanged.connect(self.goto_offset)
        
        self.hex_find = QLineEdit()
        self.hex_find.setPlaceholderText("Поиск HEX...")
        self.hex_find.returnPressed.connect(self.search_hex)
        
        btn_search = QPushButton("🔍 Найти")
        btn_search.clicked.connect(self.search_hex)
        
        btn_export = QPushButton("💾 Экспорт")
        btn_export.clicked.connect(self.export_selection)
        
        toolbar.addWidget(self.offset_spin)
        toolbar.addStretch()
        toolbar.addWidget(self.hex_find)
        toolbar.addWidget(btn_search)
        toolbar.addWidget(btn_export)
        
        layout.addLayout(toolbar)
        
        # HEX редактор
        self.hex_view = QTextEdit()
        self.hex_view.setFont(QFont("Courier New", 11))
        self.hex_view.setReadOnly(True)
        
        layout.addWidget(self.hex_view)
        
        # Информация
        info_layout = QHBoxLayout()
        self.size_label = QLabel("Размер: -")
        self.uid_label = QLabel("UID: -")
        self.type_label = QLabel("Тип: -")
        
        info_layout.addWidget(self.size_label)
        info_layout.addWidget(self.uid_label)
        info_layout.addWidget(self.type_label)
        
        layout.addLayout(info_layout)
    
    def load_dump(self):
        """Загрузка дампа"""
        try:
            with open(self.dump_path, 'rb') as f:
                self.data = f.read()
            
            self.size_label.setText(f"Размер: {len(self.data)} байт")
            self.offset_spin.setMaximum(max(0, len(self.data) - 16))
            
            # Определение UID
            if len(self.data) >= 4:
                uid = self.data[:4].hex().upper()
                self.uid_label.setText(f"UID: {uid}")
            
            # Определение типа
            self.detect_dump_type()
            
            # Отображение
            self.display_hex(0)
            
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить дамп: {e}")
    
    def detect_dump_type(self):
        """Определение типа дампа"""
        size = len(self.data)
        
        if size == 1024:
            self.type_label.setText("Тип: Mifare Classic 1K")
        elif size == 4096:
            self.type_label.setText("Тип: Mifare Classic 4K")
        elif size >= 16 and size <= 256:
            self.type_label.setText("Тип: Mifare Ultralight")
        else:
            self.type_label.setText("Тип: Неизвестный / Binary")
    
    def display_hex(self, offset):
        """Отображение HEX дампа"""
        self.hex_view.clear()
        
        bytes_per_line = 16
        lines = []
        
        for i in range(offset, min(len(self.data), offset + 4096), bytes_per_line):
            chunk = self.data[i:i + bytes_per_line]
            
            # HEX часть
            hex_part = ' '.join(f'{b:02X}' for b in chunk)
            hex_part = hex_part.ljust(bytes_per_line * 3 - 1)
            
            # ASCII часть
            ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
            
            # Форматирование с цветом
            line = f'{i:08X}  {hex_part}  |{ascii_part}|'
            
            # Подсветка UID если это первые 4 байта
            if i == 0 and offset == 0:
                line = f'<span style="color: #4CAF50; font-weight: bold;">{line}</span>'
            
            lines.append(line)
        
        html = '<pre style="font-family: Courier New; font-size: 11px;">' + '\n'.join(lines) + '</pre>'
        self.hex_view.setHtml(html)
    
    def goto_offset(self):
        """Переход к смещению"""
        self.display_hex(self.offset_spin.value())
    
    def search_hex(self):
        """Поиск HEX строки"""
        search = self.hex_find.text().replace(' ', '').upper()
        if not search:
            return
        
        try:
            search_bytes = bytes.fromhex(search)
            pos = self.data.find(search_bytes)
            
            if pos >= 0:
                self.offset_spin.setValue(pos)
                self.display_hex(pos)
                
                # Подсветка найденного
                cursor = self.hex_view.textCursor()
                # ... выделение найденного текста
                
                QMessageBox.information(self, "Поиск", f"Найдено по смещению: {pos:08X}")
            else:
                QMessageBox.warning(self, "Поиск", "Не найдено")
        except:
            QMessageBox.warning(self, "Ошибка", "Неверный HEX формат")
    
    def export_selection(self):
        """Экспорт выделенного фрагмента"""
        # Диалог выбора диапазона
        dialog = ExportRangeDialog(0, len(self.data), self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            start, end = dialog.get_range()
            
            filename, _ = QFileDialog.getSaveFileName(self, "Экспорт фрагмента", "", "Binary files (*.bin)")
            if filename:
                with open(filename, 'wb') as f:
                    f.write(self.data[start:end])
                QMessageBox.information(self, "Успех", f"Экспортировано {end-start} байт")


class ExportRangeDialog(QDialog):
    def __init__(self, max_start, max_end, parent=None):
        super().__init__(parent)
        self.max_start = max_start
        self.max_end = max_end
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Экспорт диапазона")
        layout = QFormLayout(self)
        
        self.start_spin = QSpinBox()
        self.start_spin.setRange(0, self.max_start)
        self.start_spin.setPrefix("0x")
        self.start_spin.setDisplayIntegerBase(16)
        
        self.end_spin = QSpinBox()
        self.end_spin.setRange(0, self.max_end)
        self.end_spin.setPrefix("0x")
        self.end_spin.setDisplayIntegerBase(16)
        self.end_spin.setValue(self.max_end)
        
        layout.addRow("Начало:", self.start_spin)
        layout.addRow("Конец:", self.end_spin)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
    
    def get_range(self):
        return self.start_spin.value(), self.end_spin.value()