# gui/dumps/dump_manager.py
"""
Управление дампами карт
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import os
import json
from datetime import datetime
from pathlib import Path

# Исправленные импорты
from gui.dumps.dump_viewer import DumpViewer
from gui.dumps.dump_comparator import DumpComparator
from gui.dumps.dump_analyzer import DumpAnalyzer
from gui.dumps.dump_importer import DumpImporter


class DumpManager(QWidget):
    """Управление дампами карт"""
    
    def __init__(self, pm3_client, card_repo):
        super().__init__()
        self.pm3 = pm3_client
        self.card_repo = card_repo
        self.dumps_dir = self.get_dumps_dir()
        self.init_ui()
        self.load_dumps()
    
    def get_dumps_dir(self):
        """Получение директории дампов"""
        default_dir = Path.home() / ".proxmark3_studio" / "dumps"
        default_dir.mkdir(parents=True, exist_ok=True)
        return str(default_dir)
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Панель инструментов
        toolbar = QHBoxLayout()
        
        btn_refresh = QPushButton("🔄 Обновить")
        btn_refresh.clicked.connect(self.load_dumps)
        
        btn_import = QPushButton("📁 Импорт дампа")
        btn_import.clicked.connect(self.import_dump)
        
        btn_create = QPushButton("📝 Создать дамп с карты")
        btn_create.clicked.connect(self.create_dump)
        
        btn_analyze = QPushButton("🔬 Анализ дампа")
        btn_analyze.clicked.connect(self.analyze_dump)
        
        toolbar.addWidget(btn_refresh)
        toolbar.addWidget(btn_import)
        toolbar.addWidget(btn_create)
        toolbar.addWidget(btn_analyze)
        
        layout.addLayout(toolbar)
        
        # Список дампов
        self.dumps_list = QListWidget()
        self.dumps_list.setIconSize(QSize(32, 32))
        self.dumps_list.itemClicked.connect(self.on_dump_selected)
        self.dumps_list.itemDoubleClicked.connect(self.view_dump)
        
        layout.addWidget(self.dumps_list)
        
        # Информация о выбранном дампе
        info_group = QGroupBox("Информация о дампе")
        info_layout = QFormLayout()
        
        self.dump_name = QLabel("-")
        self.dump_type = QLabel("-")
        self.dump_size = QLabel("-")
        self.dump_date = QLabel("-")
        self.dump_uid = QLabel("-")
        self.dump_note = QLabel("-")
        
        info_layout.addRow("Имя:", self.dump_name)
        info_layout.addRow("Тип:", self.dump_type)
        info_layout.addRow("Размер:", self.dump_size)
        info_layout.addRow("Дата:", self.dump_date)
        info_layout.addRow("UID:", self.dump_uid)
        info_layout.addRow("Заметки:", self.dump_note)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # Кнопки действий
        actions_layout = QHBoxLayout()
        
        btn_view = QPushButton("👁️ Просмотр")
        btn_view.clicked.connect(self.view_dump)
        
        btn_restore = QPushButton("💾 Восстановить на карту")
        btn_restore.clicked.connect(self.restore_dump)
        
        btn_export = QPushButton("📤 Экспорт")
        btn_export.clicked.connect(self.export_dump)
        
        btn_delete = QPushButton("🗑️ Удалить")
        btn_delete.clicked.connect(self.delete_dump)
        
        btn_compare = QPushButton("🔄 Сравнить")
        btn_compare.clicked.connect(self.compare_dumps)
        
        actions_layout.addWidget(btn_view)
        actions_layout.addWidget(btn_restore)
        actions_layout.addWidget(btn_export)
        actions_layout.addWidget(btn_compare)
        actions_layout.addWidget(btn_delete)
        
        layout.addLayout(actions_layout)
        
        self.setLayout(layout)
        
        self.current_dump = None
    
    def load_dumps(self):
        """Загрузка списка дампов"""
        self.dumps_list.clear()
        
        if not os.path.exists(self.dumps_dir):
            os.makedirs(self.dumps_dir)
        
        for file in sorted(os.listdir(self.dumps_dir), reverse=True):
            if file.endswith(('.dump', '.bin', '.eml', '.json')):
                item = QListWidgetItem(f"💾 {file}")
                item.setData(Qt.UserRole, os.path.join(self.dumps_dir, file))
                
                file_path = os.path.join(self.dumps_dir, file)
                size = os.path.getsize(file_path)
                item.setToolTip(f"Размер: {size} байт")
                
                self.dumps_list.addItem(item)
    
    def on_dump_selected(self, item):
        """Выбор дампа"""
        dump_path = item.data(Qt.UserRole)
        self.current_dump = dump_path
        
        self.dump_name.setText(os.path.basename(dump_path))
        self.dump_size.setText(f"{os.path.getsize(dump_path)} байт")
        
        mod_time = os.path.getmtime(dump_path)
        self.dump_date.setText(datetime.fromtimestamp(mod_time).strftime("%Y-%m-%d %H:%M:%S"))
        
        # Определение типа
        if dump_path.endswith('.dump'):
            self.dump_type.setText("Proxmark3 dump")
        elif dump_path.endswith('.bin'):
            self.dump_type.setText("Binary dump")
        elif dump_path.endswith('.eml'):
            self.dump_type.setText("EML format")
        elif dump_path.endswith('.json'):
            self.dump_type.setText("JSON format")
    
    def create_dump(self):
        """Создание дампа с карты"""
        from gui.hf.mifare.mifare_dump import MifareDumpDialog
        dialog = MifareDumpDialog(self.pm3, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_dumps()
    
    def import_dump(self):
        """Импорт дампа"""
        dialog = DumpImporter(self.card_repo, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_dumps()
    
    def view_dump(self):
        """Просмотр дампа"""
        if not self.current_dump:
            QMessageBox.warning(self, "Ошибка", "Выберите дамп")
            return
        
        viewer = DumpViewer(self.current_dump, self)
        viewer.exec()
    
    def restore_dump(self):
        """Восстановление дампа на карту"""
        if not self.current_dump:
            QMessageBox.warning(self, "Ошибка", "Выберите дамп")
            return
        
        reply = QMessageBox.question(self, "Восстановление",
            f"Восстановить дамп {os.path.basename(self.current_dump)} на карту?\n\n"
            "Убедитесь, что карта поддерживает запись!",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            from gui.hf.mifare.mifare_restore import MifareRestoreDialog
            dialog = MifareRestoreDialog(self.pm3, self)
            dialog.exec()
    
    def export_dump(self):
        """Экспорт дампа"""
        if not self.current_dump:
            QMessageBox.warning(self, "Ошибка", "Выберите дамп")
            return
        
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт дампа", "",
                                                   "Binary file (*.bin);;EML file (*.eml);;JSON file (*.json)")
        if filename:
            import shutil
            shutil.copy2(self.current_dump, filename)
            QMessageBox.information(self, "Успех", f"Дамп экспортирован: {os.path.basename(filename)}")
    
    def delete_dump(self):
        """Удаление дампа"""
        if not self.current_dump:
            QMessageBox.warning(self, "Ошибка", "Выберите дамп")
            return
        
        reply = QMessageBox.question(self, "Удаление",
            f"Удалить дамп {os.path.basename(self.current_dump)}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            os.remove(self.current_dump)
            self.load_dumps()
            self.current_dump = None
            QMessageBox.information(self, "Успех", "Дамп удалён")
    
    def analyze_dump(self):
        """Анализ дампа"""
        if not self.current_dump:
            QMessageBox.warning(self, "Ошибка", "Выберите дамп")
            return
        
        analyzer = DumpAnalyzer(self.current_dump, self)
        analyzer.exec()
    
    def compare_dumps(self):
        """Сравнение дампов"""
        comparator = DumpComparator(self)
        comparator.exec()