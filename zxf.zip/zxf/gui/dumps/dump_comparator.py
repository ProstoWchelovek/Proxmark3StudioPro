# gui/dumps/dump_comparator.py
from PySide6.QtWidgets import *
import os

class DumpComparator(QDialog):
    """Сравнение двух дампов карт"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.dump1_data = None
        self.dump2_data = None
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Сравнение дампов")
        self.setGeometry(200, 200, 1200, 800)
        
        layout = QVBoxLayout(self)
        
        # Выбор файлов
        file_layout = QHBoxLayout()
        
        # Дамп 1
        group1 = QGroupBox("Дамп 1")
        group1_layout = QVBoxLayout()
        self.file1_label = QLabel("Файл не выбран")
        btn1 = QPushButton("Выбрать...")
        btn1.clicked.connect(lambda: self.select_dump(1))
        group1_layout.addWidget(self.file1_label)
        group1_layout.addWidget(btn1)
        group1.setLayout(group1_layout)
        
        # Дамп 2
        group2 = QGroupBox("Дамп 2")
        group2_layout = QVBoxLayout()
        self.file2_label = QLabel("Файл не выбран")
        btn2 = QPushButton("Выбрать...")
        btn2.clicked.connect(lambda: self.select_dump(2))
        group2_layout.addWidget(self.file2_label)
        group2_layout.addWidget(btn2)
        group2.setLayout(group2_layout)
        
        file_layout.addWidget(group1)
        file_layout.addWidget(group2)
        
        layout.addLayout(file_layout)
        
        # Статистика сравнения
        stats_group = QGroupBox("Результаты сравнения")
        stats_layout = QVBoxLayout()
        
        self.stats_label = QLabel()
        self.stats_label.setWordWrap(True)
        stats_layout.addWidget(self.stats_label)
        
        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)
        
        # Таблица различий
        diff_group = QGroupBox("Различия")
        diff_layout = QVBoxLayout()
        
        self.diff_table = QTableWidget()
        self.diff_table.setColumnCount(4)
        self.diff_table.setHorizontalHeaderLabels(["Смещение", "Дамп 1", "Дамп 2", "Байт 1→2"])
        diff_layout.addWidget(self.diff_table)
        
        diff_group.setLayout(diff_layout)
        layout.addWidget(diff_group)
        
        # Кнопка сравнения
        btn_compare = QPushButton("🔄 СРАВНИТЬ")
        btn_compare.clicked.connect(self.compare_dumps)
        btn_compare.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        layout.addWidget(btn_compare)
    
    def select_dump(self, num):
        filename, _ = QFileDialog.getOpenFileName(self, f"Выберите дамп {num}", "", "Dump files (*.dump *.bin)")
        if filename:
            try:
                with open(filename, 'rb') as f:
                    data = f.read()
                
                if num == 1:
                    self.dump1_data = data
                    self.file1_label.setText(f"{os.path.basename(filename)} ({len(data)} байт)")
                else:
                    self.dump2_data = data
                    self.file2_label.setText(f"{os.path.basename(filename)} ({len(data)} байт)")
            except Exception as e:
                QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить: {e}")
    
    def compare_dumps(self):
        """Сравнение дампов"""
        if self.dump1_data is None or self.dump2_data is None:
            QMessageBox.warning(self, "Ошибка", "Выберите оба дампа")
            return
        
        # Статистика
        size1 = len(self.dump1_data)
        size2 = len(self.dump2_data)
        min_size = min(size1, size2)
        
        # Поиск различий
        differences = []
        for i in range(min_size):
            if self.dump1_data[i] != self.dump2_data[i]:
                differences.append((i, self.dump1_data[i], self.dump2_data[i]))
        
        # Дополнительные байты
        if size1 > size2:
            differences.append((min_size, "EOF", f"+{size1 - size2} байт"))
        elif size2 > size1:
            differences.append((min_size, f"+{size2 - size1} байт", "EOF"))
        
        # Обновление статистики
        similarity = (min_size - len([d for d in differences if isinstance(d[1], int)])) / min_size * 100 if min_size > 0 else 0
        
        self.stats_label.setText(
            f"Размер дампа 1: {size1} байт\n"
            f"Размер дампа 2: {size2} байт\n"
            f"Совпадающих байт: {min_size - len([d for d in differences if isinstance(d[1], int)])}\n"
            f"Различий: {len([d for d in differences if isinstance(d[1], int)])}\n"
            f"Сходство: {similarity:.2f}%"
        )
        
        # Таблица различий
        self.diff_table.setRowCount(len(differences))
        for row, (offset, b1, b2) in enumerate(differences[:1000]):  # Ограничение 1000 записей
            self.diff_table.setItem(row, 0, QTableWidgetItem(f"0x{offset:08X}"))
            
            if isinstance(b1, int):
                self.diff_table.setItem(row, 1, QTableWidgetItem(f"0x{b1:02X} ({b1})"))
            else:
                self.diff_table.setItem(row, 1, QTableWidgetItem(str(b1)))
            
            if isinstance(b2, int):
                self.diff_table.setItem(row, 2, QTableWidgetItem(f"0x{b2:02X} ({b2})"))
            else:
                self.diff_table.setItem(row, 2, QTableWidgetItem(str(b2)))
            
            if isinstance(b1, int) and isinstance(b2, int):
                self.diff_table.setItem(row, 3, QTableWidgetItem(f"{b1} → {b2}"))
            else:
                self.diff_table.setItem(row, 3, QTableWidgetItem("Разный размер"))
        
        if len(differences) > 1000:
            self.stats_label.setText(self.stats_label.text() + f"\n\n(Показаны первые 1000 из {len(differences)} различий)")