# gui/dumps/dump_analyzer.py
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from collections import Counter
import os

class DumpAnalyzer(QDialog):
    """Анализ структуры дампа"""
    
    def __init__(self, dump_path, parent=None):
        super().__init__(parent)
        self.dump_path = dump_path
        self.data = None
        self.init_ui()
        self.load_and_analyze()
    
    def init_ui(self):
        self.setWindowTitle(f"Анализ дампа: {os.path.basename(self.dump_path)}")
        self.setGeometry(200, 200, 800, 600)
        
        layout = QVBoxLayout(self)
        
        # Вкладки
        tabs = QTabWidget()
        
        # Вкладка: Общая информация
        tabs.addTab(self.create_info_tab(), "📊 ИНФОРМАЦИЯ")
        
        # Вкладка: Сектора
        tabs.addTab(self.create_sectors_tab(), "📁 СЕКТОРА")
        
        # Вкладка: Ключи
        tabs.addTab(self.create_keys_tab(), "🔑 КЛЮЧИ")
        
        # Вкладка: Данные
        tabs.addTab(self.create_data_tab(), "💾 ДАННЫЕ")
        
        layout.addWidget(tabs)
        
        # Кнопка экспорта отчёта
        btn_export = QPushButton("📄 ЭКСПОРТ ОТЧЁТА")
        btn_export.clicked.connect(self.export_report)
        btn_export.setStyleSheet("background-color: #2196F3; padding: 8px;")
        layout.addWidget(btn_export)
    
    def create_info_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.size_label = QLabel("-")
        self.type_label = QLabel("-")
        self.uid_label = QLabel("-")
        self.manufacturer_label = QLabel("-")
        self.entropy_label = QLabel("-")
        
        layout.addRow("Размер:", self.size_label)
        layout.addRow("Тип:", self.type_label)
        layout.addRow("UID:", self.uid_label)
        layout.addRow("Производитель:", self.manufacturer_label)
        layout.addRow("Энтропия:", self.entropy_label)
        
        return widget
    
    def create_sectors_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.sectors_table = QTableWidget()
        self.sectors_table.setColumnCount(5)
        self.sectors_table.setHorizontalHeaderLabels(["Сектор", "Блоки", "Трейлер", "Key A", "Key B"])
        
        layout.addWidget(self.sectors_table)
        return widget
    
    def create_keys_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.keys_list = QListWidget()
        layout.addWidget(self.keys_list)
        
        return widget
    
    def create_data_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.data_text = QTextEdit()
        self.data_text.setFont(QFont("Courier New", 10))
        self.data_text.setReadOnly(True)
        
        layout.addWidget(self.data_text)
        return widget
    
    def load_and_analyze(self):
        """Загрузка и анализ дампа"""
        try:
            with open(self.dump_path, 'rb') as f:
                self.data = f.read()
            
            # Общая информация
            size = len(self.data)
            self.size_label.setText(f"{size} байт ({size // 1024} KB)")
            
            # Определение типа
            if size == 1024:
                self.type_label.setText("Mifare Classic 1K (16 секторов)")
                self.analyze_mifare_classic()
            elif size == 4096:
                self.type_label.setText("Mifare Classic 4K (40 секторов)")
                self.analyze_mifare_classic()
            elif size <= 1024:
                self.type_label.setText("Mifare Ultralight / NTAG")
                self.analyze_ultralight()
            else:
                self.type_label.setText("Неизвестный формат / Binary")
                self.analyze_binary()
            
            # UID
            if len(self.data) >= 4:
                uid = self.data[:4].hex().upper()
                self.uid_label.setText(uid)
                
                # Производитель по UID
                manufacturer_byte = self.data[0]
                manufacturers = {
                    0x04: "NXP Semiconductors",
                    0x08: "NXP Semiconductors",
                    0x28: "Infineon Technologies",
                    0x30: "Gemalto",
                    0x33: "STMicroelectronics",
                }
                self.manufacturer_label.setText(manufacturers.get(manufacturer_byte, "Неизвестен"))
            
            # Энтропия
            from key_analyzer import KeyAnalyzer
            analyzer = KeyAnalyzer(None)
            entropy = analyzer.compute_entropy(self.data.hex())
            self.entropy_label.setText(f"{entropy:.4f} бит")
            
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось проанализировать: {e}")
    
    def analyze_mifare_classic(self):
        """Анализ Mifare Classic дампа"""
        sector_size = 64  # 16 блоков по 4 байта?
        # Уточнение: Mifare Classic: 16 секторов по 4 блока (1K) или 40 секторов (4K)
        
        sectors = len(self.data) // 64 if len(self.data) == 1024 else 40
        
        self.sectors_table.setRowCount(sectors)
        
        keys_found = []
        
        for sector in range(sectors):
            offset = sector * 64 + 48  # Трейлер в конце сектора
            if offset + 16 <= len(self.data):
                trailer = self.data[offset:offset + 16]
                key_a = trailer[0:6].hex().upper()
                key_b = trailer[10:16].hex().upper()
                access_bits = trailer[6:10].hex().upper()
                
                self.sectors_table.setItem(sector, 0, QTableWidgetItem(str(sector)))
                self.sectors_table.setItem(sector, 1, QTableWidgetItem("0-3" if sector < 32 else "0-15"))
                self.sectors_table.setItem(sector, 2, QTableWidgetItem(access_bits))
                self.sectors_table.setItem(sector, 3, QTableWidgetItem(key_a))
                self.sectors_table.setItem(sector, 4, QTableWidgetItem(key_b))
                
                if key_a != "FFFFFFFFFFFF":
                    keys_found.append(f"Сектор {sector} Key A: {key_a}")
                if key_b != "FFFFFFFFFFFF":
                    keys_found.append(f"Сектор {sector} Key B: {key_b}")
        
        # Список ключей
        self.keys_list.clear()
        for key in keys_found:
            self.keys_list.addItem(key)
        
        # Данные
        self.data_text.setPlainText(self.data.hex().upper())
    
    def analyze_ultralight(self):
        """Анализ Ultralight дампа"""
        pages = len(self.data) // 4
        
        self.sectors_table.setRowCount(pages)
        self.sectors_table.setHorizontalHeaderLabels(["Страница", "Данные (HEX)", "ASCII"])
        
        for page in range(pages):
            offset = page * 4
            if offset + 4 <= len(self.data):
                page_data = self.data[offset:offset + 4]
                hex_data = page_data.hex().upper()
                ascii_data = ''.join(chr(b) if 32 <= b < 127 else '.' for b in page_data)
                
                self.sectors_table.setItem(page, 0, QTableWidgetItem(str(page)))
                self.sectors_table.setItem(page, 1, QTableWidgetItem(hex_data))
                self.sectors_table.setItem(page, 2, QTableWidgetItem(ascii_data))
        
        self.data_text.setPlainText(self.data.hex().upper())
    
    def analyze_binary(self):
        """Анализ бинарных данных"""
        # Статистика байтов
        byte_counts = Counter(self.data)
        most_common = byte_counts.most_common(10)
        
        stats_text = "Наиболее частые байты:\n"
        for byte, count in most_common:
            stats_text += f"0x{byte:02X}: {count} раз ({count/len(self.data)*100:.1f}%)\n"
        
        # Поиск паттернов
        stats_text += "\nВозможные паттерны:\n"
        
        # Поиск повторяющихся последовательностей
        for pattern_len in [4, 8, 12, 16]:
            patterns = Counter()
            for i in range(len(self.data) - pattern_len):
                pattern = self.data[i:i + pattern_len]
                if pattern_len == 4:
                    patterns[pattern] += 1
            
            common_patterns = patterns.most_common(3)
            if common_patterns and common_patterns[0][1] > 2:
                for pattern, count in common_patterns[:2]:
                    stats_text += f"Повторяется {pattern.hex().upper()}: {count} раз\n"
        
        self.data_text.setPlainText(stats_text + "\n\n" + self.data.hex().upper())
    
    def export_report(self):
        """Экспорт отчёта"""
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить отчёт", "", "HTML files (*.html);;Text files (*.txt)")
        
        if filename:
            report = f"""<!DOCTYPE html>
<html>
<head><title>Анализ дампа</title></head>
<body>
<h1>Отчёт об анализе дампа</h1>
<p><b>Файл:</b> {os.path.basename(self.dump_path)}</p>
<p><b>Размер:</b> {self.size_label.text()}</p>
<p><b>Тип:</b> {self.type_label.text()}</p>
<p><b>UID:</b> {self.uid_label.text()}</p>
<p><b>Производитель:</b> {self.manufacturer_label.text()}</p>
<p><b>Энтропия:</b> {self.entropy_label.text()}</p>
</body>
</html>"""
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(report)
            
            QMessageBox.information(self, "Успех", f"Отчёт сохранён: {filename}")