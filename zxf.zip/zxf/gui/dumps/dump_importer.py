# gui/dumps/dump_importer.py
"""
Импорт дампов из различных форматов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
import os
import hashlib
from pathlib import Path


class DumpImporter(QDialog):
    """Импорт дампов карт"""
    
    def __init__(self, dump_repo, parent=None):
        super().__init__(parent)
        self.dump_repo = dump_repo
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Импорт дампа")
        self.setModal(True)
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Выбор файла
        file_group = QGroupBox("Выбор файла")
        file_layout = QHBoxLayout()
        
        self.file_path = QLineEdit()
        self.file_path.setReadOnly(True)
        
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(self.browse_file)
        
        file_layout.addWidget(self.file_path)
        file_layout.addWidget(btn_browse)
        file_group.setLayout(file_layout)
        
        # Информация о дампе
        info_group = QGroupBox("Информация о дампе")
        info_layout = QFormLayout()
        
        self.type_label = QLabel("-")
        self.size_label = QLabel("-")
        self.md5_label = QLabel("-")
        
        info_layout.addRow("Тип:", self.type_label)
        info_layout.addRow("Размер:", self.size_label)
        info_layout.addRow("MD5:", self.md5_label)
        info_group.setLayout(info_layout)
        
        # Параметры импорта
        params_group = QGroupBox("Параметры импорта")
        params_layout = QFormLayout()
        
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Имя дампа (опционально)")
        
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("Теги через запятую")
        
        params_layout.addRow("Имя:", self.name_edit)
        params_layout.addRow("Теги:", self.tags_edit)
        params_group.setLayout(params_layout)
        
        # Кнопки
        btn_import = QPushButton("📥 ИМПОРТИРОВАТЬ")
        btn_import.clicked.connect(self.import_dump)
        btn_import.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_import)
        button_layout.addWidget(btn_cancel)
        
        layout.addWidget(file_group)
        layout.addWidget(info_group)
        layout.addWidget(params_group)
        layout.addLayout(button_layout)
    
    def browse_file(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите дамп", "", 
                                                   "Dump files (*.dump *.bin *.eml);;All files (*.*)")
        if filename:
            self.file_path.setText(filename)
            self.analyze_file(filename)
    
    def analyze_file(self, filename):
        """Анализ файла дампа"""
        size = os.path.getsize(filename)
        self.size_label.setText(f"{size} байт")
        
        # MD5
        with open(filename, 'rb') as f:
            md5 = hashlib.md5(f.read()).hexdigest()
            self.md5_label.setText(md5)
        
        # Определение типа
        if size == 1024:
            self.type_label.setText("Mifare Classic 1K")
        elif size == 4096:
            self.type_label.setText("Mifare Classic 4K")
        elif size <= 512:
            self.type_label.setText("Mifare Ultralight")
        else:
            self.type_label.setText("Binary dump")
        
        # Предлагаем имя
        if not self.name_edit.text():
            self.name_edit.setText(os.path.basename(filename))
    
    def import_dump(self):
        filename = self.file_path.text()
        if not filename:
            QMessageBox.warning(self, "Ошибка", "Выберите файл")
            return
        
        # Копируем в хранилище
        dest_dir = Path.home() / ".proxmark3_studio" / "dumps"
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        import shutil
        dest_path = dest_dir / os.path.basename(filename)
        shutil.copy2(filename, dest_path)
        
        QMessageBox.information(self, "Успех", f"Дамп импортирован: {dest_path.name}")
        self.accept()