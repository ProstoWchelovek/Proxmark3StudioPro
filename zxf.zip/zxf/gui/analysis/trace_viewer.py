# gui/analysis/trace_viewer.py
"""
Просмотр и анализ трассировки протоколов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from core.trace_analyzer import TraceAnalyzer, TraceEntry, TraceDirection


class TraceViewer(QWidget):
    """Виджет для просмотра трассировки"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.analyzer = TraceAnalyzer()
        self.trace_data = []
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Панель управления
        control_layout = QHBoxLayout()
        
        self.capture_btn = QPushButton("👂 ЗАХВАТИТЬ ТРАССИРОВКУ")
        self.capture_btn.clicked.connect(self.capture_trace)
        
        self.load_btn = QPushButton("📁 ЗАГРУЗИТЬ")
        self.load_btn.clicked.connect(self.load_trace)
        
        self.save_btn = QPushButton("💾 СОХРАНИТЬ")
        self.save_btn.clicked.connect(self.save_trace)
        
        self.export_btn = QPushButton("📤 ЭКСПОРТ В WIRESHARK")
        self.export_btn.clicked.connect(self.export_to_wireshark)
        
        self.clear_btn = QPushButton("🗑️ ОЧИСТИТЬ")
        self.clear_btn.clicked.connect(self.clear_trace)
        
        control_layout.addWidget(self.capture_btn)
        control_layout.addWidget(self.load_btn)
        control_layout.addWidget(self.save_btn)
        control_layout.addWidget(self.export_btn)
        control_layout.addWidget(self.clear_btn)
        
        # Таблица трассировки
        self.trace_table = QTableWidget()
        self.trace_table.setColumnCount(5)
        self.trace_table.setHorizontalHeaderLabels(["Время", "Направление", "Протокол", "Данные", "Декодировано"])
        self.trace_table.horizontalHeader().setStretchLastSection(True)
        self.trace_table.setAlternatingRowColors(True)
        
        # Статистика
        stats_group = QGroupBox("Статистика")
        stats_layout = QHBoxLayout()
        
        self.packets_label = QLabel("Пакетов: 0")
        self.duration_label = QLabel("Длительность: 0 сек")
        self.protocol_label = QLabel("Протокол: -")
        
        stats_layout.addWidget(self.packets_label)
        stats_layout.addWidget(self.duration_label)
        stats_layout.addWidget(self.protocol_label)
        stats_group.setLayout(stats_layout)
        
        # Сборка
        layout.addLayout(control_layout)
        layout.addWidget(self.trace_table)
        layout.addWidget(stats_group)
        
        self.setLayout(layout)
    
    def capture_trace(self):
        """Захват трассировки"""
        self.append_to_table("👂 Захват трассировки...")
        
        # Запуск в потоке
        self.capture_thread = TraceCaptureThread(self.pm3)
        self.capture_thread.data_received.connect(self.on_trace_data)
        self.capture_thread.start()
    
    def on_trace_data(self, data):
        """Обработка полученных данных трассировки"""
        entries = self.analyzer.parse_trace(data)
        self.trace_data.extend(entries)
        self.update_display()
    
    def load_trace(self):
        """Загрузка трассировки из файла"""
        filename, _ = QFileDialog.getOpenFileName(self, "Загрузить трассировку", "", 
                                                   "Trace files (*.trace *.txt);;All files (*.*)")
        if filename:
            with open(filename, 'r') as f:
                content = f.read()
            self.trace_data = self.analyzer.parse_trace(content)
            self.update_display()
    
    def save_trace(self):
        """Сохранение трассировки в файл"""
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить трассировку", "", "Trace files (*.trace)")
        if filename:
            with open(filename, 'w') as f:
                for entry in self.trace_data:
                    direction = "RDR->CARD" if entry.direction == TraceDirection.READER_TO_CARD else "CARD->RDR"
                    f.write(f"[{entry.timestamp:.3f}] {direction}: {entry.data.hex()}\n")
            QMessageBox.information(self, "Успех", f"Трассировка сохранена в {filename}")
    
    def export_to_wireshark(self):
        """Экспорт в Wireshark"""
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт в Wireshark", "", "PCAP files (*.pcap)")
        if filename:
            if self.analyzer.export_to_wireshark(filename, self.trace_data):
                QMessageBox.information(self, "Успех", f"Экспортировано в {filename}")
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось экспортировать")
    
    def clear_trace(self):
        """Очистка трассировки"""
        self.trace_data.clear()
        self.trace_table.setRowCount(0)
        self.update_stats()
    
    def update_display(self):
        """Обновление отображения"""
        self.trace_table.setRowCount(len(self.trace_data))
        
        for i, entry in enumerate(self.trace_data):
            direction = "📤 RDR→CARD" if entry.direction == TraceDirection.READER_TO_CARD else "📥 CARD→RDR"
            color = "#4CAF50" if entry.direction == TraceDirection.READER_TO_CARD else "#2196F3"
            
            self.trace_table.setItem(i, 0, QTableWidgetItem(f"{entry.timestamp:.3f}"))
            self.trace_table.setItem(i, 1, QTableWidgetItem(direction))
            self.trace_table.setItem(i, 2, QTableWidgetItem(entry.protocol))
            self.trace_table.setItem(i, 3, QTableWidgetItem(entry.data.hex()[:50]))
            self.trace_table.setItem(i, 4, QTableWidgetItem(entry.decoded or ""))
            
            for col in range(5):
                item = self.trace_table.item(i, col)
                if item:
                    item.setForeground(QColor(color))
        
        self.update_stats()
    
    def update_stats(self):
        """Обновление статистики"""
        analysis = self.analyzer.analyze(self.trace_data)
        self.packets_label.setText(f"Пакетов: {analysis.total_entries}")
        self.duration_label.setText(f"Длительность: {analysis.duration:.3f} сек")
        self.protocol_label.setText(f"Протокол: {analysis.protocol}")
    
    def append_to_table(self, text):
        """Добавление текста в таблицу"""
        row = self.trace_table.rowCount()
        self.trace_table.insertRow(row)
        self.trace_table.setItem(row, 3, QTableWidgetItem(text))


class TraceCaptureThread(QThread):
    """Поток для захвата трассировки"""
    
    data_received = Signal(str)
    
    def __init__(self, pm3):
        super().__init__()
        self.pm3 = pm3
        self.running = True
    
    def run(self):
        # Включаем трассировку
        self.pm3.run_command("trace list")
        self.pm3.run_command("trace clear")
        
        # Захватываем
        output = self.pm3.run_command("hf 14a snoop")
        self.data_received.emit(output)
        
        # Получаем трассировку
        trace = self.pm3.run_command("trace list")
        self.data_received.emit(trace)