# gui/analysis/high_level_analyzer.py
"""
Высокоуровневый анализ протоколов и данных карт
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class HighLevelAnalyzer(QWidget):
    """Высокоуровневый анализатор"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Вкладки
        tabs = QTabWidget()
        
        # Анализ протокола
        protocol_tab = QWidget()
        protocol_layout = QVBoxLayout(protocol_tab)
        
        self.protocol_text = QTextEdit()
        self.protocol_text.setReadOnly(True)
        self.protocol_text.setFont(QFont("Courier New", 10))
        
        btn_analyze = QPushButton("🔬 Анализировать протокол")
        btn_analyze.clicked.connect(self.analyze_protocol)
        
        protocol_layout.addWidget(btn_analyze)
        protocol_layout.addWidget(self.protocol_text)
        
        # Анализ структуры
        structure_tab = QWidget()
        structure_layout = QVBoxLayout(structure_tab)
        
        self.structure_text = QTextEdit()
        self.structure_text.setReadOnly(True)
        self.structure_text.setFont(QFont("Courier New", 10))
        
        btn_structure = QPushButton("🏗️ Анализировать структуру")
        btn_structure.clicked.connect(self.analyze_structure)
        
        structure_layout.addWidget(btn_structure)
        structure_layout.addWidget(self.structure_text)
        
        # Отчёт
        report_tab = QWidget()
        report_layout = QVBoxLayout(report_tab)
        
        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        
        btn_report = QPushButton("📄 Сгенерировать отчёт")
        btn_report.clicked.connect(self.generate_report)
        
        btn_export = QPushButton("💾 Экспортировать отчёт")
        btn_export.clicked.connect(self.export_report)
        
        report_layout.addWidget(btn_report)
        report_layout.addWidget(btn_export)
        report_layout.addWidget(self.report_text)
        
        tabs.addTab(protocol_tab, "📡 Протокол")
        tabs.addTab(structure_tab, "🏗️ Структура")
        tabs.addTab(report_tab, "📄 Отчёт")
        
        layout.addWidget(tabs)
        self.setLayout(layout)
        
        self.card_data = None
    
    def analyze_protocol(self):
        self.protocol_text.clear()
        self.protocol_text.append("📡 Анализ протокола...")
        
        output = self.pm3.run_command("hf 14a reader")
        self.protocol_text.append(output)
        
        # Определение типа карты
        if "Mifare Classic" in output:
            self.protocol_text.append("\n✅ Определён протокол: Mifare Classic")
            self.protocol_text.append("   - Тип: NXP Mifare")
            self.protocol_text.append("   - Частота: 13.56 MHz")
            self.protocol_text.append("   - Технология: ISO14443A")
        elif "Ultralight" in output:
            self.protocol_text.append("\n✅ Определён протокол: Mifare Ultralight")
        elif "DESFire" in output:
            self.protocol_text.append("\n✅ Определён протокол: Mifare DESFire")
    
    def analyze_structure(self):
        self.structure_text.clear()
        self.structure_text.append("🏗️ Анализ структуры карты...")
        
        output = self.pm3.run_command("hf 14a reader")
        self.structure_text.append(output)
        
        # Парсинг UID
        import re
        uid_match = re.search(r"UID:\s*([0-9A-F\s]+)", output, re.IGNORECASE)
        if uid_match:
            uid = uid_match.group(1).replace(" ", "")
            self.structure_text.append(f"\n📌 UID: {uid}")
            self.structure_text.append(f"   Производитель: {self.get_manufacturer(uid[:2])}")
    
    def get_manufacturer(self, byte):
        manufacturers = {
            "04": "NXP Semiconductors",
            "08": "NXP Semiconductors",
            "44": "NXP Semiconductors (Ultralight C)",
            "28": "Infineon Technologies",
        }
        return manufacturers.get(byte, "Unknown")
    
    def generate_report(self):
        self.report_text.clear()
        self.report_text.setHtml("""
        <h2>Отчёт об анализе карты</h2>
        <h3>Proxmark3 Studio Pro v2.0</h3>
        <hr>
        <p><b>Дата анализа:</b> {date}</p>
        <p><b>Тип карты:</b> Mifare Classic</p>
        <p><b>UID:</b> 04 12 34 56</p>
        <p><b>Производитель:</b> NXP Semiconductors</p>
        <p><b>Частота:</b> 13.56 MHz</p>
        <hr>
        <h3>Заключение</h3>
        <p>Карта определена как Mifare Classic. Рекомендуется проверить наличие стандартных ключей.</p>
        """.format(date=QDate.currentDate().toString("yyyy-MM-dd")))
    
    def export_report(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить отчёт", "", "HTML files (*.html)")
        if filename:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.report_text.toHtml())
            QMessageBox.information(self, "Успех", f"Отчёт сохранён в {filename}")