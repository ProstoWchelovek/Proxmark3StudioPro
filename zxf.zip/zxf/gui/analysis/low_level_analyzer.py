# gui/analysis/low_level_analyzer.py
"""
Низкоуровневый анализ сигналов и сырых данных
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import numpy as np


class LowLevelAnalyzer(QWidget):
    """Низкоуровневый анализ сигналов"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.raw_data = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Вкладки
        tabs = QTabWidget()
        
        # Сырые данные
        raw_tab = QWidget()
        raw_layout = QVBoxLayout(raw_tab)
        
        self.raw_text = QTextEdit()
        self.raw_text.setFont(QFont("Courier New", 10))
        
        btn_load_raw = QPushButton("📁 Загрузить сырые данные")
        btn_load_raw.clicked.connect(self.load_raw_data)
        
        raw_layout.addWidget(btn_load_raw)
        raw_layout.addWidget(self.raw_text)
        
        # Анализ битов
        bits_tab = QWidget()
        bits_layout = QVBoxLayout(bits_tab)
        
        self.bits_text = QTextEdit()
        self.bits_text.setFont(QFont("Courier New", 10))
        self.bits_text.setReadOnly(True)
        
        btn_analyze = QPushButton("🔬 Анализировать")
        btn_analyze.clicked.connect(self.analyze_bits)
        
        bits_layout.addWidget(btn_analyze)
        bits_layout.addWidget(self.bits_text)
        
        # Манчестер декодирование
        manchester_tab = QWidget()
        manchester_layout = QVBoxLayout(manchester_tab)
        
        self.manchester_input = QTextEdit()
        self.manchester_input.setPlaceholderText("Введите биты для декодирования...")
        self.manchester_input.setMaximumHeight(100)
        
        btn_decode = QPushButton("🔄 Декодировать Manchester")
        btn_decode.clicked.connect(self.decode_manchester)
        
        self.manchester_output = QTextEdit()
        self.manchester_output.setReadOnly(True)
        
        manchester_layout.addWidget(self.manchester_input)
        manchester_layout.addWidget(btn_decode)
        manchester_layout.addWidget(self.manchester_output)
        
        # Добавляем вкладки
        tabs.addTab(raw_tab, "📄 Сырые данные")
        tabs.addTab(bits_tab, "🔬 Анализ битов")
        tabs.addTab(manchester_tab, "🔄 Manchester")
        
        layout.addWidget(tabs)
        self.setLayout(layout)
    
    def load_raw_data(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Загрузить сырые данные", "", 
                                                   "Text files (*.txt);;Binary files (*.bin);;All files (*.*)")
        if filename:
            with open(filename, 'r') as f:
                self.raw_text.setText(f.read())
    
    def analyze_bits(self):
        text = self.raw_text.toPlainText()
        # Ищем бинарные строки
        import re
        bits = re.findall(r'[01]{8,}', text)
        
        self.bits_text.clear()
        for i, bit_str in enumerate(bits):
            self.bits_text.append(f"=== Строка {i+1} ({len(bit_str)} бит) ===")
            self.bits_text.append(bit_str)
            self.bits_text.append(f"HEX: {self.bits_to_hex(bit_str)}")
            self.bits_text.append("")
    
    def bits_to_hex(self, bits):
        hex_str = ''
        for i in range(0, len(bits), 4):
            byte = bits[i:i+4]
            if len(byte) == 4:
                hex_str += f'{int(byte, 2):X}'
        return hex_str
    
    def decode_manchester(self):
        bits = self.manchester_input.toPlainText().replace(' ', '').replace('\n', '')
        decoded = []
        
        for i in range(0, len(bits) - 1, 2):
            if bits[i] == '0' and bits[i+1] == '1':
                decoded.append('0')
            elif bits[i] == '1' and bits[i+1] == '0':
                decoded.append('1')
        
        self.manchester_output.setText(''.join(decoded))