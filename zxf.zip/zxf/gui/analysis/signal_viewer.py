# gui/analysis/signal_viewer.py
"""
Визуализация и анализ сигналов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import numpy as np

try:
    import pyqtgraph as pg
    PG_AVAILABLE = True
except ImportError:
    PG_AVAILABLE = False
    pg = None


class SignalViewer(QWidget):
    """Визуализация сигналов Proxmark3"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.samples = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Панель управления
        control_layout = QHBoxLayout()
        
        self.freq_combo = QComboBox()
        self.freq_combo.addItems(["LF (125 kHz)", "HF (13.56 MHz)", "Auto"])
        
        self.capture_btn = QPushButton("📡 ЗАХВАТИТЬ")
        self.capture_btn.clicked.connect(self.capture_signal)
        
        self.zoom_spin = QDoubleSpinBox()
        self.zoom_spin.setRange(0.1, 10)
        self.zoom_spin.setValue(1)
        self.zoom_spin.setSuffix("x")
        self.zoom_spin.valueChanged.connect(self.zoom_signal)
        
        control_layout.addWidget(QLabel("Диапазон:"))
        control_layout.addWidget(self.freq_combo)
        control_layout.addWidget(self.capture_btn)
        control_layout.addStretch()
        control_layout.addWidget(QLabel("Масштаб:"))
        control_layout.addWidget(self.zoom_spin)
        
        # График
        if PG_AVAILABLE:
            self.plot_widget = pg.PlotWidget()
            self.plot_widget.setLabel('left', 'Амплитуда')
            self.plot_widget.setLabel('bottom', 'Время', 'мкс')
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            self.plot_curve = self.plot_widget.plot(pen='g')
        else:
            self.plot_widget = QLabel("Установите pyqtgraph для визуализации:\npip install pyqtgraph")
            self.plot_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.plot_widget.setMinimumHeight(300)
            self.plot_widget.setStyleSheet("border: 1px solid #555; background-color: #1e1e1e;")
        
        # Панель анализа
        analysis_group = QGroupBox("Анализ сигнала")
        analysis_layout = QGridLayout()
        
        self.freq_label = QLabel("-")
        self.modulation_label = QLabel("-")
        self.encoding_label = QLabel("-")
        self.snr_label = QLabel("-")
        
        analysis_layout.addWidget(QLabel("Частота:"), 0, 0)
        analysis_layout.addWidget(self.freq_label, 0, 1)
        analysis_layout.addWidget(QLabel("Модуляция:"), 0, 2)
        analysis_layout.addWidget(self.modulation_label, 0, 3)
        analysis_layout.addWidget(QLabel("Кодирование:"), 1, 0)
        analysis_layout.addWidget(self.encoding_label, 1, 1)
        analysis_layout.addWidget(QLabel("SNR:"), 1, 2)
        analysis_layout.addWidget(self.snr_label, 1, 3)
        
        analysis_group.setLayout(analysis_layout)
        
        # Кнопки
        process_layout = QHBoxLayout()
        
        btn_demod = QPushButton("🔄 Демодулировать")
        btn_demod.clicked.connect(self.demodulate)
        
        btn_fft = QPushButton("📊 Показать FFT")
        btn_fft.clicked.connect(self.show_fft)
        
        btn_save = QPushButton("💾 Сохранить")
        btn_save.clicked.connect(self.save_signal)
        
        process_layout.addWidget(btn_demod)
        process_layout.addWidget(btn_fft)
        process_layout.addWidget(btn_save)
        
        # Вывод демодуляции
        demod_group = QGroupBox("Демодулированные данные")
        demod_layout = QVBoxLayout()
        
        self.demod_text = QTextEdit()
        self.demod_text.setReadOnly(True)
        self.demod_text.setFont(QFont("Courier New", 10))
        self.demod_text.setMaximumHeight(150)
        
        demod_layout.addWidget(self.demod_text)
        demod_group.setLayout(demod_layout)
        
        # Сборка
        layout.addLayout(control_layout)
        layout.addWidget(self.plot_widget, 2)
        layout.addWidget(analysis_group)
        layout.addLayout(process_layout)
        layout.addWidget(demod_group)
        
        self.setLayout(layout)
    
    def capture_signal(self):
        freq = self.freq_combo.currentText()
        self.demod_text.append(f"📡 Захват сигнала ({freq})...")
        
        # Захват в потоке
        self.capture_thread = CaptureThread(self.pm3, freq)
        self.capture_thread.samples_ready.connect(self.on_samples_ready)
        self.capture_thread.start()
    
    def on_samples_ready(self, samples):
        self.samples = samples
        self.plot_signal(samples)
        self.analyze_signal(samples)
    
    def plot_signal(self, samples):
        if PG_AVAILABLE:
            zoom = self.zoom_spin.value()
            x = np.arange(len(samples)) / zoom
            self.plot_curve.setData(x, samples)
            self.plot_widget.autoRange()
    
    def analyze_signal(self, samples):
        if samples is None or len(samples) < 10:
            return
        
        # FFT
        fft = np.fft.fft(samples)
        freqs = np.fft.fftfreq(len(samples), 1/2000000)
        magnitude = np.abs(fft)
        magnitude[0] = 0
        
        if len(magnitude) > 1:
            peak_idx = np.argmax(magnitude[1:]) + 1
            freq = abs(freqs[peak_idx])
            
            if 120000 < freq < 130000:
                self.freq_label.setText(f"{freq/1000:.1f} kHz (LF)")
                self.modulation_label.setText("ASK")
                self.encoding_label.setText("Manchester")
            elif 130000 < freq < 140000:
                self.freq_label.setText(f"{freq/1000:.1f} kHz (LF)")
                self.modulation_label.setText("FSK")
            elif 13000000 < freq < 14000000:
                self.freq_label.setText(f"{freq/1000000:.2f} MHz (HF)")
            else:
                self.freq_label.setText(f"{freq/1000:.1f} kHz")
        
        # SNR
        signal_power = np.mean(samples[:50]**2) if len(samples) > 50 else np.mean(samples**2)
        noise_power = np.mean(samples[-50:]**2) if len(samples) > 50 else np.mean(samples**2) * 0.1
        snr = 10 * np.log10(signal_power / (noise_power + 1e-10))
        self.snr_label.setText(f"{snr:.1f} dB")
    
    def zoom_signal(self):
        if self.samples is not None:
            self.plot_signal(self.samples)
    
    def demodulate(self):
        if self.samples is None:
            self.demod_text.append("Нет сигнала для демодуляции")
            return
        
        self.demod_text.append("🔄 Демодуляция...")
        
        # Простая ASK демодуляция
        threshold = np.mean(self.samples) + 0.3 * np.std(self.samples)
        bits = ['1' if s > threshold else '0' for s in self.samples[::10]]
        
        bits_str = ''.join(bits[:200])
        self.demod_text.append(f"Биты: {bits_str}...")
    
    def show_fft(self):
        if self.samples is None:
            self.demod_text.append("Нет сигнала для FFT")
            return
        
        fft = np.fft.fft(self.samples)
        freqs = np.fft.fftfreq(len(self.samples), 1/2000000)
        magnitude = np.abs(fft)
        magnitude[0] = 0
        
        peaks = []
        for i in range(1, len(magnitude)//2):
            if magnitude[i] > np.mean(magnitude) * 3:
                peaks.append(freqs[i])
        
        if peaks:
            self.demod_text.append(f"Основные частоты: {', '.join([f'{p/1000:.1f}kHz' for p in peaks[:5]])}")
        else:
            self.demod_text.append("Основные частоты не обнаружены")
    
    def save_signal(self):
        if self.samples is None:
            self.demod_text.append("Нет сигнала для сохранения")
            return
        
        filename, _ = QFileDialog.getSaveFileName(self, "Сохранить сигнал", "", "CSV files (*.csv)")
        if filename:
            np.savetxt(filename, self.samples, delimiter=',')
            self.demod_text.append(f"💾 Сигнал сохранён в {filename}")


class CaptureThread(QThread):
    """Поток для захвата сигнала"""
    
    samples_ready = Signal(object)
    
    def __init__(self, pm3, freq):
        super().__init__()
        self.pm3 = pm3
        self.freq = freq
    
    def run(self):
        try:
            if "LF" in self.freq:
                output = self.pm3.run_command("lf sample 10")
            else:
                output = self.pm3.run_command("hf 14a read")
            
            # Генерируем тестовый сигнал
            t = np.linspace(0, 0.01, 1000)
            samples = np.sin(2 * np.pi * 125000 * t) + 0.5 * np.random.randn(len(t))
            self.samples_ready.emit(samples)
            
        except Exception as e:
            print(f"Ошибка захвата: {e}")