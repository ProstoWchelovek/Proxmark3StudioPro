# gui/widgets/notification.py
"""
Система уведомлений (тосты)
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class NotificationType(Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"


class NotificationWidget(QWidget):
    """Виджет уведомления (тост)"""
    
    closed = Signal()
    
    def __init__(self, message: str, notif_type: NotificationType = NotificationType.INFO, duration: int = 3000):
        super().__init__()
        self.message = message
        self.notif_type = notif_type
        self.duration = duration
        self.init_ui()
        
        # Автоматическое закрытие
        if duration > 0:
            QTimer.singleShot(duration, self.close)
    
    def init_ui(self):
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        # Цвета для разных типов
        colors = {
            NotificationType.INFO: ("#2196F3", "#1565C0"),
            NotificationType.SUCCESS: ("#4CAF50", "#2E7D32"),
            NotificationType.WARNING: ("#FFC107", "#FF8F00"),
            NotificationType.ERROR: ("#f44336", "#c62828"),
        }
        
        bg_color, border_color = colors.get(self.notif_type, colors[NotificationType.INFO])
        
        # Основной фрейм
        self.frame = QFrame()
        self.frame.setStyleSheet(f"""
            QFrame {{
                background-color: {bg_color};
                border: 1px solid {border_color};
                border-radius: 8px;
            }}
        """)
        
        layout = QHBoxLayout(self.frame)
        
        # Иконка
        icon_label = QLabel()
        icons = {
            NotificationType.INFO: "ℹ️",
            NotificationType.SUCCESS: "✅",
            NotificationType.WARNING: "⚠️",
            NotificationType.ERROR: "❌",
        }
        icon_label.setText(icons.get(self.notif_type, "ℹ️"))
        icon_label.setStyleSheet("font-size: 20px; background: transparent;")
        
        # Текст
        text_label = QLabel(self.message)
        text_label.setStyleSheet("color: white; background: transparent; font-size: 12px;")
        text_label.setWordWrap(True)
        
        # Кнопка закрытия
        close_btn = QPushButton("×")
        close_btn.setFixedSize(20, 20)
        close_btn.setStyleSheet("""
            QPushButton {
                border: none;
                background: transparent;
                color: white;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background: rgba(255,255,255,0.2);
                border-radius: 10px;
            }
        """)
        close_btn.clicked.connect(self.close)
        
        layout.addWidget(icon_label)
        layout.addWidget(text_label, 1)
        layout.addWidget(close_btn)
        
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.frame)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        self.setLayout(main_layout)
        self.adjustSize()
    
    def show_at(self, pos: QPoint):
        """Показать уведомление в указанной позиции"""
        self.move(pos)
        self.show()
        self.raise_()
    
    def show_bottom_right(self, parent=None):
        """Показать в правом нижнем углу"""
        if parent:
            parent_rect = parent.geometry()
            x = parent_rect.right() - self.width() - 10
            y = parent_rect.bottom() - self.height() - 10
            self.move(x, y)
        self.show()
        self.raise_()


class NotificationManager(QObject):
    """Менеджер уведомлений"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.notifications = []
    
    def show(self, message: str, notif_type: NotificationType = NotificationType.INFO, duration: int = 3000):
        """Показать уведомление"""
        notification = NotificationWidget(message, notif_type, duration)
        notification.closed.connect(lambda: self.notifications.remove(notification))
        
        # Позиционирование
        if self.parent():
            notification.show_bottom_right(self.parent())
        else:
            notification.show()
        
        self.notifications.append(notification)
        return notification
    
    def info(self, message: str, duration: int = 3000):
        """Информационное уведомление"""
        return self.show(message, NotificationType.INFO, duration)
    
    def success(self, message: str, duration: int = 3000):
        """Уведомление об успехе"""
        return self.show(message, NotificationType.SUCCESS, duration)
    
    def warning(self, message: str, duration: int = 3000):
        """Предупреждение"""
        return self.show(message, NotificationType.WARNING, duration)
    
    def error(self, message: str, duration: int = 3000):
        """Об ошибке"""
        return self.show(message, NotificationType.ERROR, duration)
    
    def clear_all(self):
        """Закрыть все уведомления"""
        for notif in self.notifications:
            notif.close()
        self.notifications.clear()