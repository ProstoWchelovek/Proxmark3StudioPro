# gui/widgets/status_bar.py
"""
Расширенный статус-бар с индикаторами
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class StatusBar(QStatusBar):
    """Расширенный статус-бар"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        # Индикатор подключения
        self.connection_indicator = QLabel("⚫")
        self.connection_indicator.setToolTip("Не подключен")
        self.connection_indicator.setStyleSheet("font-size: 14px;")
        
        # Индикатор активности
        self.activity_indicator = QLabel("●")
        self.activity_indicator.setToolTip("Готов")
        self.activity_indicator.setStyleSheet("color: #4CAF50; font-size: 12px;")
        
        # Индикатор частоты
        self.frequency_label = QLabel("📡 --")
        
        # Прогресс-бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setVisible(False)
        
        # Сообщение
        self.message_label = QLabel("Готов")
        
        self.addPermanentWidget(self.connection_indicator)
        self.addPermanentWidget(self.activity_indicator)
        self.addPermanentWidget(self.frequency_label)
        self.addPermanentWidget(self.progress_bar)
        self.addWidget(self.message_label)
    
    def set_connected(self, connected: bool):
        """Установка статуса подключения"""
        if connected:
            self.connection_indicator.setText("🟢")
            self.connection_indicator.setToolTip("Подключен")
            self.message_label.setText("Устройство подключено")
        else:
            self.connection_indicator.setText("🔴")
            self.connection_indicator.setToolTip("Не подключен")
            self.message_label.setText("Устройство не подключено")
    
    def set_busy(self, busy: bool, message: str = ""):
        """Установка статуса занятости"""
        if busy:
            self.activity_indicator.setText("◉")
            self.activity_indicator.setStyleSheet("color: #FFC107; font-size: 12px;")
            self.activity_indicator.setToolTip("Выполняется операция")
            if message:
                self.message_label.setText(message)
        else:
            self.activity_indicator.setText("●")
            self.activity_indicator.setStyleSheet("color: #4CAF50; font-size: 12px;")
            self.activity_indicator.setToolTip("Готов")
            self.message_label.setText("Готов")
    
    def set_frequency(self, freq: str):
        """Установка частоты"""
        self.frequency_label.setText(f"📡 {freq}")
    
    def show_progress(self, show: bool):
        """Показать/скрыть прогресс-бар"""
        self.progress_bar.setVisible(show)
    
    def update_progress(self, value: int, message: str = None):
        """Обновление прогресса"""
        self.progress_bar.setValue(value)
        if message:
            self.message_label.setText(message)
    
    def show_message(self, message: str, timeout: int = 3000):
        """Показать временное сообщение"""
        self.message_label.setText(message)
        if timeout > 0:
            QTimer.singleShot(timeout, lambda: self.message_label.setText("Готов"))