# gui/widgets/custom_tabs.py
"""
Кастомные вкладки с дополнительными функциями
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class CustomTabWidget(QTabWidget):
    """Вкладки с возможностью закрытия и переименования"""
    
    tab_closed = Signal(int)
    tab_renamed = Signal(int, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTabsClosable(True)
        self.tabCloseRequested.connect(self.close_tab)
        self.setMovable(True)
    
    def add_tab(self, widget: QWidget, title: str, closable: bool = True):
        """Добавление вкладки"""
        index = self.addTab(widget, title)
        if closable:
            # Создаем кнопку закрытия
            close_btn = QPushButton("×")
            close_btn.setFixedSize(16, 16)
            close_btn.setStyleSheet("""
                QPushButton {
                    border: none;
                    background: transparent;
                    font-weight: bold;
                    color: #888;
                }
                QPushButton:hover {
                    color: #f00;
                }
            """)
            close_btn.clicked.connect(lambda: self.close_tab(index))
            self.tabBar().setTabButton(index, QTabBar.RightSide, close_btn)
        
        return index
    
    def close_tab(self, index: int):
        """Закрытие вкладки"""
        widget = self.widget(index)
        if widget:
            widget.deleteLater()
        self.removeTab(index)
        self.tab_closed.emit(index)
    
    def rename_tab(self, index: int, new_title: str):
        """Переименование вкладки"""
        self.setTabText(index, new_title)
        self.tab_renamed.emit(index, new_title)
    
    def get_current_widget(self) -> QWidget:
        """Получение текущего виджета"""
        return self.currentWidget()
    
    def get_all_widgets(self) -> list:
        """Получение всех виджетов"""
        widgets = []
        for i in range(self.count()):
            widgets.append(self.widget(i))
        return widgets


class ClosableTabBar(QTabBar):
    """Панель вкладок с кнопкой закрытия"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDrawBase(True)
        self.setElideMode(Qt.TextElideMode.ElideRight)
    
    def tabSizeHint(self, index):
        size = super().tabSizeHint(index)
        size.setWidth(size.width() + 20)
        return size