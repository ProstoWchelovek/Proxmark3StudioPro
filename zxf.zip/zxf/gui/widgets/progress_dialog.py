# gui/widgets/progress_dialog.py
"""
Диалог с индикатором прогресса для длительных операций
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *


class ProgressDialog(QProgressDialog):
    """Улучшенный диалог прогресса"""
    
    def __init__(self, title: str, label: str, parent=None):
        super().__init__(label, "Отмена", 0, 100, parent)
        self.setWindowTitle(title)
        self.setWindowModality(Qt.WindowModality.WindowModal)
        self.setMinimumDuration(0)
        self.setAutoClose(True)
        self.setAutoReset(True)
        self.setMinimumWidth(400)
        
        self.setStyleSheet("""
            QProgressDialog {
                background-color: #2b2b2b;
                border: 1px solid #3c3c3c;
                border-radius: 5px;
            }
            QProgressBar {
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                text-align: center;
                background-color: #1e1e1e;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                border-radius: 3px;
            }
            QLabel {
                color: #d4d4d4;
            }
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                padding: 5px 15px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)
    
    def update_progress(self, value: int, message: str = None):
        """Обновление прогресса"""
        self.setValue(value)
        if message:
            self.setLabelText(message)
        QApplication.processEvents()
    
    def set_maximum(self, maximum: int):
        """Установка максимального значения"""
        self.setMaximum(maximum)
    
    def is_cancelled(self) -> bool:
        """Проверка, была ли нажата отмена"""
        return self.wasCanceled()


class ProgressWorker(QThread):
    """Поток с прогрессом для длительных операций"""
    
    progress = Signal(int)
    message = Signal(str)
    finished_signal = Signal(object)
    error = Signal(str)
    
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
        self._is_cancelled = False
    
    def run(self):
        try:
            result = self.func(*self.args, **self.kwargs, 
                              progress_callback=self.progress.emit,
                              message_callback=self.message.emit)
            self.finished_signal.emit(result)
        except Exception as e:
            self.error.emit(str(e))
    
    def cancel(self):
        self._is_cancelled = True
        self.terminate()