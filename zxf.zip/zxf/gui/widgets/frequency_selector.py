# gui/widgets/frequency_selector.py
"""
Виджет выбора частоты/диапазона
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *


class FrequencySelector(QComboBox):
    """Виджет выбора частоты"""
    
    frequency_changed = Signal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_items()
        self.currentTextChanged.connect(self.frequency_changed.emit)
        
        self.setStyleSheet("""
            FrequencySelector {
                padding: 5px;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                background-color: #2b2b2b;
            }
        """)
    
    def _init_items(self):
        """Инициализация списка частот"""
        self.addItems([
            "🌊 Низкая частота (LF) - 125 kHz",
            "🌊 Низкая частота (LF) - 134 kHz",
            "⚡ Высокая частота (HF) - 13.56 MHz",
            "🔍 Автоопределение",
        ])
        self.setCurrentIndex(0)
    
    def get_frequency(self) -> int:
        """Получение выбранной частоты в Гц"""
        text = self.currentText()
        if "125" in text:
            return 125000
        elif "134" in text:
            return 134200
        elif "13.56" in text:
            return 13560000
        return 0
    
    def get_range(self) -> str:
        """Получение диапазона"""
        text = self.currentText()
        if "LF" in text:
            return "lf"
        elif "HF" in text:
            return "hf"
        return "auto"
    
    def set_lf(self):
        self.setCurrentIndex(0)
    
    def set_hf(self):
        self.setCurrentIndex(2)
    
    def set_auto(self):
        self.setCurrentIndex(3)


class FrequencyMeter(QWidget):
    """Виджет индикатора частоты и силы сигнала"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
    
    def _init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.label = QLabel("📡 Частота: ---")
        self.label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setVisible(False)
        self.bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                height: 8px;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                border-radius: 3px;
            }
        """)
        
        layout.addWidget(self.label)
        layout.addWidget(self.bar)
        
        self.setLayout(layout)
    
    def set_frequency(self, freq_hz: int):
        """Установка частоты в Гц"""
        if freq_hz == 0:
            self.label.setText("📡 Частота: ---")
            return
        
        if freq_hz < 1000000:
            freq_display = f"{freq_hz / 1000:.1f} kHz"
            range_text = "LF"
            color = "#4CAF50"
        else:
            freq_display = f"{freq_hz / 1000000:.2f} MHz"
            range_text = "HF"
            color = "#2196F3"
        
        self.label.setText(f"📡 Частота: {freq_display} [{range_text}]")
        self.label.setStyleSheet(f"color: {color}; font-weight: bold;")
    
    def set_signal_strength(self, strength_percent: int):
        """Установка силы сигнала (0-100)"""
        self.bar.setVisible(True)
        self.bar.setValue(strength_percent)
        
        if strength_percent > 70:
            color = "#4CAF50"
        elif strength_percent > 30:
            color = "#FFC107"
        else:
            color = "#ff5555"
        
        self.bar.setStyleSheet(f"""
            QProgressBar::chunk {{
                background-color: {color};
            }}
        """)
    
    def clear(self):
        """Очистка индикатора"""
        self.label.setText("📡 Частота: ---")
        self.bar.setVisible(False)