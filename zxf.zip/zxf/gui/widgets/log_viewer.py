# gui/widgets/log_viewer.py
"""
Виджет для просмотра и фильтрации логов
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from datetime import datetime
from typing import List, Dict


class LogViewer(QWidget):
    """Виджет для отображения логов с фильтрацией"""
    
    def __init__(self, parent=None, max_lines: int = 10000):
        super().__init__(parent)
        self.max_lines = max_lines
        self.logs: List[Dict] = []
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Панель фильтров
        filter_layout = QHBoxLayout()
        
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("🔍 Фильтр...")
        self.filter_input.textChanged.connect(self.apply_filter)
        
        self.level_combo = QComboBox()
        self.level_combo.addItems(["Все", "INFO", "WARNING", "ERROR", "SUCCESS", "DEBUG"])
        self.level_combo.currentTextChanged.connect(self.apply_filter)
        
        self.clear_btn = QPushButton("🗑️ Очистить")
        self.clear_btn.clicked.connect(self.clear_logs)
        
        self.export_btn = QPushButton("💾 Экспорт")
        self.export_btn.clicked.connect(self.export_logs)
        
        filter_layout.addWidget(self.filter_input)
        filter_layout.addWidget(self.level_combo)
        filter_layout.addStretch()
        filter_layout.addWidget(self.clear_btn)
        filter_layout.addWidget(self.export_btn)
        
        # Текстовый вывод
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
            }
        """)
        
        layout.addLayout(filter_layout)
        layout.addWidget(self.log_text)
        
        self.setLayout(layout)
    
    def add_log(self, message: str, level: str = "INFO"):
        """Добавление сообщения в лог"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        colors = {
            "INFO": "#d4d4d4",
            "WARNING": "#FFC107",
            "ERROR": "#ff5555",
            "SUCCESS": "#4CAF50",
            "DEBUG": "#888888"
        }
        
        color = colors.get(level, "#d4d4d4")
        
        log_entry = {
            "timestamp": timestamp,
            "level": level,
            "message": message,
            "html": f'<span style="color: #888888;">[{timestamp}]</span> '
                    f'<span style="color: {color}; font-weight: bold;">[{level}]</span> '
                    f'<span style="color: #d4d4d4;">{self._escape_html(message)}</span>'
        }
        
        self.logs.append(log_entry)
        
        # Ограничение размера
        if len(self.logs) > self.max_lines:
            self.logs = self.logs[-self.max_lines:]
        
        self.apply_filter()
    
    def _escape_html(self, text: str) -> str:
        """Экранирование HTML символов"""
        return (text.replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;')
                    .replace('"', '&quot;'))
    
    def apply_filter(self):
        """Применение фильтра"""
        filter_text = self.filter_input.text().lower()
        level_filter = self.level_combo.currentText()
        
        filtered_logs = []
        for log in self.logs:
            if level_filter != "Все" and log["level"] != level_filter:
                continue
            if filter_text and filter_text not in log["message"].lower():
                continue
            filtered_logs.append(log)
        
        # Отображение (последние 5000)
        display_logs = filtered_logs[-5000:]
        
        html = '<pre style="font-family: Courier New; font-size: 10pt; margin: 0; white-space: pre-wrap;">'
        for log in display_logs:
            html += log["html"] + "<br>"
        html += "</pre>"
        
        self.log_text.setHtml(html)
        
        # Прокрутка вниз
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def clear_logs(self):
        """Очистка логов"""
        self.logs.clear()
        self.log_text.clear()
    
    def export_logs(self):
        """Экспорт логов в файл"""
        filename, _ = QFileDialog.getSaveFileName(self, "Экспорт логов", "", 
                                                   "Text files (*.txt);;HTML files (*.html)")
        if filename:
            if filename.endswith('.html'):
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write("<html><head><title>Proxmark3 Studio Logs</title></head><body>\n")
                    for log in self.logs:
                        f.write(f"<p>{log['html']}</p>\n")
                    f.write("</body></html>")
            else:
                with open(filename, 'w', encoding='utf-8') as f:
                    for log in self.logs:
                        f.write(f"[{log['timestamp']}] [{log['level']}] {log['message']}\n")
            
            QMessageBox.information(self, "Экспорт", f"Логи сохранены в {filename}")
    
    # Удобные методы для разных уровней
    def info(self, message: str):
        self.add_log(message, "INFO")
    
    def warning(self, message: str):
        self.add_log(message, "WARNING")
    
    def error(self, message: str):
        self.add_log(message, "ERROR")
    
    def success(self, message: str):
        self.add_log(message, "SUCCESS")
    
    def debug(self, message: str):
        self.add_log(message, "DEBUG")