# gui/widgets/hex_input.py
"""
Поле ввода HEX данных с валидацией и форматированием
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import re


class HexInput(QLineEdit):
    """Поле ввода HEX данных с валидацией"""
    
    def __init__(self, max_bytes: int = 16, parent=None):
        super().__init__(parent)
        self.max_bytes = max_bytes
        self.setMaxLength(max_bytes * 2)
        self.setPlaceholderText(f"HEX ({max_bytes} байт)")
        
        # Валидатор HEX
        hex_pattern = QRegularExpression("^[0-9A-Fa-f]*$")
        self.setValidator(QRegularExpressionValidator(hex_pattern))
        
        # Автоматическое форматирование
        self.textChanged.connect(self._format_hex)
        
        self.setStyleSheet("""
            HexInput {
                font-family: Courier New;
                font-size: 11px;
            }
        """)
    
    def _format_hex(self):
        """Форматирование HEX с пробелами каждые 2 символа"""
        text = self.text().upper().replace(' ', '')
        
        if len(text) > 2:
            formatted = ' '.join(text[i:i+2] for i in range(0, len(text), 2))
            if formatted != self.text():
                self.blockSignals(True)
                self.setText(formatted)
                self.blockSignals(False)
    
    def get_bytes(self) -> Optional[bytes]:
        """Получение байтов из HEX строки"""
        hex_str = self.text().replace(' ', '')
        if not hex_str:
            return None
        try:
            return bytes.fromhex(hex_str)
        except ValueError:
            return None
    
    def set_bytes(self, data: bytes):
        """Установка байтов в поле"""
        self.setText(data.hex().upper())
    
    def is_valid(self) -> bool:
        """Проверка валидности HEX строки"""
        hex_str = self.text().replace(' ', '')
        if not hex_str:
            return False
        return len(hex_str) % 2 == 0 and all(c in "0123456789ABCDEF" for c in hex_str.upper())


class HexEdit(QTextEdit):
    """Многострочный HEX редактор"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont("Courier New", 10))
        self.setStyleSheet("""
            HexEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
            }
        """)
        
        # Автоформатирование при изменении
        self.textChanged.connect(self._auto_format)
    
    def _auto_format(self):
        """Автоматическое форматирование HEX"""
        text = self.toPlainText().upper()
        
        # Убираем все не-HEX символы
        clean = ''.join(c for c in text if c in '0123456789ABCDEF')
        
        if clean != text.replace(' ', '').replace('\n', '').replace('-', ''):
            # Форматируем: по 32 символа (16 байт) на строку
            lines = []
            for i in range(0, len(clean), 32):
                line = clean[i:i+32]
                formatted = ' '.join(line[j:j+2] for j in range(0, len(line), 2))
                lines.append(formatted)
            
            self.blockSignals(True)
            self.setText('\n'.join(lines))
            self.blockSignals(False)
    
    def get_bytes(self) -> Optional[bytes]:
        """Получение байтов"""
        hex_str = self.toPlainText().replace(' ', '').replace('\n', '')
        if not hex_str:
            return None
        try:
            return bytes.fromhex(hex_str)
        except ValueError:
            return None
    
    def set_bytes(self, data: bytes):
        """Установка байтов"""
        hex_str = data.hex().upper()
        lines = []
        for i in range(0, len(hex_str), 32):
            line = hex_str[i:i+32]
            formatted = ' '.join(line[j:j+2] for j in range(0, len(line), 2))
            lines.append(formatted)
        
        self.setText('\n'.join(lines))
    
    def load_file(self, filename: str) -> bool:
        """Загрузка из файла"""
        try:
            with open(filename, 'rb') as f:
                data = f.read()
                self.set_bytes(data)
            return True
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить: {e}")
            return False