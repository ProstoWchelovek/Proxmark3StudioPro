# gui/tools/hardware_test.py
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

class HardwareTestDialog(QDialog):
    """Диалог тестирования аппаратной части Proxmark3"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Тестирование оборудования Proxmark3")
        self.setGeometry(300, 300, 700, 600)
        
        layout = QVBoxLayout(self)
        
        # Вкладки тестов
        tabs = QTabWidget()
        
        # Тест связи
        tabs.addWidget(self.create_connection_test(), "🔌 СВЯЗЬ")
        
        # Тест антенны
        tabs.addWidget(self.create_antenna_test(), "📡 АНТЕННА")
        
        # Тест памяти
        tabs.addWidget(self.create_memory_test(), "💾 ПАМЯТЬ")
        
        # Тест FPGA
        tabs.addWidget(self.create_fpga_test(), "⚙️ FPGA")
        
        # Общий тест
        tabs.addWidget(self.create_full_test(), "🔬 ПОЛНЫЙ ТЕСТ")
        
        layout.addWidget(tabs)
        
        # Кнопки
        btn_close = QPushButton("Закрыть")
        btn_close.clicked.connect(self.reject)
        layout.addWidget(btn_close)
    
    def create_connection_test(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.conn_result = QTextEdit()
        self.conn_result.setReadOnly(True)
        self.conn_result.setFont(QFont("Courier New", 10))
        
        btn_test = QPushButton("🔌 ТЕСТИРОВАТЬ СВЯЗЬ")
        btn_test.clicked.connect(self.test_connection)
        btn_test.setStyleSheet("padding: 10px;")
        
        layout.addWidget(btn_test)
        layout.addWidget(self.conn_result)
        
        return widget
    
    def create_antenna_test(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Настройки
        settings_layout = QHBoxLayout()
        
        self.freq_combo = QComboBox()
        self.freq_combo.addItems(["125 kHz (LF)", "13.56 MHz (HF)"])
        
        self.power_spin = QDoubleSpinBox()
        self.power_spin.setRange(0, 100)
        self.power_spin.setValue(50)
        self.power_spin.setSuffix("%")
        
        settings_layout.addWidget(QLabel("Частота:"))
        settings_layout.addWidget(self.freq_combo)
        settings_layout.addWidget(QLabel("Мощность:"))
        settings_layout.addWidget(self.power_spin)
        
        # Результаты
        self.antenna_result = QTextEdit()
        self.antenna_result.setReadOnly(True)
        self.antenna_result.setFont(QFont("Courier New", 10))
        
        # Кнопки
        btn_test = QPushButton("📡 ТЕСТИРОВАТЬ АНТЕННУ")
        btn_test.clicked.connect(self.test_antenna)
        
        btn_calibrate = QPushButton("⚡ КАЛИБРОВАТЬ")
        btn_calibrate.clicked.connect(self.calibrate_antenna)
        
        layout.addLayout(settings_layout)
        layout.addWidget(btn_test)
        layout.addWidget(btn_calibrate)
        layout.addWidget(self.antenna_result)
        
        return widget
    
    def create_memory_test(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.memory_result = QTextEdit()
        self.memory_result.setReadOnly(True)
        self.memory_result.setFont(QFont("Courier New", 10))
        
        btn_test = QPushButton("💾 ТЕСТИРОВАТЬ ПАМЯТЬ")
        btn_test.clicked.connect(self.test_memory)
        btn_test.setStyleSheet("padding: 10px;")
        
        layout.addWidget(btn_test)
        layout.addWidget(self.memory_result)
        
        return widget
    
    def create_fpga_test(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.fpga_result = QTextEdit()
        self.fpga_result.setReadOnly(True)
        self.fpga_result.setFont(QFont("Courier New", 10))
        
        btn_test = QPushButton("⚙️ ТЕСТИРОВАТЬ FPGA")
        btn_test.clicked.connect(self.test_fpga)
        btn_test.setStyleSheet("padding: 10px;")
        
        layout.addWidget(btn_test)
        layout.addWidget(self.fpga_result)
        
        return widget
    
    def create_full_test(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        self.full_result = QTextEdit()
        self.full_result.setReadOnly(True)
        self.full_result.setFont(QFont("Courier New", 10))
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        btn_test = QPushButton("🔬 ЗАПУСТИТЬ ПОЛНЫЙ ТЕСТ")
        btn_test.clicked.connect(self.run_full_test)
        btn_test.setStyleSheet("background-color: #4CAF50; padding: 10px; font-weight: bold;")
        
        layout.addWidget(btn_test)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.full_result)
        
        return widget
    
    def append_result(self, text_widget, text, color=None):
        """Добавление результата"""
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        if color:
            formatted = f'<span style="color: {color};">[{timestamp}] {text}</span>'
        else:
            formatted = f'[{timestamp}] {text}'
        
        text_widget.append(formatted)
        QApplication.processEvents()
    
    def test_connection(self):
        """Тест связи с устройством"""
        self.append_result(self.conn_result, "Начало теста связи...", "#4CAF50")
        
        # Проверка версии
        version = self.pm3.run_command("hw version")
        if "proxmark" in version.lower():
            self.append_result(self.conn_result, "✅ Устройство обнаружено", "#4CAF50")
            self.append_result(self.conn_result, f"   {version.split(chr(10))[0]}")
        else:
            self.append_result(self.conn_result, "❌ Устройство не отвечает", "#ff5555")
            return
        
        # Пинг
        ping = self.pm3.run_command("hw ping")
        if "PING" in ping:
            self.append_result(self.conn_result, "✅ Пинг успешен", "#4CAF50")
        else:
            self.append_result(self.conn_result, "❌ Ошибка пинга", "#ff5555")
        
        # Статус
        status = self.pm3.run_command("hw status")
        self.append_result(self.conn_result, f"Статус: {status[:200]}")
        
        self.append_result(self.conn_result, "Тест связи завершён", "#4CAF50")
    
    def test_antenna(self):
        """Тест антенны"""
        self.append_result(self.antenna_result, "Начало теста антенны...", "#4CAF50")
        
        freq = "lf" if "LF" in self.freq_combo.currentText() else "hf"
        
        # Измерение
        cmd = f"hw tune"
        output = self.pm3.run_command(cmd)
        
        self.append_result(self.antenna_result, output)
        
        # Анализ результата
        import re
        match = re.search(r'\[+\s*([\d.]+)\s*\]', output)
        if match:
            amplitude = float(match.group(1))
            if amplitude > 30:
                self.append_result(self.antenna_result, f"✅ Амплитуда сигнала: {amplitude} (хорошо)", "#4CAF50")
            elif amplitude > 15:
                self.append_result(self.antenna_result, f"⚠️ Амплитуда сигнала: {amplitude} (средне)", "#FFC107")
            else:
                self.append_result(self.antenna_result, f"❌ Амплитуда сигнала: {amplitude} (плохо)", "#ff5555")
        
        self.append_result(self.antenna_result, "Тест антенны завершён", "#4CAF50")
    
    def calibrate_antenna(self):
        """Калибровка антенны"""
        self.append_result(self.antenna_result, "Калибровка антенны...", "#4CAF50")
        
        output = self.pm3.run_command("hw tune")
        self.append_result(self.antenna_result, output)
        
        self.append_result(self.antenna_result, "Калибровка завершена", "#4CAF50")
    
    def test_memory(self):
        """Тест памяти"""
        self.append_result(self.memory_result, "Начало теста памяти...", "#4CAF50")
        
        # Чтение информации о памяти
        output = self.pm3.run_command("hw version")
        
        import re
        mem_match = re.search(r'Memory:\s*(\w+)', output)
        if mem_match:
            self.append_result(self.memory_result, f"✅ Память: {mem_match.group(1)}", "#4CAF50")
        
        # Проверка целостности
        test = self.pm3.run_command("hw test")
        if "OK" in test:
            self.append_result(self.memory_result, "✅ Тест целостности пройден", "#4CAF50")
        else:
            self.append_result(self.memory_result, "⚠️ Тест целостности: возможны проблемы", "#FFC107")
        
        self.append_result(self.memory_result, "Тест памяти завершён", "#4CAF50")
    
    def test_fpga(self):
        """Тест FPGA"""
        self.append_result(self.fpga_result, "Начало теста FPGA...", "#4CAF50")
        
        # Версия FPGA
        version = self.pm3.run_command("hw version")
        import re
        fpga_match = re.search(r'FPGA\s*image\s*built\s*([0-9-]+)', version)
        if fpga_match:
            self.append_result(self.fpga_result, f"✅ Версия FPGA: {fpga_match.group(1)}", "#4CAF50")
        
        # Сброс FPGA
        reset = self.pm3.run_command("hw reset")
        if "OK" in reset:
            self.append_result(self.fpga_result, "✅ Сброс FPGA выполнен", "#4CAF50")
        
        self.append_result(self.fpga_result, "Тест FPGA завершён", "#4CAF50")
    
    def run_full_test(self):
        """Полный тест всех компонентов"""
        self.full_result.clear()
        self.progress_bar.setVisible(True)
        
        tests = [
            ("Тест связи", self.test_connection_full),
            ("Тест антенны (LF)", lambda: self.test_antenna_full("lf")),
            ("Тест антенны (HF)", lambda: self.test_antenna_full("hf")),
            ("Тест памяти", self.test_memory_full),
            ("Тест FPGA", self.test_fpga_full),
        ]
        
        passed = 0
        total = len(tests)
        
        for i, (name, test_func) in enumerate(tests):
            self.progress_bar.setValue(int(i / total * 100))
            self.append_result(self.full_result, f"\n=== {name} ===", "#4CAF50")
            
            try:
                result = test_func()
                if result:
                    passed += 1
                    self.append_result(self.full_result, f"✅ {name}: ПРОЙДЕН", "#4CAF50")
                else:
                    self.append_result(self.full_result, f"❌ {name}: НЕ ПРОЙДЕН", "#ff5555")
            except Exception as e:
                self.append_result(self.full_result, f"❌ {name}: ОШИБКА - {e}", "#ff5555")
        
        self.progress_bar.setValue(100)
        
        # Итог
        self.append_result(self.full_result, "\n" + "=" * 40, "#4CAF50")
        self.append_result(self.full_result, f"РЕЗУЛЬТАТ: {passed}/{total} тестов пройдено", 
                          "#4CAF50" if passed == total else "#FFC107")
        
        self.progress_bar.setVisible(False)
    
    def test_connection_full(self):
        """Полный тест связи"""
        version = self.pm3.run_command("hw version")
        return "proxmark" in version.lower()
    
    def test_antenna_full(self, freq):
        """Полный тест антенны"""
        cmd = "hw tune"
        output = self.pm3.run_command(cmd)
        
        import re
        match = re.search(r'\[+\s*([\d.]+)\s*\]', output)
        if match:
            amplitude = float(match.group(1))
            return amplitude > 15
        return False
    
    def test_memory_full(self):
        """Полный тест памяти"""
        test = self.pm3.run_command("hw test")
        return "OK" in test
    
    def test_fpga_full(self):
        """Полный тест FPGA"""
        reset = self.pm3.run_command("hw reset")
        return "OK" in reset