# gui/tools/console.py
"""
Терминал для прямых команд Proxmark3
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *


class ConsoleWidget(QWidget):
    """Терминал Proxmark3"""
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.history = []
        self.history_index = -1
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Вывод
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Courier New", 10))
        self.output.setStyleSheet("background-color: #1e1e1e; color: #d4d4d4;")
        
        # Ввод
        input_layout = QHBoxLayout()
        
        self.prompt = QLabel("pm3>")
        self.prompt.setFont(QFont("Courier New", 11, QFont.Weight.Bold))
        self.prompt.setStyleSheet("color: #4CAF50;")
        
        self.command_input = QLineEdit()
        self.command_input.setFont(QFont("Courier New", 11))
        self.command_input.returnPressed.connect(self.execute_command)
        
        btn_send = QPushButton("▶️ Выполнить")
        btn_send.clicked.connect(self.execute_command)
        
        btn_clear = QPushButton("🗑️ Очистить")
        btn_clear.clicked.connect(self.clear_output)
        
        input_layout.addWidget(self.prompt)
        input_layout.addWidget(self.command_input)
        input_layout.addWidget(btn_send)
        input_layout.addWidget(btn_clear)
        
        layout.addWidget(self.output)
        layout.addLayout(input_layout)
        
        self.setLayout(layout)
        
        self.command_input.setFocus()
        self.command_input.installEventFilter(self)
    
    def eventFilter(self, obj, event):
        if obj == self.command_input and event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_Up:
                self.previous_command()
                return True
            elif event.key() == Qt.Key.Key_Down:
                self.next_command()
                return True
        return super().eventFilter(obj, event)
    
    def execute_command(self):
        cmd = self.command_input.text().strip()
        if not cmd:
            return
        
        self.history.append(cmd)
        self.history_index = len(self.history)
        
        self.output.append(f"<span style='color: #4CAF50;'>pm3&gt; {cmd}</span>")
        
        try:
            result = self.pm3.run_command(cmd)
            self.output.append(result)
            self.output.append("")
        except Exception as e:
            self.output.append(f"<span style='color: #ff5555;'>Ошибка: {str(e)}</span>")
        
        scrollbar = self.output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        
        self.command_input.clear()
    
    def previous_command(self):
        if self.history and self.history_index > 0:
            self.history_index -= 1
            self.command_input.setText(self.history[self.history_index])
    
    def next_command(self):
        if self.history and self.history_index < len(self.history) - 1:
            self.history_index += 1
            self.command_input.setText(self.history[self.history_index])
        elif self.history_index == len(self.history) - 1:
            self.history_index = len(self.history)
            self.command_input.clear()
    
    def clear_output(self):
        self.output.clear()