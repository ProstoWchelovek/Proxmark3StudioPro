# gui/tools/settings.py
"""
Диалог настроек приложения
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import json
from pathlib import Path


class SettingsDialog(QDialog):
    """Диалог настроек"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = self.load_settings()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Настройки Proxmark3 Studio Pro")
        self.setGeometry(300, 300, 600, 450)
        
        layout = QVBoxLayout(self)
        
        tabs = QTabWidget()
        
        # Устройство
        device_tab = self.create_device_tab()
        tabs.addTab(device_tab, "🔌 УСТРОЙСТВО")
        
        # Внешний вид
        appearance_tab = self.create_appearance_tab()
        tabs.addTab(appearance_tab, "🎨 ВНЕШНИЙ ВИД")
        
        # Пути
        paths_tab = self.create_paths_tab()
        tabs.addTab(paths_tab, "📁 ПУТИ")
        
        # Атаки
        attacks_tab = self.create_attacks_tab()
        tabs.addTab(attacks_tab, "⚔️ АТАКИ")
        
        layout.addWidget(tabs)
        
        # Кнопки
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | 
                                   QDialogButtonBox.StandardButton.Cancel |
                                   QDialogButtonBox.StandardButton.Apply)
        buttons.accepted.connect(self.save_and_close)
        buttons.rejected.connect(self.reject)
        buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.apply_settings)
        
        layout.addWidget(buttons)
    
    def create_device_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.port_combo = QComboBox()
        self.port_combo.setEditable(True)
        
        btn_refresh = QPushButton("🔄 Обновить")
        btn_refresh.clicked.connect(self.detect_ports)
        
        port_layout = QHBoxLayout()
        port_layout.addWidget(self.port_combo)
        port_layout.addWidget(btn_refresh)
        
        self.baud_combo = QComboBox()
        self.baud_combo.addItems(["115200", "230400", "460800", "921600"])
        self.baud_combo.setCurrentText(self.settings.get("port", {}).get("baud", "115200"))
        
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 60)
        self.timeout_spin.setValue(self.settings.get("port", {}).get("timeout", 5))
        self.timeout_spin.setSuffix(" сек")
        
        layout.addRow("Порт:", port_layout)
        layout.addRow("Скорость:", self.baud_combo)
        layout.addRow("Таймаут:", self.timeout_spin)
        
        self.detect_ports()
        
        return widget
    
    def create_appearance_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Тёмная", "Светлая"])
        self.theme_combo.setCurrentText(self.settings.get("appearance", {}).get("theme", "Тёмная"))
        
        self.font_btn = QPushButton("Выбрать шрифт...")
        self.font_btn.clicked.connect(self.select_font)
        
        self.font_label = QLabel(self.settings.get("appearance", {}).get("font", "Courier New, 10pt"))
        
        layout.addRow("Тема:", self.theme_combo)
        layout.addRow("Шрифт:", self.font_btn)
        layout.addRow("", self.font_label)
        
        return widget
    
    def create_paths_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.dumps_dir = QLineEdit()
        self.dumps_dir.setText(self.settings.get("paths", {}).get("dumps", str(Path.home() / ".proxmark3_studio" / "dumps")))
        btn_dumps = QPushButton("Обзор...")
        btn_dumps.clicked.connect(lambda: self.browse_folder(self.dumps_dir))
        
        dumps_layout = QHBoxLayout()
        dumps_layout.addWidget(self.dumps_dir)
        dumps_layout.addWidget(btn_dumps)
        
        self.scripts_dir = QLineEdit()
        self.scripts_dir.setText(self.settings.get("paths", {}).get("scripts", str(Path.home() / ".proxmark3_studio" / "scripts")))
        btn_scripts = QPushButton("Обзор...")
        btn_scripts.clicked.connect(lambda: self.browse_folder(self.scripts_dir))
        
        scripts_layout = QHBoxLayout()
        scripts_layout.addWidget(self.scripts_dir)
        scripts_layout.addWidget(btn_scripts)
        
        layout.addRow("Дампы:", dumps_layout)
        layout.addRow("Скрипты:", scripts_layout)
        
        return widget
    
    def create_attacks_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.attack_timeout = QSpinBox()
        self.attack_timeout.setRange(10, 3600)
        self.attack_timeout.setValue(self.settings.get("attacks", {}).get("timeout", 300))
        self.attack_timeout.setSuffix(" сек")
        
        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 8)
        self.threads_spin.setValue(self.settings.get("attacks", {}).get("threads", 4))
        
        self.save_keys = QCheckBox("Автоматически сохранять найденные ключи")
        self.save_keys.setChecked(self.settings.get("attacks", {}).get("save_keys", True))
        
        layout.addRow("Таймаут:", self.attack_timeout)
        layout.addRow("Потоков:", self.threads_spin)
        layout.addRow("", self.save_keys)
        
        return widget
    
    def detect_ports(self):
        import serial.tools.list_ports
        ports = [port.device for port in serial.tools.list_ports.comports()]
        self.port_combo.clear()
        self.port_combo.addItems(ports)
        
        saved_port = self.settings.get("port", {}).get("device", "")
        if saved_port in ports:
            self.port_combo.setCurrentText(saved_port)
    
    def browse_folder(self, line_edit):
        folder = QFileDialog.getExistingDirectory(self, "Выберите папку")
        if folder:
            line_edit.setText(folder)
    
    def select_font(self):
        ok, font = QFontDialog.getFont()
        if ok:
            self.font_label.setText(f"{font.family()}, {font.pointSize()}pt")
    
    def load_settings(self):
        settings_file = Path.home() / ".proxmark3_studio" / "settings.json"
        if settings_file.exists():
            try:
                with open(settings_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def save_settings(self):
        settings = {
            "port": {
                "device": self.port_combo.currentText(),
                "baud": int(self.baud_combo.currentText()),
                "timeout": self.timeout_spin.value()
            },
            "appearance": {
                "theme": self.theme_combo.currentText(),
                "font": self.font_label.text()
            },
            "paths": {
                "dumps": self.dumps_dir.text(),
                "scripts": self.scripts_dir.text()
            },
            "attacks": {
                "timeout": self.attack_timeout.value(),
                "threads": self.threads_spin.value(),
                "save_keys": self.save_keys.isChecked()
            }
        }
        
        settings_file = Path.home() / ".proxmark3_studio" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2)
        
        return settings
    
    def apply_settings(self):
        self.save_settings()
        QMessageBox.information(self, "Настройки", "Настройки сохранены")
    
    def save_and_close(self):
        self.save_settings()
        self.accept()