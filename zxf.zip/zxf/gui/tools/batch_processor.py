# gui/tools/batch_processor.py
"""
Пакетная обработка нескольких карт/ключей
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
import os


class BatchProcessor(QWidget):
    """Пакетная обработка"""
    
    def __init__(self, pm3, key_repo, dump_repo):
        super().__init__()
        self.pm3 = pm3
        self.key_repo = key_repo
        self.dump_repo = dump_repo
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Выбор режима
        mode_group = QGroupBox("Режим обработки")
        mode_layout = QHBoxLayout()
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([
            "Проверка ключей из словаря",
            "Дамп всех карт",
            "Клонирование из папки",
            "Анализ дампов в папке"
        ])
        
        mode_layout.addWidget(self.mode_combo)
        mode_group.setLayout(mode_layout)
        
        # Параметры
        params_group = QGroupBox("Параметры")
        params_layout = QFormLayout()
        
        self.folder_path = QLineEdit()
        btn_browse = QPushButton("Обзор...")
        btn_browse.clicked.connect(lambda: self.browse_folder(self.folder_path))
        
        folder_layout = QHBoxLayout()
        folder_layout.addWidget(self.folder_path)
        folder_layout.addWidget(btn_browse)
        
        self.dict_file = QLineEdit()
        btn_dict = QPushButton("Обзор...")
        btn_dict.clicked.connect(lambda: self.browse_file(self.dict_file))
        
        dict_layout = QHBoxLayout()
        dict_layout.addWidget(self.dict_file)
        dict_layout.addWidget(btn_dict)
        
        params_layout.addRow("Папка:", folder_layout)
        params_layout.addRow("Словарь:", dict_layout)
        params_group.setLayout(params_layout)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        
        # Лог
        log_group = QGroupBox("Лог обработки")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        # Кнопки
        btn_start = QPushButton("🚀 СТАРТ")
        btn_start.clicked.connect(self.start_processing)
        btn_start.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        layout.addWidget(mode_group)
        layout.addWidget(params_group)
        layout.addWidget(self.progress_bar)
        layout.addWidget(log_group)
        layout.addWidget(btn_start)
        
        self.setLayout(layout)
    
    def browse_folder(self, line_edit):
        folder = QFileDialog.getExistingDirectory(self, "Выберите папку")
        if folder:
            line_edit.setText(folder)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите файл", "", "Dictionary files (*.dic *.txt)")
        if filename:
            line_edit.setText(filename)
    
    def log(self, message):
        timestamp = QTime.currentTime().toString("hh:mm:ss")
        self.log_text.append(f"[{timestamp}] {message}")
        QApplication.processEvents()
    
    def start_processing(self):
        mode = self.mode_combo.currentText()
        
        if mode == "Проверка ключей из словаря":
            self.process_dictionary()
        elif mode == "Дамп всех карт":
            self.process_dump_all()
        elif mode == "Клонирование из папки":
            self.process_clone_folder()
        elif mode == "Анализ дампов в папке":
            self.process_analyze_dumps()
    
    def process_dictionary(self):
        dict_file = self.dict_file.text()
        if not os.path.exists(dict_file):
            self.log("❌ Словарь не найден")
            return
        
        self.log(f"🔑 Проверка ключей из {dict_file}")
        
        with open(dict_file, 'r') as f:
            keys = [line.strip() for line in f if line.strip()]
        
        self.progress_bar.setMaximum(len(keys))
        
        found = []
        for i, key in enumerate(keys):
            self.progress_bar.setValue(i)
            self.log(f"Проверка: {key}")
            # TODO: реальная проверка ключа
            # output = self.pm3.run_command(f"hf mf chk --key {key}")
            # if "found" in output.lower():
            #     found.append(key)
        
        self.log(f"✅ Найдено {len(found)} ключей")
        self.progress_bar.setValue(len(keys))
    
    def process_dump_all(self):
        folder = self.folder_path.text()
        if not os.path.exists(folder):
            self.log("❌ Папка не найдена")
            return
        
        self.log(f"💾 Дамп всех карт в {folder}")
        # TODO: реализация дампа всех карт
    
    def process_clone_folder(self):
        folder = self.folder_path.text()
        if not os.path.exists(folder):
            self.log("❌ Папка не найдена")
            return
        
        self.log(f"📝 Клонирование из {folder}")
        # TODO: реализация клонирования
    
    def process_analyze_dumps(self):
        folder = self.folder_path.text()
        if not os.path.exists(folder):
            self.log("❌ Папка не найдена")
            return
        
        self.log(f"🔬 Анализ дампов в {folder}")
        
        dumps = [f for f in os.listdir(folder) if f.endswith(('.dump', '.bin'))]
        self.progress_bar.setMaximum(len(dumps))
        
        for i, dump_file in enumerate(dumps):
            self.progress_bar.setValue(i)
            self.log(f"Анализ: {dump_file}")
            # TODO: анализ дампа
        
        self.log(f"✅ Проанализировано {len(dumps)} дампов")