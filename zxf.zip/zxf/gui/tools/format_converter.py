# gui/tools/format_converter.py
"""
Конвертер форматов дампов и ключей
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import *
import os


class FormatConverter(QWidget):
    """Конвертер форматов"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Выбор типа конвертации
        type_group = QGroupBox("Тип конвертации")
        type_layout = QHBoxLayout()
        
        self.convert_type = QComboBox()
        self.convert_type.addItems([
            "Dump -> EML",
            "EML -> Dump",
            "Dump -> JSON",
            "JSON -> Dump",
            "Keys -> Dictionary"
        ])
        
        type_layout.addWidget(self.convert_type)
        type_group.setLayout(type_layout)
        
        # Входной файл
        input_group = QGroupBox("Входной файл")
        input_layout = QHBoxLayout()
        
        self.input_file = QLineEdit()
        self.input_file.setReadOnly(True)
        
        btn_input = QPushButton("📁 Обзор...")
        btn_input.clicked.connect(lambda: self.browse_file(self.input_file))
        
        input_layout.addWidget(self.input_file)
        input_layout.addWidget(btn_input)
        input_group.setLayout(input_layout)
        
        # Выходной файл
        output_group = QGroupBox("Выходной файл")
        output_layout = QHBoxLayout()
        
        self.output_file = QLineEdit()
        self.output_file.setReadOnly(True)
        
        btn_output = QPushButton("📁 Обзор...")
        btn_output.clicked.connect(lambda: self.browse_file(self.output_file))
        
        output_layout.addWidget(self.output_file)
        output_layout.addWidget(btn_output)
        output_group.setLayout(output_layout)
        
        # Кнопки
        btn_convert = QPushButton("🔄 КОНВЕРТИРОВАТЬ")
        btn_convert.clicked.connect(self.convert)
        btn_convert.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        # Лог
        log_group = QGroupBox("Лог")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier New", 10))
        
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        
        layout.addWidget(type_group)
        layout.addWidget(input_group)
        layout.addWidget(output_group)
        layout.addWidget(btn_convert)
        layout.addWidget(log_group)
        
        self.setLayout(layout)
    
    def browse_file(self, line_edit):
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите файл", "", "All files (*.*)")
        if filename:
            line_edit.setText(filename)
            if not self.output_file.text():
                base, ext = os.path.splitext(filename)
                self.output_file.setText(f"{base}_converted{ext}")
    
    def log(self, message):
        self.log_text.append(message)
        QApplication.processEvents()
    
    def convert(self):
        input_path = self.input_file.text()
        output_path = self.output_file.text()
        
        if not input_path or not output_path:
            QMessageBox.warning(self, "Ошибка", "Выберите входной и выходной файлы")
            return
        
        conv_type = self.convert_type.currentText()
        
        try:
            if conv_type == "Dump -> EML":
                self.convert_dump_to_eml(input_path, output_path)
            elif conv_type == "EML -> Dump":
                self.convert_eml_to_dump(input_path, output_path)
            elif conv_type == "Dump -> JSON":
                self.convert_dump_to_json(input_path, output_path)
            elif conv_type == "JSON -> Dump":
                self.convert_json_to_dump(input_path, output_path)
            elif conv_type == "Keys -> Dictionary":
                self.convert_keys_to_dict(input_path, output_path)
            
            self.log(f"✅ Конвертация завершена: {output_path}")
            QMessageBox.information(self, "Успех", f"Файл сохранён: {output_path}")
            
        except Exception as e:
            self.log(f"❌ Ошибка: {str(e)}")
            QMessageBox.warning(self, "Ошибка", str(e))
    
    def convert_dump_to_eml(self, input_path, output_path):
        with open(input_path, 'rb') as f:
            data = f.read()
        
        with open(output_path, 'w') as f:
            for i, byte in enumerate(data):
                f.write(f"{byte:02X}")
                if (i + 1) % 16 == 0:
                    f.write("\n")
                else:
                    f.write(" ")
        
        self.log(f"Конвертировано {len(data)} байт")
    
    def convert_eml_to_dump(self, input_path, output_path):
        with open(input_path, 'r') as f:
            hex_str = f.read().replace(" ", "").replace("\n", "")
        
        data = bytes.fromhex(hex_str)
        
        with open(output_path, 'wb') as f:
            f.write(data)
        
        self.log(f"Конвертировано {len(data)} байт")
    
    def convert_dump_to_json(self, input_path, output_path):
        import json
        
        with open(input_path, 'rb') as f:
            data = f.read()
        
        result = {
            "format": "proxmark3_dump",
            "size": len(data),
            "data": data.hex()
        }
        
        with open(output_path, 'w') as f:
            json.dump(result, f, indent=2)
        
        self.log(f"Конвертировано {len(data)} байт в JSON")
    
    def convert_json_to_dump(self, input_path, output_path):
        import json
        
        with open(input_path, 'r') as f:
            obj = json.load(f)
        
        data = bytes.fromhex(obj["data"])
        
        with open(output_path, 'wb') as f:
            f.write(data)
        
        self.log(f"Конвертировано {len(data)} байт из JSON")
    
    def convert_keys_to_dict(self, input_path, output_path):
        keys = []
        
        with open(input_path, 'r') as f:
            for line in f:
                line = line.strip().upper()
                if len(line) in [12, 16] and all(c in "0123456789ABCDEF" for c in line):
                    keys.append(line)
        
        with open(output_path, 'w') as f:
            for key in keys:
                f.write(f"{key}\n")
        
        self.log(f"Извлечено {len(keys)} ключей")