# gui/tools/firmware_updater.py
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import subprocess
import os
import platform
import zipfile
import urllib.request
from pathlib import Path

class FirmwareUpdater(QDialog):
    """Обновление прошивки Proxmark3"""
    
    def __init__(self, pm3_client, parent=None):
        super().__init__(parent)
        self.pm3 = pm3_client
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Обновление прошивки Proxmark3")
        self.setGeometry(300, 300, 600, 500)
        
        layout = QVBoxLayout(self)
        
        # Информация о текущей версии
        info_group = QGroupBox("Текущая версия")
        info_layout = QFormLayout()
        
        self.current_version = QLabel("Неизвестно")
        self.current_commit = QLabel("Неизвестно")
        self.device_type = QLabel("Неизвестно")
        
        info_layout.addRow("Версия:", self.current_version)
        info_layout.addRow("Commit:", self.current_commit)
        info_layout.addRow("Устройство:", self.device_type)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # Доступные версии
        versions_group = QGroupBox("Доступные прошивки")
        versions_layout = QVBoxLayout()
        
        self.versions_list = QListWidget()
        self.versions_list.itemClicked.connect(self.on_version_selected)
        versions_layout.addWidget(self.versions_list)
        
        versions_group.setLayout(versions_layout)
        layout.addWidget(versions_group)
        
        # Опции
        options_group = QGroupBox("Опции обновления")
        options_layout = QHBoxLayout()
        
        self.bootrom_check = QCheckBox("Обновить BootROM")
        self.bootrom_check.setChecked(True)
        
        self.full_check = QCheckBox("Полная перезапись")
        
        options_layout.addWidget(self.bootrom_check)
        options_layout.addWidget(self.full_check)
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Прогресс
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Кнопки
        btn_refresh = QPushButton("🔄 Проверить обновления")
        btn_refresh.clicked.connect(self.check_updates)
        
        btn_update = QPushButton("⬇️ ЗАГРУЗИТЬ И ОБНОВИТЬ")
        btn_update.clicked.connect(self.start_update)
        btn_update.setEnabled(False)
        btn_update.setStyleSheet("background-color: #4CAF50; padding: 10px;")
        
        btn_close = QPushButton("Закрыть")
        btn_close.clicked.connect(self.reject)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(btn_refresh)
        button_layout.addStretch()
        button_layout.addWidget(btn_update)
        button_layout.addWidget(btn_close)
        
        layout.addLayout(button_layout)
        
        # Загрузка информации о текущей версии
        self.load_current_version()
    
    def load_current_version(self):
        """Загрузка информации о текущей версии"""
        try:
            output = self.pm3.run_command("hw version")
            
            import re
            version_match = re.search(r'proxmark3\s+[\w-]+\s+v([\d.]+)', output, re.IGNORECASE)
            if version_match:
                self.current_version.setText(version_match.group(1))
            
            commit_match = re.search(r'commit:\s*([a-f0-9]+)', output, re.IGNORECASE)
            if commit_match:
                self.current_commit.setText(commit_match.group(1))
            
            if "RDV4" in output:
                self.device_type.setText("Proxmark3 RDV4")
            elif "Easy" in output:
                self.device_type.setText("Proxmark3 Easy")
            else:
                self.device_type.setText("Proxmark3")
                
        except Exception as e:
            self.current_version.setText(f"Ошибка: {e}")
    
    def check_updates(self):
        """Проверка доступных обновлений"""
        self.versions_list.clear()
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(10)
        
        # Запуск в потоке
        self.update_thread = CheckUpdatesThread()
        self.update_thread.progress.connect(self.progress_bar.setValue)
        self.update_thread.finished.connect(self.on_updates_loaded)
        self.update_thread.start()
    
    def on_updates_loaded(self, versions):
        """Обработка загруженных версий"""
        self.progress_bar.setVisible(False)
        
        if versions:
            for version in versions:
                item = QListWidgetItem(f"📦 {version['name']} - {version['date']}")
                item.setData(Qt.UserRole, version)
                self.versions_list.addItem(item)
            
            self.versions_list.setCurrentRow(0)
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось загрузить список обновлений")
    
    def on_version_selected(self, item):
        """Выбор версии для обновления"""
        self.selected_version = item.data(Qt.UserRole)
        self.sender().setEnabled(True)
    
    def start_update(self):
        """Начало обновления"""
        if not hasattr(self, 'selected_version'):
            QMessageBox.warning(self, "Ошибка", "Выберите версию прошивки")
            return
        
        reply = QMessageBox.question(
            self, "Подтверждение",
            f"Обновить прошивку до {self.selected_version['name']}?\n\n"
            "Убедитесь, что устройство подключено и не будет отключено во время обновления!",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            # Запуск обновления
            self.update_firmware_thread = UpdateFirmwareThread(
                self.selected_version['url'],
                self.bootrom_check.isChecked(),
                self.full_check.isChecked()
            )
            self.update_firmware_thread.progress.connect(self.progress_bar.setValue)
            self.update_firmware_thread.message.connect(self.on_update_message)
            self.update_firmware_thread.finished.connect(self.on_update_finished)
            self.update_firmware_thread.start()
    
    def on_update_message(self, message):
        """Сообщение от процесса обновления"""
        QMessageBox.information(self, "Обновление", message)
    
    def on_update_finished(self, success):
        """Завершение обновления"""
        self.progress_bar.setVisible(False)
        
        if success:
            QMessageBox.information(self, "Успех", "Прошивка успешно обновлена!\nПереподключите устройство.")
            self.load_current_version()
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить прошивку")


class CheckUpdatesThread(QThread):
    """Поток проверки обновлений"""
    progress = Signal(int)
    finished = Signal(list)
    
    def run(self):
        versions = []
        
        try:
            self.progress.emit(20)
            
            # Получение списка релизов с GitHub
            url = "https://api.github.com/repos/RfidResearchGroup/proxmark3/releases"
            
            req = urllib.request.Request(url, headers={'User-Agent': 'Proxmark3-Studio'})
            with urllib.request.urlopen(req, timeout=10) as response:
                import json
                data = json.loads(response.read())
                
                for i, release in enumerate(data[:5]):  # Последние 5 релизов
                    versions.append({
                        'name': release['tag_name'],
                        'date': release['published_at'][:10],
                        'url': release['assets'][0]['browser_download_url'] if release['assets'] else None
                    })
                    self.progress.emit(20 + i * 15)
            
            self.progress.emit(100)
            
        except Exception as e:
            print(f"Ошибка проверки обновлений: {e}")
        
        self.finished.emit(versions)


class UpdateFirmwareThread(QThread):
    """Поток обновления прошивки"""
    progress = Signal(int)
    message = Signal(str)
    finished = Signal(bool)
    
    def __init__(self, url, update_bootrom, full):
        super().__init__()
        self.url = url
        self.update_bootrom = update_bootrom
        self.full = full
    
    def run(self):
        try:
            # Скачивание прошивки
            self.message.emit("Скачивание прошивки...")
            self.progress.emit(10)
            
            firmware_path = Path.home() / ".proxmark3_studio" / "firmware_update.bin"
            firmware_path.parent.mkdir(parents=True, exist_ok=True)
            
            urllib.request.urlretrieve(self.url, firmware_path, self.report_progress)
            
            self.progress.emit(50)
            self.message.emit("Обновление прошивки...")
            
            # Обновление через pm3-flash
            system = platform.system()
            
            if system == "Windows":
                flash_cmd = ["pm3-flash.exe", str(firmware_path)]
            else:
                flash_cmd = ["pm3-flash", str(firmware_path)]
            
            if self.update_bootrom:
                flash_cmd.append("--bootrom")
            if self.full:
                flash_cmd.append("--full")
            
            result = subprocess.run(flash_cmd, capture_output=True, text=True, timeout=60)
            
            self.progress.emit(90)
            
            if result.returncode == 0:
                self.progress.emit(100)
                self.message.emit("Обновление завершено!")
                self.finished.emit(True)
            else:
                self.message.emit(f"Ошибка: {result.stderr}")
                self.finished.emit(False)
                
        except Exception as e:
            self.message.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False)
    
    def report_progress(self, block, block_size, total_size):
        """Отчёт о прогрессе скачивания"""
        if total_size > 0:
            percent = int(block * block_size * 50 / total_size) + 10
            self.progress.emit(min(percent, 49))