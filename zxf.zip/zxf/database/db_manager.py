# database/db_manager.py
"""
Менеджер базы данных SQLite
Управление подключениями, миграциями, резервным копированием
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional

from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from database.models import Base


class DatabaseManager:
    """Менеджер базы данных"""
    
    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = Path.home() / ".proxmark3_studio" / "proxmark3_studio.db"
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.engine = None
        self.SessionLocal = None
        self._initialize()
    
    def _initialize(self):
        """Инициализация базы данных"""
        # Создаём engine
        self.engine = create_engine(
            f'sqlite:///{self.db_path}',
            connect_args={'check_same_thread': False},
            poolclass=StaticPool,
            echo=False
        )
        
        # Создаём таблицы
        Base.metadata.create_all(self.engine)
        
        # Создаём сессию
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # Включаем внешние ключи для SQLite
        @event.listens_for(self.engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    
    def get_session(self) -> Session:
        """Получение сессии базы данных"""
        return self.SessionLocal()
    
    def backup(self, backup_path: str = None) -> str:
        """Создание резервной копии базы данных"""
        if backup_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = self.db_path.parent / f"backup_{timestamp}.db"
        
        shutil.copy2(self.db_path, backup_path)
        return str(backup_path)
    
    def restore(self, backup_path: str) -> bool:
        """Восстановление базы данных из резервной копии"""
        try:
            shutil.copy2(backup_path, self.db_path)
            self._initialize()
            return True
        except Exception as e:
            print(f"Ошибка восстановления: {e}")
            return False
    
    def vacuum(self):
        """Оптимизация базы данных"""
        with self.engine.connect() as conn:
            conn.execute("VACUUM")
    
    def get_size(self) -> int:
        """Получение размера базы данных в байтах"""
        return self.db_path.stat().st_size if self.db_path.exists() else 0
    
    def export_to_json(self, json_path: str) -> bool:
        """Экспорт всей базы данных в JSON"""
        import json
        
        try:
            session = self.get_session()
            
            data = {
                'cards': [c.to_dict() for c in session.query(Card).all()],
                'keys': [k.to_dict() for k in session.query(Key).all()],
                'scripts': [s.to_dict() for s in session.query(Script).all()],
                'dumps': [d.to_dict() for d in session.query(Dump).all()],
                'export_date': datetime.now().isoformat()
            }
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            session.close()
            return True
            
        except Exception as e:
            print(f"Ошибка экспорта: {e}")
            return False
    
    def import_from_json(self, json_path: str) -> bool:
        """Импорт данных из JSON"""
        import json
        
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            session = self.get_session()
            
            # Очищаем таблицы (опционально)
            # session.query(Card).delete()
            # session.query(Key).delete()
            
            # Импортируем данные
            # (упрощённо, в реальности нужна более сложная логика)
            
            session.commit()
            session.close()
            return True
            
        except Exception as e:
            print(f"Ошибка импорта: {e}")
            return False