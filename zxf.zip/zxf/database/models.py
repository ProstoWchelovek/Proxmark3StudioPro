# database/models.py
"""
SQLAlchemy модели для базы данных Proxmark3 Studio Pro
"""

from sqlalchemy import (
    Column, Integer, String, DateTime, ForeignKey, Text, Boolean, 
    Float, LargeBinary, create_engine, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Card(Base):
    """Модель карты/метки"""
    __tablename__ = 'cards'
    
    id = Column(Integer, primary_key=True)
    uid = Column(String(32), unique=True, nullable=False, index=True)
    type = Column(String(50), nullable=False)
    name = Column(String(100), default="Unknown Card")
    manufacturer = Column(String(50))
    
    # Технические параметры
    atqa = Column(String(8))
    sak = Column(String(4))
    size = Column(Integer)  # Размер в байтах
    
    # Частотные характеристики
    frequency = Column(Float)  # Частота в Гц
    family = Column(String(20))  # LF, HF, UHF
    
    # Дополнительная информация
    note = Column(Text)
    tags = Column(String(200))
    icon_path = Column(String(200))
    
    # Временные метки
    created_at = Column(DateTime, default=datetime.now)
    last_seen = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    last_used = Column(DateTime)
    
    # Внешние ключи
    dump_id = Column(Integer, ForeignKey('dumps.id'), nullable=True)
    
    # Связи
    dump = relationship("Dump", back_populates="card")
    key_usages = relationship("KeyUsage", back_populates="card")
    
    # Индексы
    __table_args__ = (
        Index('idx_card_uid', 'uid'),
        Index('idx_card_type', 'type'),
        Index('idx_card_family', 'family'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'uid': self.uid,
            'type': self.type,
            'name': self.name,
            'manufacturer': self.manufacturer,
            'atqa': self.atqa,
            'sak': self.sak,
            'size': self.size,
            'frequency': self.frequency,
            'family': self.family,
            'note': self.note,
            'tags': self.tags,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_seen': self.last_seen.isoformat() if self.last_seen else None,
        }


class Key(Base):
    """Модель ключа доступа"""
    __tablename__ = 'keys'
    
    id = Column(Integer, primary_key=True)
    key = Column(String(16), nullable=False, index=True)  # HEX ключ
    key_type = Column(String(20), default="unknown")  # default, known, user, custom
    key_format = Column(String(10), default="HEX")  # HEX, DEC, BIN
    
    # Для Mifare: Key A или Key B
    key_side = Column(String(1))  # A или B
    
    # Дополнительная информация
    description = Column(Text)
    tags = Column(String(200))
    source = Column(String(100))  # Источник: файл, словарь, атака и т.д.
    
    # Статистика использования
    usage_count = Column(Integer, default=0)
    last_used = Column(DateTime)
    success_count = Column(Integer, default=0)
    
    # Криптографические параметры
    is_weak = Column(Boolean, default=False)
    entropy = Column(Float)
    
    # Временные метки
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Связи
    usages = relationship("KeyUsage", back_populates="key")
    
    # Индексы
    __table_args__ = (
        Index('idx_key_value', 'key'),
        Index('idx_key_type', 'key_type'),
        Index('idx_key_tags', 'tags'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'key': self.key,
            'key_type': self.key_type,
            'key_format': self.key_format,
            'description': self.description,
            'tags': self.tags,
            'source': self.source,
            'usage_count': self.usage_count,
            'is_weak': self.is_weak,
            'entropy': self.entropy,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class Script(Base):
    """Модель Lua/Python скрипта"""
    __tablename__ = 'scripts'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True, index=True)
    script_type = Column(String(10), default="lua")  # lua, python
    content = Column(Text, nullable=False)
    description = Column(Text)
    author = Column(String(100))
    version = Column(String(20), default="1.0")
    
    # Категория и теги
    category = Column(String(50))  # attack, utility, clone, etc.
    tags = Column(String(200))
    
    # Статистика
    usage_count = Column(Integer, default=0)
    is_favorite = Column(Boolean, default=False)
    is_builtin = Column(Boolean, default=False)
    
    # Временные метки
    created_at = Column(DateTime, default=datetime.now)
    modified_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Индексы
    __table_args__ = (
        Index('idx_script_name', 'name'),
        Index('idx_script_category', 'category'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'script_type': self.script_type,
            'description': self.description,
            'author': self.author,
            'version': self.version,
            'category': self.category,
            'tags': self.tags,
            'usage_count': self.usage_count,
            'is_favorite': self.is_favorite,
            'is_builtin': self.is_builtin,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class Dump(Base):
    """Модель дампа карты"""
    __tablename__ = 'dumps'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(200), nullable=False)
    file_path = Column(String(500), nullable=False, unique=True)
    file_size = Column(Integer)
    
    # Информация о карте
    card_uid = Column(String(32), index=True)
    card_type = Column(String(50))
    
    # Формат дампа
    dump_format = Column(String(20), default="binary")  # binary, eml, json
    
    # Хеш для проверки целостности
    md5_hash = Column(String(32))
    sha256_hash = Column(String(64))
    
    # Дополнительная информация
    description = Column(Text)
    tags = Column(String(200))
    is_corrupted = Column(Boolean, default=False)
    
    # Временные метки
    created_at = Column(DateTime, default=datetime.now)
    last_accessed = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Связи
    card = relationship("Card", back_populates="dump")
    
    # Индексы
    __table_args__ = (
        Index('idx_dump_filename', 'filename'),
        Index('idx_dump_card_uid', 'card_uid'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'filename': self.filename,
            'file_path': self.file_path,
            'file_size': self.file_size,
            'card_uid': self.card_uid,
            'card_type': self.card_type,
            'dump_format': self.dump_format,
            'md5_hash': self.md5_hash,
            'description': self.description,
            'tags': self.tags,
            'is_corrupted': self.is_corrupted,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class KeyUsage(Base):
    """Модель использования ключей (для статистики)"""
    __tablename__ = 'key_usage'
    
    id = Column(Integer, primary_key=True)
    key_id = Column(Integer, ForeignKey('keys.id'), nullable=False)
    card_id = Column(Integer, ForeignKey('cards.id'), nullable=False)
    
    sector = Column(Integer)  # Для Mifare
    key_type = Column(String(1))  # A или B
    success = Column(Boolean, default=True)
    
    # Контекст использования
    operation = Column(String(50))  # read, write, auth, attack
    attack_type = Column(String(50))  # nested, hardnested, darkside
    
    # Время
    timestamp = Column(DateTime, default=datetime.now)
    
    # Связи
    key = relationship("Key", back_populates="usages")
    card = relationship("Card", back_populates="key_usages")
    
    # Индексы
    __table_args__ = (
        Index('idx_key_usage_key', 'key_id'),
        Index('idx_key_usage_card', 'card_id'),
        Index('idx_key_usage_timestamp', 'timestamp'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'key_id': self.key_id,
            'card_id': self.card_id,
            'sector': self.sector,
            'key_type': self.key_type,
            'success': self.success,
            'operation': self.operation,
            'attack_type': self.attack_type,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
        }