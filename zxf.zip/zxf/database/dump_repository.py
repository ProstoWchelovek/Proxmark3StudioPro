# database/dump_repository.py
"""
Репозиторий для работы с дампами в базе данных
"""

import os
import hashlib
from typing import List, Optional, Dict
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import desc

from database.models import Dump


class DumpRepository:
    """Репозиторий дампов"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def add(self, dump: Dump) -> Dump:
        """Добавление нового дампа"""
        # Вычисляем хеши
        if os.path.exists(dump.file_path):
            dump.md5_hash = self._calculate_md5(dump.file_path)
            dump.sha256_hash = self._calculate_sha256(dump.file_path)
            dump.file_size = os.path.getsize(dump.file_path)
        
        self.session.add(dump)
        self.session.commit()
        return dump
    
    def get_by_id(self, dump_id: int) -> Optional[Dump]:
        """Получение дампа по ID"""
        return self.session.query(Dump).filter(Dump.id == dump_id).first()
    
    def get_by_filename(self, filename: str) -> Optional[Dump]:
        """Получение дампа по имени файла"""
        return self.session.query(Dump).filter(Dump.filename == filename).first()
    
    def get_by_card_uid(self, card_uid: str) -> List[Dump]:
        """Получение дампов по UID карты"""
        return self.session.query(Dump).filter(Dump.card_uid == card_uid).all()
    
    def get_all(self, limit: int = 100) -> List[Dump]:
        """Получение всех дампов"""
        return self.session.query(Dump).order_by(desc(Dump.created_at)).limit(limit).all()
    
    def get_recent(self, limit: int = 10) -> List[Dump]:
        """Получение последних дампов"""
        return self.session.query(Dump).order_by(desc(Dump.created_at)).limit(limit).all()
    
    def get_by_tags(self, tags: str) -> List[Dump]:
        """Получение дампов по тегам"""
        return self.session.query(Dump).filter(Dump.tags.contains(tags)).all()
    
    def update(self, dump_id: int, **kwargs) -> Optional[Dump]:
        """Обновление дампа"""
        dump = self.get_by_id(dump_id)
        if dump:
            for key, value in kwargs.items():
                if hasattr(dump, key):
                    setattr(dump, key, value)
            dump.last_accessed = datetime.now()
            self.session.commit()
        return dump
    
    def delete(self, dump_id: int, delete_file: bool = False) -> bool:
        """Удаление дампа"""
        dump = self.get_by_id(dump_id)
        if dump:
            # Удаляем файл если нужно
            if delete_file and os.path.exists(dump.file_path):
                os.remove(dump.file_path)
            
            self.session.delete(dump)
            self.session.commit()
            return True
        return False
    
    def search(self, query: str) -> List[Dump]:
        """Поиск дампов по имени, описанию, UID или тегам"""
        search_pattern = f"%{query}%"
        return self.session.query(Dump).filter(
            (Dump.filename.like(search_pattern)) |
            (Dump.description.like(search_pattern)) |
            (Dump.card_uid.like(search_pattern)) |
            (Dump.tags.like(search_pattern))
        ).all()
    
    def verify_integrity(self, dump_id: int) -> bool:
        """Проверка целостности дампа"""
        dump = self.get_by_id(dump_id)
        if not dump or not os.path.exists(dump.file_path):
            return False
        
        current_md5 = self._calculate_md5(dump.file_path)
        return current_md5 == dump.md5_hash
    
    def _calculate_md5(self, file_path: str) -> str:
        """Вычисление MD5 хеша файла"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    def _calculate_sha256(self, file_path: str) -> str:
        """Вычисление SHA256 хеша файла"""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    def count(self) -> int:
        """Количество дампов в базе"""
        return self.session.query(Dump).count()
    
    def get_total_size(self) -> int:
        """Общий размер всех дампов в байтах"""
        total = self.session.query(Dump).filter(Dump.file_size.isnot(None)).all()
        return sum(d.file_size for d in total if d.file_size)