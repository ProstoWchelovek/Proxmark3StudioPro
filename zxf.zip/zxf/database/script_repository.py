# database/script_repository.py
"""
Репозиторий для работы со скриптами в базе данных
"""

from typing import List, Optional, Dict
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import desc, func

from database.models import Script


class ScriptRepository:
    """Репозиторий скриптов"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def add(self, script: Script) -> Script:
        """Добавление нового скрипта"""
        self.session.add(script)
        self.session.commit()
        return script
    
    def get_by_id(self, script_id: int) -> Optional[Script]:
        """Получение скрипта по ID"""
        return self.session.query(Script).filter(Script.id == script_id).first()
    
    def get_by_name(self, name: str) -> Optional[Script]:
        """Получение скрипта по имени"""
        return self.session.query(Script).filter(Script.name == name).first()
    
    def get_all(self, limit: int = 100) -> List[Script]:
        """Получение всех скриптов"""
        return self.session.query(Script).limit(limit).all()
    
    def get_by_category(self, category: str) -> List[Script]:
        """Получение скриптов по категории"""
        return self.session.query(Script).filter(Script.category == category).all()
    
    def get_favorites(self) -> List[Script]:
        """Получение избранных скриптов"""
        return self.session.query(Script).filter(Script.is_favorite == True).all()
    
    def get_builtin(self) -> List[Script]:
        """Получение встроенных скриптов"""
        return self.session.query(Script).filter(Script.is_builtin == True).all()
    
    def get_user_scripts(self) -> List[Script]:
        """Получение пользовательских скриптов"""
        return self.session.query(Script).filter(Script.is_builtin == False).all()
    
    def get_recent(self, limit: int = 10) -> List[Script]:
        """Получение недавно использованных скриптов"""
        return self.session.query(Script).order_by(desc(Script.modified_at)).limit(limit).all()
    
    def update(self, script_id: int, **kwargs) -> Optional[Script]:
        """Обновление скрипта"""
        script = self.get_by_id(script_id)
        if script:
            for key, value in kwargs.items():
                if hasattr(script, key):
                    setattr(script, key, value)
            script.modified_at = datetime.now()
            self.session.commit()
        return script
    
    def delete(self, script_id: int) -> bool:
        """Удаление скрипта"""
        script = self.get_by_id(script_id)
        if script and not script.is_builtin:  # Не удаляем встроенные скрипты
            self.session.delete(script)
            self.session.commit()
            return True
        return False
    
    def search(self, query: str) -> List[Script]:
        """Поиск скриптов по имени, описанию, автору или тегам"""
        search_pattern = f"%{query}%"
        return self.session.query(Script).filter(
            (Script.name.like(search_pattern)) |
            (Script.description.like(search_pattern)) |
            (Script.author.like(search_pattern)) |
            (Script.tags.like(search_pattern))
        ).all()
    
    def increment_usage(self, script_id: int) -> None:
        """Увеличение счётчика использования скрипта"""
        script = self.get_by_id(script_id)
        if script:
            script.usage_count += 1
            self.session.commit()
    
    def toggle_favorite(self, script_id: int) -> bool:
        """Переключение статуса избранного"""
        script = self.get_by_id(script_id)
        if script:
            script.is_favorite = not script.is_favorite
            self.session.commit()
            return script.is_favorite
        return False
    
    def count(self) -> int:
        """Количество скриптов в базе"""
        return self.session.query(Script).count()