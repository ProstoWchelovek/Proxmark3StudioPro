# database/card_repository.py
"""
Репозиторий для работы с картами в базе данных
"""

from typing import List, Optional, Dict
from datetime import datetime
from sqlalchemy.orm import Session

from database.models import Card


class CardRepository:
    """Репозиторий карт"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def add(self, card: Card) -> Card:
        """Добавление новой карты"""
        self.session.add(card)
        self.session.commit()
        return card
    
    def get_by_id(self, card_id: int) -> Optional[Card]:
        """Получение карты по ID"""
        return self.session.query(Card).filter(Card.id == card_id).first()
    
    def get_by_uid(self, uid: str) -> Optional[Card]:
        """Получение карты по UID"""
        return self.session.query(Card).filter(Card.uid == uid).first()
    
    def get_all(self, limit: int = 100, offset: int = 0) -> List[Card]:
        """Получение всех карт"""
        return self.session.query(Card).offset(offset).limit(limit).all()
    
    def get_by_type(self, card_type: str) -> List[Card]:
        """Получение карт по типу"""
        return self.session.query(Card).filter(Card.type == card_type).all()
    
    def get_by_family(self, family: str) -> List[Card]:
        """Получение карт по семейству (LF/HF)"""
        return self.session.query(Card).filter(Card.family == family).all()
    
    def get_by_tags(self, tags: str) -> List[Card]:
        """Получение карт по тегам"""
        return self.session.query(Card).filter(Card.tags.contains(tags)).all()
    
    def get_recent(self, limit: int = 10) -> List[Card]:
        """Получение последних использованных карт"""
        return self.session.query(Card).order_by(Card.last_seen.desc()).limit(limit).all()
    
    def update(self, card_id: int, **kwargs) -> Optional[Card]:
        """Обновление карты"""
        card = self.get_by_id(card_id)
        if card:
            for key, value in kwargs.items():
                if hasattr(card, key):
                    setattr(card, key, value)
            card.last_seen = datetime.now()
            self.session.commit()
        return card
    
    def delete(self, card_id: int) -> bool:
        """Удаление карты"""
        card = self.get_by_id(card_id)
        if card:
            self.session.delete(card)
            self.session.commit()
            return True
        return False
    
    def search(self, query: str) -> List[Card]:
        """Поиск карт по UID, имени или тегам"""
        search_pattern = f"%{query}%"
        return self.session.query(Card).filter(
            (Card.uid.like(search_pattern)) |
            (Card.name.like(search_pattern)) |
            (Card.tags.like(search_pattern))
        ).all()
    
    def count(self) -> int:
        """Количество карт в базе"""
        return self.session.query(Card).count()
    
    def add_or_update(self, uid: str, **kwargs) -> Card:
        """Добавление или обновление карты"""
        card = self.get_by_uid(uid)
        if card:
            return self.update(card.id, **kwargs)
        else:
            new_card = Card(uid=uid, **kwargs)
            return self.add(new_card)