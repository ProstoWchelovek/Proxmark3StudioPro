# database/key_repository.py
"""
Репозиторий для работы с ключами в базе данных
"""

from typing import List, Optional, Dict, Tuple
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from database.models import Key, KeyUsage


class KeyRepository:
    """Репозиторий ключей"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def add(self, key: Key) -> Key:
        """Добавление нового ключа"""
        # Проверяем на дубликат
        existing = self.get_by_value(key.key)
        if existing:
            return existing
        
        self.session.add(key)
        self.session.commit()
        return key
    
    def get_by_id(self, key_id: int) -> Optional[Key]:
        """Получение ключа по ID"""
        return self.session.query(Key).filter(Key.id == key_id).first()
    
    def get_by_value(self, key_value: str) -> Optional[Key]:
        """Получение ключа по значению"""
        return self.session.query(Key).filter(Key.key == key_value.upper()).first()
    
    def get_all(self, limit: int = 1000) -> List[Key]:
        """Получение всех ключей"""
        return self.session.query(Key).limit(limit).all()
    
    def get_by_type(self, key_type: str) -> List[Key]:
        """Получение ключей по типу"""
        return self.session.query(Key).filter(Key.key_type == key_type).all()
    
    def get_by_tags(self, tags: str) -> List[Key]:
        """Получение ключей по тегам"""
        return self.session.query(Key).filter(Key.tags.contains(tags)).all()
    
    def get_most_used(self, limit: int = 20) -> List[Key]:
        """Получение наиболее часто используемых ключей"""
        return self.session.query(Key).order_by(desc(Key.usage_count)).limit(limit).all()
    
    def get_weak_keys(self) -> List[Key]:
        """Получение слабых ключей"""
        return self.session.query(Key).filter(Key.is_weak == True).all()
    
    def update(self, key_id: int, **kwargs) -> Optional[Key]:
        """Обновление ключа"""
        key = self.get_by_id(key_id)
        if key:
            for key_name, value in kwargs.items():
                if hasattr(key, key_name):
                    setattr(key, key_name, value)
            key.updated_at = datetime.now()
            self.session.commit()
        return key
    
    def delete(self, key_id: int) -> bool:
        """Удаление ключа"""
        key = self.get_by_id(key_id)
        if key:
            self.session.delete(key)
            self.session.commit()
            return True
        return False
    
    def delete_by_value(self, key_value: str) -> bool:
        """Удаление ключа по значению"""
        key = self.get_by_value(key_value)
        if key:
            self.session.delete(key)
            self.session.commit()
            return True
        return False
    
    def search(self, query: str) -> List[Key]:
        """Поиск ключей по значению, описанию или тегам"""
        search_pattern = f"%{query}%"
        return self.session.query(Key).filter(
            (Key.key.like(search_pattern)) |
            (Key.description.like(search_pattern)) |
            (Key.tags.like(search_pattern))
        ).all()
    
    def count(self) -> int:
        """Количество ключей в базе"""
        return self.session.query(Key).count()
    
    def count_unique(self) -> int:
        """Количество уникальных ключей"""
        return self.session.query(Key.key).distinct().count()
    
    def import_dictionary(self, keys: List[str], key_type: str = "dictionary", tags: str = None) -> int:
        """Импорт словаря ключей"""
        imported = 0
        for key_value in keys:
            existing = self.get_by_value(key_value)
            if not existing:
                key = Key(
                    key=key_value.upper(),
                    key_type=key_type,
                    tags=tags,
                    source="dictionary_import"
                )
                self.session.add(key)
                imported += 1
        
        self.session.commit()
        return imported
    
    def record_usage(self, key_id: int, card_id: int, success: bool = True, 
                     sector: int = None, key_type: str = None, operation: str = None) -> None:
        """Запись использования ключа"""
        usage = KeyUsage(
            key_id=key_id,
            card_id=card_id,
            sector=sector,
            key_type=key_type,
            success=success,
            operation=operation,
            timestamp=datetime.now()
        )
        
        # Обновляем счётчик использования ключа
        key = self.get_by_id(key_id)
        if key:
            key.usage_count += 1
            if success:
                key.success_count += 1
            key.last_used = datetime.now()
        
        self.session.add(usage)
        self.session.commit()
    
    def get_key_statistics(self) -> Dict:
        """Получение статистики по ключам"""
        total = self.count()
        unique = self.count_unique()
        
        by_type = self.session.query(Key.key_type, func.count(Key.id)).group_by(Key.key_type).all()
        
        weak_count = self.session.query(Key).filter(Key.is_weak == True).count()
        
        most_common = self.session.query(Key.key, Key.usage_count).order_by(desc(Key.usage_count)).limit(10).all()
        
        return {
            'total_keys': total,
            'unique_keys': unique,
            'by_type': dict(by_type),
            'weak_keys': weak_count,
            'most_common': most_common
        }