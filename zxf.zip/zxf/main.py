#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from pathlib import Path

# Добавляем пути для импорта
sys.path.insert(0, str(Path(__file__).parent))

from PySide6.QtWidgets import QApplication, QSplashScreen
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QIcon

from gui.main_window import MainWindow

def main():
    """Главная точка входа"""
    
    # Создаём приложение
    app = QApplication(sys.argv)
    app.setApplicationName("Proxmark3 Studio Pro")
    app.setOrganizationName("ProxmarkStudio")
    
    # Загрузка стилей
    try:
        with open("resources/styles/dark_theme.qss", "r") as f:
            app.setStyleSheet(f.read())
    except FileNotFoundError:
        print("Стиль не найден, используем стандартный")
    
    # Устанавливаем иконку приложения
    try:
        app.setWindowIcon(QIcon("resources/icons/app_icon.png"))
    except:
        pass
    
    # Заставка при загрузке
    splash_pixmap = QPixmap(500, 300)
    splash_pixmap.fill(Qt.GlobalColor.darkGray)
    splash = QSplashScreen(splash_pixmap)
    splash.show()
    splash.showMessage("Загрузка Proxmark3 Studio Pro...", 
                       Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                       Qt.GlobalColor.white)
    
    # Создаём и показываем главное окно
    window = MainWindow()
    
    # Закрываем заставку после загрузки
    QTimer.singleShot(1500, splash.close)
    
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()