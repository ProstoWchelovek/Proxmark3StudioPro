# Windows
pyinstaller --onefile --windowed --name="Proxmark3StudioPro" main.py

# macOS
pyinstaller --onefile --windowed --name="Proxmark3StudioPro" main.py

# Linux
python setup.py sdist bdist_wheel