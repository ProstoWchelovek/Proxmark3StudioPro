# decoders/iso14443.py
"""
Декодер для ISO14443-4 протокола (APDU команды)
"""

import re
from typing import Optional, Dict, List


class ISO14443Decoder:
    """Декодирование ISO14443-4/APDU команд"""
    
    # Коды команд (INS)
    COMMANDS = {
        'A4': {'name': 'SELECT', 'description': 'Выбор приложения/файла'},
        'B0': {'name': 'READ BINARY', 'description': 'Чтение бинарного файла'},
        'B2': {'name': 'READ RECORD', 'description': 'Чтение записи'},
        'C0': {'name': 'GET RESPONSE', 'description': 'Получение ответа'},
        'CA': {'name': 'GET DATA', 'description': 'Получение данных'},
        'D0': {'name': 'WRITE BINARY', 'description': 'Запись бинарных данных'},
        'D2': {'name': 'WRITE RECORD', 'description': 'Запись записи'},
        'DA': {'name': 'PUT DATA', 'description': 'Запись данных'},
        'E0': {'name': 'UPDATE BINARY', 'description': 'Обновление бинарного файла'},
        'E2': {'name': 'UPDATE RECORD', 'description': 'Обновление записи'},
        'F2': {'name': 'VERIFY', 'description': 'Проверка PIN'},
        '84': {'name': 'GET CHALLENGE', 'description': 'Получение challenge'},
        '82': {'name': 'EXTERNAL AUTH', 'description': 'Внешняя аутентификация'},
        '00': {'name': 'NOP', 'description': 'Нет операции'},
    }
    
    # Коды ответов (SW1, SW2)
    RESPONSES = {
        (0x90, 0x00): 'Успешно',
        (0x61, None): 'Данные доступны (Le={})',
        (0x62, 0x00): 'Информация не возвращена',
        (0x62, 0x81): 'Часть возвращённых данных может быть повреждена',
        (0x62, 0x82): 'Le превышает длину данных',
        (0x63, 0x00): 'Аутентификация не выполнена',
        (0x63, 0xC0): 'Проверка PIN - попыток осталось: {}',
        (0x64, 0x00): 'Ошибка выполнения',
        (0x65, 0x81): 'Ошибка памяти',
        (0x67, 0x00): 'Неправильная длина',
        (0x68, 0x00): 'Неправильный CLA',
        (0x69, 0x82): 'Небезопасный статус',
        (0x69, 0x85): 'Условия не выполнены',
        (0x69, 0x86): 'Команда не разрешена',
        (0x6A, 0x81): 'Функция не поддерживается',
        (0x6A, 0x82): 'Файл/приложение не найдены',
        (0x6A, 0x86): 'Неправильные параметры P1/P2',
        (0x6D, 0x00): 'Неизвестная команда',
        (0x6E, 0x00): 'Неправильный CLA',
    }
    
    @classmethod
    def decode_apdu(cls, apdu_hex: str) -> Dict:
        """
        Декодирование APDU команды
        
        Args:
            apdu_hex: HEX строка APDU команды
        
        Returns:
            Декодированная команда
        """
        apdu = apdu_hex.replace(' ', '').upper()
        
        if len(apdu) < 4:
            return {'error': 'APDU слишком короткая'}
        
        result = {
            'raw': apdu_hex,
            'cla': apdu[0:2],
            'ins': apdu[2:4],
            'p1': apdu[4:6] if len(apdu) >= 6 else '00',
            'p2': apdu[6:8] if len(apdu) >= 8 else '00',
        }
        
        # Определение команды
        ins = result['ins']
        if ins in cls.COMMANDS:
            result['command'] = cls.COMMANDS[ins]['name']
            result['description'] = cls.COMMANDS[ins]['description']
        else:
            result['command'] = 'Unknown'
        
        # Парсинг Lc/Le
        if len(apdu) >= 10:
            # Есть данные
            lc = apdu[8:10]
            lc_val = int(lc, 16)
            result['lc'] = lc
            result['lc_val'] = lc_val
            
            if len(apdu) >= 10 + lc_val * 2:
                data = apdu[10:10 + lc_val * 2]
                result['data'] = data
                
                if len(apdu) > 10 + lc_val * 2:
                    le = apdu[10 + lc_val * 2:12 + lc_val * 2]
                    result['le'] = le
        else:
            # Нет данных, возможно есть Le
            if len(apdu) >= 10:
                le = apdu[8:10]
                result['le'] = le
        
        return result
    
    @classmethod
    def decode_response(cls, response_hex: str) -> Dict:
        """
        Декодирование APDU ответа
        
        Args:
            response_hex: HEX строка ответа
        
        Returns:
            Декодированный ответ
        """
        response = response_hex.replace(' ', '').upper()
        
        if len(response) < 4:
            return {'error': 'Ответ слишком короткий'}
        
        # Последние 4 байта - SW1 SW2
        sw = response[-4:]
        sw1 = int(sw[0:2], 16)
        sw2 = int(sw[2:4], 16)
        
        data = response[:-4] if len(response) > 4 else ''
        
        result = {
            'raw': response_hex,
            'data': data,
            'sw1': f'{sw1:02X}',
            'sw2': f'{sw2:02X}',
            'status_word': f'{sw1:02X}{sw2:02X}'
        }
        
        # Определение статуса
        for (code1, code2), message in cls.RESPONSES.items():
            if code1 == sw1:
                if code2 is None or code2 == sw2:
                    if '{}' in message:
                        result['status'] = message.format(sw2)
                    else:
                        result['status'] = message
                    break
        else:
            result['status'] = f'Неизвестный статус'
        
        return result
    
    @classmethod
    def build_apdu(cls, cla: str, ins: str, p1: str, p2: str, data: str = '', le: str = '') -> str:
        """
        Сборка APDU команды из компонентов
        
        Args:
            cla: CLA байт
            ins: INS байт
            p1: P1 байт
            p2: P2 байт
            data: Дополнительные данные (HEX)
            le: Le байт (ожидаемая длина ответа)
        
        Returns:
            APDU команда в HEX
        """
        apdu = f"{cla}{ins}{p1}{p2}"
        
        if data:
            lc = f"{len(data) // 2:02X}"
            apdu += lc + data
        
        if le:
            apdu += le
        
        return apdu


class APDUAnalyzer:
    """Анализатор APDU трафика"""
    
    @staticmethod
    def analyze_trace(trace_data: str) -> List[Dict]:
        """
        Анализ трассировки APDU команд
        
        Args:
            trace_data: Трассировка команд
        
        Returns:
            Список проанализированных команд
        """
        results = []
        
        # Разделяем на команды (упрощенно)
        # В реальности нужно парсить вывод Proxmark3
        
        lines = trace_data.split('\n')
        
        for line in lines:
            # Ищем HEX строки
            hex_matches = re.findall(r'\b[0-9A-F]{4,}\b', line, re.IGNORECASE)
            
            for hex_str in hex_matches:
                # Пробуем декодировать как APDU
                if len(hex_str) >= 4:
                    if hex_str[0:2] in ['00', '80', '84', 'CA']:
                        # Возможно APDU команда
                        decoded = ISO14443Decoder.decode_apdu(hex_str)
                        results.append(decoded)
                    elif len(hex_str) >= 6 and hex_str[-4:].isalnum():
                        # Возможно APDU ответ
                        decoded = ISO14443Decoder.decode_response(hex_str)
                        results.append(decoded)
        
        return results