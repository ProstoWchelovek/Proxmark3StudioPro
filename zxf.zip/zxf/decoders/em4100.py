# decoders/em4100.py
"""
Декодер для EM4100 меток
"""

import re
from typing import Optional, Dict, List


class EM4100Decoder:
    """Декодирование EM4100 протокола"""
    
    # Таблица манчестерского кодирования
    MANCHESTER_TABLE = {
        '01': '0',
        '10': '1'
    }
    
    @classmethod
    def decode(cls, raw_data: str) -> Optional[Dict]:
        """
        Декодирование сырых данных EM4100
        
        Args:
            raw_data: HEX строка или бинарные данные
        
        Returns:
            Словарь с данными метки
        """
        # Если пришла HEX строка, конвертируем в биты
        if re.match(r'^[0-9A-Fa-f]+$', raw_data):
            bits = cls.hex_to_bits(raw_data)
        else:
            bits = raw_data
        
        # Ищем синхро-последовательность (9 единиц)
        sync_pattern = '1' * 9
        sync_pos = bits.find(sync_pattern)
        
        if sync_pos == -1:
            return None
        
        # Берем данные после синхронизации
        data_bits = bits[sync_pos + 9:sync_pos + 9 + 64]  # 64 бита данных
        
        if len(data_bits) < 64:
            return None
        
        # Декодируем манчестер
        decoded_bits = []
        for i in range(0, 64, 2):
            pair = data_bits[i:i+2]
            if pair in cls.MANCHESTER_TABLE:
                decoded_bits.append(cls.MANCHESTER_TABLE[pair])
            else:
                decoded_bits.append('?')
        
        decoded = ''.join(decoded_bits)
        
        # Парсим структуру EM4100
        # 40 бит данных + 14 бит паритета + 10 бит служебных
        # Формат: [9 синхро] [10 версия] [8 конфиг] [32 UID] [14 паритет]
        
        result = {
            'type': 'EM4100',
            'raw_bits': bits[:sync_pos + 9 + 64],
            'decoded_bits': decoded
        }
        
        # Извлекаем UID (32 бита после 18 бит служебных)
        if len(decoded) >= 50:
            uid_bits = decoded[18:50]  # 32 бита UID
            result['uid'] = cls.bits_to_hex(uid_bits)
            result['uid_decimal'] = int(uid_bits, 2) if uid_bits else 0
            
            # Версия
            version_bits = decoded[0:10]
            result['version'] = int(version_bits, 2) if version_bits else 0
            
            # Конфигурация
            config_bits = decoded[10:18]
            result['config'] = int(config_bits, 2) if config_bits else 0
        
        # Паритет
        parity_bits = decoded[50:64] if len(decoded) >= 64 else ''
        result['parity'] = parity_bits
        
        return result
    
    @classmethod
    def hex_to_bits(cls, hex_str: str) -> str:
        """Конвертация HEX в биты"""
        bits = ''
        for h in hex_str:
            if h in '0123456789ABCDEF':
                val = int(h, 16)
                bits += f'{val:04b}'
        return bits
    
    @classmethod
    def bits_to_hex(cls, bits: str) -> str:
        """Конвертация бит в HEX"""
        hex_str = ''
        for i in range(0, len(bits), 4):
            byte = bits[i:i+4]
            if len(byte) == 4:
                hex_str += f'{int(byte, 2):X}'
        return hex_str
    
    @classmethod
    def encode(cls, uid: str, version: int = 0, config: int = 0) -> str:
        """
        Кодирование данных в EM4100 формат
        
        Args:
            uid: UID (HEX строка)
            version: Версия (0-1023)
            config: Конфигурация (0-255)
        
        Returns:
            HEX строка готовой метки
        """
        # Конвертируем UID в биты
        uid_bits = ''
        for c in uid:
            uid_bits += f'{int(c, 16):04b}'
        
        uid_bits = uid_bits[:32]  # Только 32 бита
        
        # Служебные биты
        version_bits = f'{version:010b}'
        config_bits = f'{config:08b}'
        
        # Рассчитываем паритет
        # ... (упрощенно, полный расчет паритета опущен)
        parity_bits = '0' * 14
        
        # Полные данные
        data_bits = version_bits + config_bits + uid_bits + parity_bits
        
        # Манчестерское кодирование
        manchester_bits = ''
        for bit in data_bits:
            if bit == '0':
                manchester_bits += '01'
            else:
                manchester_bits += '10'
        
        # Добавляем синхро-последовательность
        full_bits = '1' * 9 + manchester_bits
        
        # Конвертируем в HEX
        hex_result = ''
        for i in range(0, len(full_bits), 4):
            byte = full_bits[i:i+4]
            if len(byte) == 4:
                hex_result += f'{int(byte, 2):X}'
        
        return hex_result


class EM4100Analyzer:
    """Анализатор EM4100 меток"""
    
    @staticmethod
    def analyze(raw_data: str) -> Dict:
        """Анализ EM4100 данных"""
        decoded = EM4100Decoder.decode(raw_data)
        
        if not decoded:
            return {'error': 'Не удалось декодировать EM4100'}
        
        result = {
            'valid': True,
            'uid': decoded.get('uid', 'Unknown'),
            'uid_decimal': decoded.get('uid_decimal', 0),
            'version': decoded.get('version', 0),
            'config': decoded.get('config', 0),
        }
        
        # Дополнительный анализ
        uid_decimal = result['uid_decimal']
        
        # Проверка на стандартные ID
        if uid_decimal < 1000:
            result['note'] = "Возможно тестовый ID"
        elif uid_decimal > 99999999:
            result['note'] = "Большой ID, возможно производитель"
        
        # Форматирование UID
        uid_hex = result['uid']
        uid_formatted = ' '.join(uid_hex[i:i+2] for i in range(0, len(uid_hex), 2))
        result['uid_formatted'] = uid_formatted
        
        return result