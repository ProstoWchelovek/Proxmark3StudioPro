# decoders/hid.py
"""
Декодер для HID Prox карт
"""

import re
from typing import Optional, Dict


class HIDDecoder:
    """Декодирование HID Prox протокола"""
    
    # Форматы HID карт
    FORMATS = {
        26: {'name': 'HID 26-bit', 'fc_bits': 8, 'cn_bits': 16},
        35: {'name': 'HID 35-bit', 'fc_bits': 12, 'cn_bits': 20},
        37: {'name': 'HID 37-bit', 'fc_bits': 12, 'cn_bits': 22},
        48: {'name': 'HID 48-bit', 'fc_bits': 16, 'cn_bits': 28},
    }
    
    @classmethod
    def decode(cls, raw_data: str) -> Optional[Dict]:
        """
        Декодирование HID данных
        
        Args:
            raw_data: HEX строка или бинарные данные
        
        Returns:
            Словарь с данными карты
        """
        # Конвертируем HEX в биты если нужно
        if re.match(r'^[0-9A-Fa-f]+$', raw_data):
            bits = cls.hex_to_bits(raw_data)
        else:
            bits = raw_data
        
        # Ищем преамбулу HID
        # HID использует манчестерское кодирование с преамбулой 010
        preamble = '010'
        preamble_pos = bits.find(preamble)
        
        if preamble_pos == -1:
            return None
        
        # Определяем формат по длине
        total_bits = len(bits) - preamble_pos
        
        best_format = None
        for fmt_len, fmt_info in cls.FORMATS.items():
            if abs(total_bits - fmt_len) < 3:
                best_format = fmt_info
                break
        
        if not best_format:
            # Пробуем стандартный 26-битный формат
            best_format = cls.FORMATS[26]
            data_bits = bits[preamble_pos + 3:preamble_pos + 3 + 26]
        else:
            data_bits = bits[preamble_pos + 3:preamble_pos + 3 + 26]  # Временно 26 бит
        
        if len(data_bits) < 26:
            return None
        
        # Парсинг 26-битного формата
        # 1 бит паритета + 8 бит FC + 16 бит CN + 1 бит паритета
        parity_bit1 = data_bits[0]
        facility_bits = data_bits[1:9]
        card_bits = data_bits[9:25]
        parity_bit2 = data_bits[25]
        
        facility_code = int(facility_bits, 2) if facility_bits else 0
        card_number = int(card_bits, 2) if card_bits else 0
        
        # Расчет паритета
        # ... (упрощенно)
        
        result = {
            'type': best_format['name'],
            'format_bits': len(data_bits),
            'facility_code': facility_code,
            'card_number': card_number,
            'raw_bits': data_bits,
            'hex': cls.bits_to_hex(data_bits)
        }
        
        # Дополнительная информация
        result['id'] = f"{facility_code}:{card_number}"
        
        return result
    
    @classmethod
    def hex_to_bits(cls, hex_str: str) -> str:
        """Конвертация HEX в биты"""
        bits = ''
        for h in hex_str:
            if h in '0123456789ABCDEF':
                val = int(h, 16)
                bits += f'{val:04b}'
        return bits
    
    @classmethod
    def bits_to_hex(cls, bits: str) -> str:
        """Конвертация бит в HEX"""
        hex_str = ''
        for i in range(0, len(bits), 4):
            byte = bits[i:i+4]
            if len(byte) == 4:
                hex_str += f'{int(byte, 2):X}'
        return hex_str
    
    @classmethod
    def encode(cls, facility_code: int, card_number: int, format_bits: int = 26) -> str:
        """
        Кодирование HID карты
        
        Args:
            facility_code: Facility Code (0-255 для 26 бит)
            card_number: Card Number (0-65535 для 26 бит)
            format_bits: Формат (26, 35, 37, 48)
        
        Returns:
            HEX строка
        """
        if format_bits not in cls.FORMATS:
            format_bits = 26
        
        fmt = cls.FORMATS[format_bits]
        
        # Формируем биты
        fc_bits = f'{facility_code:0{fmt["fc_bits"]}b}'
        cn_bits = f'{card_number:0{fmt["cn_bits"]}b}'
        
        # Паритет (упрощенно)
        parity1 = '0'
        parity2 = '0'
        
        # Полные биты
        bits = parity1 + fc_bits + cn_bits + parity2
        
        # Конвертируем в HEX
        hex_result = ''
        for i in range(0, len(bits), 4):
            byte = bits[i:i+4]
            if len(byte) == 4:
                hex_result += f'{int(byte, 2):X}'
        
        return hex_result


class HIDAnalyzer:
    """Анализатор HID карт"""
    
    @staticmethod
    def analyze(raw_data: str) -> Dict:
        """Анализ HID данных"""
        decoded = HIDDecoder.decode(raw_data)
        
        if not decoded:
            return {'error': 'Не удалось декодировать HID'}
        
        result = {
            'valid': True,
            'type': decoded.get('type', 'Unknown'),
            'facility_code': decoded.get('facility_code', 0),
            'card_number': decoded.get('card_number', 0),
            'id': decoded.get('id', ''),
            'hex': decoded.get('hex', '')
        }
        
        # Дополнительный анализ
        fc = result['facility_code']
        cn = result['card_number']
        
        # Определение возможного производителя/системы
        if fc < 10:
            result['note'] = "Маленький Facility Code - возможно тестовая система"
        elif fc > 200:
            result['note'] = "Большой Facility Code - возможно крупная организация"
        
        # Форматирование
        result['formatted'] = f"FC:{fc:03d}, CN:{cn:05d}"
        
        return result