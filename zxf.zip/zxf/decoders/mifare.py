# decoders/mifare.py
"""
Декодер для Mifare карт (Classic, Ultralight, DESFire)
"""

import re
from typing import Optional, Dict


class MifareDecoder:
    """Декодирование Mifare карт"""
    
    # Типы карт
    CARD_TYPES = {
        (0x04, 0x08): {'name': 'Mifare Classic 1K', 'size': 1024, 'sectors': 16},
        (0x04, 0x18): {'name': 'Mifare Classic 4K', 'size': 4096, 'sectors': 40},
        (0x04, 0x00): {'name': 'Mifare Ultralight', 'size': 64, 'pages': 16},
        (0x04, 0x20): {'name': 'Mifare DESFire', 'size': 4096, 'type': 'DESFire'},
        (0x04, 0x28): {'name': 'Mifare DESFire EV2', 'size': 8192},
        (0x44, 0x00): {'name': 'Mifare Ultralight C', 'size': 192},
    }
    
    @classmethod
    def decode_uid(cls, raw_data: str) -> Optional[Dict]:
        """
        Декодирование UID из данных
        
        Args:
            raw_data: HEX строка UID или дампа
        
        Returns:
            Словарь с UID информацией
        """
        # Очищаем от пробелов
        uid_hex = raw_data.replace(' ', '').replace(':', '').upper()
        
        # Разные длины UID
        uid_lengths = {
            4: '4 байта (single size)',
            7: '7 байт (double size)',
            10: '10 байт (triple size)'
        }
        
        length = len(uid_hex) // 2
        
        result = {
            'uid': uid_hex,
            'uid_formatted': ' '.join(uid_hex[i:i+2] for i in range(0, len(uid_hex), 2)),
            'length': length,
            'length_desc': uid_lengths.get(length, 'unknown')
        }
        
        # Производитель по первому байту
        if len(uid_hex) >= 2:
            manufacturer_byte = uid_hex[0:2]
            manufacturers = {
                '04': 'NXP Semiconductors',
                '08': 'NXP Semiconductors',
                '44': 'NXP Semiconductors (Ultralight C)',
                '28': 'Infineon Technologies',
                '30': 'Gemalto',
            }
            result['manufacturer'] = manufacturers.get(manufacturer_byte, 'Unknown')
        
        # ATQA (для Classic)
        if len(uid_hex) >= 8:
            atqa = uid_hex[4:8]
            result['atqa'] = atqa
        
        # SAK
        if len(uid_hex) >= 8:
            sak = uid_hex[8:10] if len(uid_hex) >= 10 else uid_hex[6:8]
            result['sak'] = sak
            
            # Определение типа карты по SAK
            sak_val = int(sak, 16) if sak else 0
            if sak_val & 0x08:
                result['card_type'] = 'Mifare Classic'
            elif sak_val & 0x20:
                result['card_type'] = 'Mifare Ultralight'
            elif sak_val & 0x28:
                result['card_type'] = 'Mifare DESFire'
        
        return result
    
    @classmethod
    def decode_sector_trailer(cls, data: str) -> Dict:
        """
        Декодирование трейлера сектора
        
        Args:
            data: 16 байт трейлера в HEX
        
        Returns:
            Информация о трейлере
        """
        data = data.replace(' ', '')
        
        if len(data) < 32:
            return {'error': 'Недостаточно данных'}
        
        key_a = data[0:12]
        access_bits = data[12:20]
        key_b = data[20:32]
        
        result = {
            'key_a': key_a,
            'key_b': key_b,
            'access_bits': access_bits
        }
        
        # Анализ access bits
        result['key_a_readable'] = key_a != 'FFFFFFFFFFFF'
        result['key_a_writable'] = key_a != '000000000000'
        
        # Декодирование прав доступа (упрощенно)
        if access_bits:
            try:
                access_val = int(access_bits, 16)
                result['access_decoded'] = cls.decode_access_bits(access_val)
            except:
                pass
        
        return result
    
    @classmethod
    def decode_access_bits(cls, access_val: int) -> Dict:
        """Декодирование access bits"""
        # Упрощенная версия
        return {
            'c1': (access_val >> 2) & 1,
            'c2': (access_val >> 3) & 1,
            'c3': (access_val >> 4) & 1,
        }
    
    @classmethod
    def identify_card(cls, atqa: str, sak: str) -> Dict:
        """Идентификация карты по ATQA и SAK"""
        try:
            atqa_val = int(atqa, 16) if atqa else 0
            sak_val = int(sak, 16) if sak else 0
            
            key = (atqa_val & 0xFF, sak_val)
            
            if key in cls.CARD_TYPES:
                return cls.CARD_TYPES[key]
            
            # Дополнительная логика
            if sak_val == 0x08:
                return {'name': 'Mifare Classic 1K', 'size': 1024}
            elif sak_val == 0x18:
                return {'name': 'Mifare Classic 4K', 'size': 4096}
            elif sak_val == 0x00 or sak_val == 0x20:
                return {'name': 'Mifare Ultralight', 'size': 64}
            
        except:
            pass
        
        return {'name': 'Unknown', 'size': 0}


class MifareAnalyzer:
    """Анализатор Mifare дампов"""
    
    @staticmethod
    def analyze_dump(dump_data: bytes) -> Dict:
        """Анализ дампа Mifare карты"""
        size = len(dump_data)
        
        result = {
            'size': size,
            'size_kb': size // 1024,
            'type': 'Unknown'
        }
        
        # Определение типа по размеру
        if size == 1024:
            result['type'] = 'Mifare Classic 1K'
            result['sectors'] = 16
            result['blocks_per_sector'] = 4
        elif size == 4096:
            result['type'] = 'Mifare Classic 4K'
            result['sectors'] = 40
            result['blocks_per_sector'] = 4
        elif size <= 512:
            result['type'] = 'Mifare Ultralight'
            result['pages'] = size // 4
        
        # Поиск трейлеров
        if result['type'].startswith('Mifare Classic'):
            trailers = []
            sector_size = 64  # 4 блока * 16 байт
            
            for sector in range(result['sectors']):
                trailer_offset = sector * sector_size + 48
                if trailer_offset + 16 <= size:
                    trailer = dump_data[trailer_offset:trailer_offset + 16]
                    trailer_hex = trailer.hex()
                    
                    key_a = trailer_hex[0:12]
                    key_b = trailer_hex[20:32]
                    
                    trailers.append({
                        'sector': sector,
                        'key_a': key_a,
                        'key_b': key_b,
                        'key_a_default': key_a == 'ffffffffffff',
                        'key_b_default': key_b == 'ffffffffffff'
                    })
            
            result['trailers'] = trailers
            
            # Подсчёт найденных ключей
            default_keys = sum(1 for t in trailers if t['key_a_default'])
            result['default_keys_count'] = default_keys
            result['custom_keys_count'] = len(trailers) - default_keys
        
        return result