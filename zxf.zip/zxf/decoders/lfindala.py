# decoders/lf/indala.py
"""
Декодер для Indala меток
"""

import re
from typing import Optional, Dict


class IndalaDecoder:
    """Декодирование Indala меток"""
    
    @staticmethod
    def decode(raw_data: str) -> Optional[Dict]:
        """
        Декодирование Indala данных
        
        Args:
            raw_data: HEX строка или бинарные данные
        
        Returns:
            Словарь с данными метки
        """
        # Очистка данных
        data = raw_data.replace(' ', '').replace(':', '').upper()
        
        # Поиск ID
        id_match = re.search(r'([0-9A-F]{8,16})', data)
        if not id_match:
            return None
        
        uid = id_match.group(1)
        
        result = {
            'type': 'Indala',
            'uid': uid,
            'uid_formatted': ' '.join(uid[i:i+2] for i in range(0, len(uid), 2)),
            'raw': raw_data
        }
        
        # Конвертация в десятичный
        try:
            result['decimal'] = int(uid, 16)
        except:
            pass
        
        return result
    
    @staticmethod
    def encode(uid: str) -> str:
        """Кодирование Indala метки"""
        return uid.upper()