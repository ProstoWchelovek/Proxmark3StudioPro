# Сборка .exe (Windows)
pyinstaller --onefile --windowed --name="Proxmark3StudioPro" --icon=resources/icons/app.ico main.py

# Сборка .app (macOS)
pyinstaller --onefile --windowed --name="Proxmark3StudioPro" --icon=resources/icons/app.icns main.py

# Сборка .deb (Linux)
python3 setup.py sdist bdist_wheel