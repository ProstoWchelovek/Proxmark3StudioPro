# setup.py
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="proxmark3-studio-pro",
    version="2.0.0",
    author="Proxmark Studio Team",
    author_email="support@proxmark-studio.com",
    description="Professional GUI for Proxmark3",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/proxmark3-studio-pro",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "PySide6>=6.6.0",
        "pyserial>=3.5",
        "cryptography>=41.0.0",
        "numpy>=1.24.0",
        "sqlalchemy>=2.0.0",
        "lupa>=2.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-qt>=4.2.0",
            "pyqtgraph>=0.13.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "proxmark3-studio=main:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: Scientific/Engineering",
    ],
    python_requires=">=3.10",
)