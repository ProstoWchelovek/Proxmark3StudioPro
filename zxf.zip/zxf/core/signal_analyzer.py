# core/signal_analyzer.py
"""
Анализ LF и HF сигналов Proxmark3
Включает демодуляцию, фильтрацию, FFT анализ и определение типа модуляции
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import re


class ModulationType(Enum):
    """Типы модуляции"""
    ASK = "ASK"
    FSK = "FSK"
    PSK = "PSK"
    BPSK = "BPSK"
    UNKNOWN = "Unknown"


class EncodingType(Enum):
    """Типы кодирования"""
    MANCHESTER = "Manchester"
    BIPHASE = "Biphase"
    MILLER = "Miller"
    NRZ = "NRZ"
    UNKNOWN = "Unknown"


@dataclass
class SignalInfo:
    """Информация о сигнале"""
    frequency: float
    modulation: ModulationType
    encoding: EncodingType
    amplitude: float
    snr: float
    bit_rate: float
    samples: np.ndarray
    confidence: float


class SignalAnalyzer:
    """Анализатор сигналов Proxmark3"""
    
    def __init__(self):
        self.sample_rate = 2000000  # 2 MHz для LF, 13.56 MHz для HF
        self.current_signal = None
        
    def capture_signal(self, pm3, frequency: str = "LF", duration_ms: int = 10) -> Optional[np.ndarray]:
        """
        Захват сигнала с Proxmark3
        
        Args:
            pm3: Экземпляр PM3Client
            frequency: "LF" или "HF"
            duration_ms: Длительность захвата в мс
        
        Returns:
            Массив сэмплов сигнала
        """
        if frequency.upper() == "LF":
            cmd = f"lf sample {duration_ms}"
        else:
            cmd = f"hf 14a read"
        
        output = pm3.run_command(cmd)
        
        # Парсим вывод и извлекаем сэмплы
        samples = self._parse_samples(output)
        
        if samples is not None:
            self.current_signal = samples
            
        return samples
    
    def _parse_samples(self, output: str) -> Optional[np.ndarray]:
        """Парсинг сэмплов из вывода Proxmark3"""
        # Ищем строки вида: Samples: [1, 2, 3, ...]
        match = re.search(r'Samples?:\s*\[(.*?)\]', output, re.IGNORECASE)
        if match:
            try:
                samples_str = match.group(1)
                samples = np.array([int(x.strip()) for x in samples_str.split(',') if x.strip()])
                return samples
            except:
                pass
        
        # Альтернативный формат: просто список чисел
        numbers = re.findall(r'-?\d+', output)
        if len(numbers) > 10:
            try:
                samples = np.array([int(x) for x in numbers])
                return samples
            except:
                pass
        
        return None
    
    def analyze_signal(self, samples: np.ndarray = None) -> SignalInfo:
        """
        Анализ сигнала: частота, модуляция, кодирование
        
        Args:
            samples: Массив сэмплов (если None, использует текущий)
        
        Returns:
            SignalInfo с результатами анализа
        """
        if samples is None:
            samples = self.current_signal
            
        if samples is None or len(samples) < 10:
            raise ValueError("Нет данных сигнала для анализа")
        
        # FFT анализ для определения частоты
        frequency = self._estimate_frequency(samples)
        
        # Определение модуляции
        modulation = self._detect_modulation(samples)
        
        # Определение кодирования
        encoding = self._detect_encoding(samples)
        
        # Амплитуда и SNR
        amplitude = np.max(np.abs(samples))
        noise_floor = np.std(samples[:100]) if len(samples) > 100 else np.std(samples)
        snr = 20 * np.log10(amplitude / (noise_floor + 1e-10))
        
        # Битрейт
        bit_rate = self._estimate_bit_rate(samples)
        
        # Уверенность анализа
        confidence = self._calculate_confidence(modulation, encoding, snr)
        
        return SignalInfo(
            frequency=frequency,
            modulation=modulation,
            encoding=encoding,
            amplitude=amplitude,
            snr=snr,
            bit_rate=bit_rate,
            samples=samples,
            confidence=confidence
        )
    
    def _estimate_frequency(self, samples: np.ndarray) -> float:
        """Оценка частоты сигнала через FFT"""
        fft = np.fft.fft(samples)
        freqs = np.fft.fftfreq(len(samples), 1/self.sample_rate)
        
        # Ищем доминирующую частоту (исключая DC)
        magnitude = np.abs(fft)
        magnitude[0] = 0  # Убираем DC компоненту
        
        if len(magnitude) > 1:
            peak_idx = np.argmax(magnitude[1:]) + 1
            freq = abs(freqs[peak_idx])
            
            # Округляем до ближайшего стандартного значения
            if 120 < freq < 130:
                return 125.0
            elif 130 < freq < 140:
                return 134.2
            elif 13e6 < freq < 14e6:
                return 13.56e6
            else:
                return freq
        return 0
    
    def _detect_modulation(self, samples: np.ndarray) -> ModulationType:
        """Определение типа модуляции"""
        # Нормализуем сигнал
        normalized = samples / (np.max(np.abs(samples)) + 1e-10)
        
        # Анализ гистограммы амплитуд
        hist, bins = np.histogram(normalized, bins=20)
        peaks = np.where(hist > np.mean(hist) * 2)[0]
        
        # ASK: 2 или более чётких уровня амплитуды
        if len(peaks) >= 2:
            return ModulationType.ASK
        
        # FSK: проверяем изменение частоты
        # (упрощённо - считаем нули)
        zero_crossings = np.where(np.diff(np.sign(samples)) != 0)[0]
        if len(zero_crossings) > 10:
            # Проверяем вариацию расстояний между переходами
            distances = np.diff(zero_crossings)
            if np.std(distances) / np.mean(distances) > 0.5:
                return ModulationType.FSK
        
        # PSK: проверяем фазу
        return ModulationType.PSK
    
    def _detect_encoding(self, samples: np.ndarray) -> EncodingType:
        """Определение типа кодирования"""
        # Демодулируем сигнал (упрощённо)
        # В реальности нужно больше логики
        
        # Проверка на манчестерское кодирование
        # Характерная особенность: переход в середине бита
        normalized = samples / (np.max(np.abs(samples)) + 1e-10)
        
        # Ищем паттерны
        # ... упрощённая логика
        
        return EncodingType.MANCHESTER
    
    def _estimate_bit_rate(self, samples: np.ndarray) -> float:
        """Оценка битрейта"""
        # Ищем нулевые переходы
        zero_crossings = np.where(np.diff(np.sign(samples)) != 0)[0]
        
        if len(zero_crossings) < 2:
            return 0
        
        # Среднее расстояние между переходами
        avg_distance = np.mean(np.diff(zero_crossings))
        
        # Битрейт = sample_rate / (среднее расстояние * 2) для манчестера
        bit_rate = self.sample_rate / (avg_distance * 2)
        
        # Округляем до стандартных значений
        if 1000 < bit_rate < 10000:
            return 4000  # 4 kbps для LF
        elif 10000 < bit_rate < 100000:
            return 10600  # 10.6 kbps для LF
        elif 100000 < bit_rate < 1000000:
            return 106000  # 106 kbps для HF
        
        return bit_rate
    
    def _calculate_confidence(self, modulation: ModulationType, encoding: EncodingType, snr: float) -> float:
        """Расчёт уверенности анализа"""
        confidence = 50.0  # Базовая уверенность
        
        if modulation != ModulationType.UNKNOWN:
            confidence += 15
        if encoding != EncodingType.UNKNOWN:
            confidence += 15
        
        # SNR вклад
        if snr > 20:
            confidence += 20
        elif snr > 10:
            confidence += 10
        
        return min(confidence, 100.0)
    
    def demodulate(self, samples: np.ndarray, modulation: ModulationType = None) -> str:
        """
        Демодуляция сигнала в биты
        
        Args:
            samples: Массив сэмплов
            modulation: Тип модуляции (если None, определяется автоматически)
        
        Returns:
            Строка битов
        """
        if modulation is None:
            info = self.analyze_signal(samples)
            modulation = info.modulation
        
        bits = ""
        
        if modulation == ModulationType.ASK:
            # ASK демодуляция: пороговая обработка
            threshold = np.mean(samples) + 0.3 * np.std(samples)
            bits = ''.join('1' if s > threshold else '0' for s in samples[::10])
        
        elif modulation == ModulationType.FSK:
            # FSK демодуляция: анализ нулевых переходов
            zero_crossings = np.where(np.diff(np.sign(samples)) != 0)[0]
            # ... упрощённо
            bits = '0' * len(zero_crossings)
        
        else:
            # PSK демодуляция
            # ... упрощённо
            bits = ''
        
        return bits
    
    def decode_manchester(self, bits: str) -> str:
        """Декодирование манчестерского кодирования"""
        decoded = []
        
        for i in range(0, len(bits) - 1, 2):
            if i + 1 < len(bits):
                if bits[i] == '0' and bits[i+1] == '1':
                    decoded.append('0')
                elif bits[i] == '1' and bits[i+1] == '0':
                    decoded.append('1')
        
        return ''.join(decoded)
    
    def filter_signal(self, samples: np.ndarray, filter_type: str = "lowpass", cutoff: float = 10000) -> np.ndarray:
        """
        Фильтрация сигнала
        
        Args:
            samples: Входной сигнал
            filter_type: "lowpass", "highpass", "bandpass"
            cutoff: Частота среза (Гц)
        
        Returns:
            Отфильтрованный сигнал
        """
        from scipy import signal
        
        # Нормализованная частота
        nyquist = self.sample_rate / 2
        normalized_cutoff = cutoff / nyquist
        
        if filter_type == "lowpass":
            b, a = signal.butter(4, normalized_cutoff, btype='low')
        elif filter_type == "highpass":
            b, a = signal.butter(4, normalized_cutoff, btype='high')
        elif filter_type == "bandpass":
            b, a = signal.butter(4, [normalized_cutoff/2, normalized_cutoff], btype='band')
        else:
            return samples
        
        filtered = signal.filtfilt(b, a, samples)
        
        return filtered
    
    def get_fft_plot_data(self, samples: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Получение данных для FFT графика
        
        Returns:
            (частоты, амплитуды)
        """
        fft = np.fft.fft(samples)
        freqs = np.fft.fftfreq(len(samples), 1/self.sample_rate)
        magnitude = np.abs(fft)
        
        # Берём только положительные частоты
        positive_idx = freqs > 0
        return freqs[positive_idx], magnitude[positive_idx]