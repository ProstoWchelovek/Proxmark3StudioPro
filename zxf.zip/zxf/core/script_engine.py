# core/script_engine.py
"""
Движок для выполнения Lua скриптов на Proxmark3
Поддержка пользовательских скриптов и автоматизации
"""

import os
from typing import Dict, List, Optional, Callable
from pathlib import Path


class ScriptEngine:
    """Движок выполнения Lua скриптов"""
    
    def __init__(self, pm3):
        self.pm3 = pm3
        self.scripts_dir = Path.home() / ".proxmark3_studio" / "scripts"
        self.scripts_dir.mkdir(parents=True, exist_ok=True)
        self.current_script = None
        self.is_running = False
        self.callbacks = []
    
    def run_script(self, script_path: str, callback: Callable = None) -> str:
        """
        Выполнение Lua скрипта через Proxmark3
        
        Args:
            script_path: Путь к Lua скрипту
            callback: Функция обратного вызова для прогресса
        
        Returns:
            Вывод выполнения скрипта
        """
        self.current_script = script_path
        self.is_running = True
        
        if callback:
            self.callbacks.append(callback)
        
        # Запуск скрипта через Proxmark3
        cmd = f"script run {script_path}"
        output = self.pm3.run_command(cmd)
        
        self.is_running = False
        self.current_script = None
        
        return output
    
    def run_script_content(self, script_content: str, name: str = "temp.lua") -> str:
        """
        Выполнение скрипта из строки
        
        Args:
            script_content: Содержимое скрипта
            name: Имя временного файла
        
        Returns:
            Вывод выполнения скрипта
        """
        # Сохраняем временный файл
        temp_path = self.scripts_dir / name
        with open(temp_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        # Выполняем
        result = self.run_script(str(temp_path))
        
        # Удаляем временный файл
        try:
            os.remove(temp_path)
        except:
            pass
        
        return result
    
    def list_scripts(self) -> List[Dict]:
        """Получение списка доступных скриптов"""
        scripts = []
        
        for file in self.scripts_dir.glob("*.lua"):
            scripts.append({
                'name': file.name,
                'path': str(file),
                'size': file.stat().st_size,
                'modified': file.stat().st_mtime
            })
        
        return scripts
    
    def get_script_content(self, script_name: str) -> Optional[str]:
        """Получение содержимого скрипта"""
        script_path = self.scripts_dir / script_name
        
        if script_path.exists():
            with open(script_path, 'r', encoding='utf-8') as f:
                return f.read()
        return None
    
    def save_script(self, script_name: str, content: str) -> bool:
        """Сохранение скрипта"""
        try:
            script_path = self.scripts_dir / script_name
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Ошибка сохранения скрипта: {e}")
            return False
    
    def delete_script(self, script_name: str) -> bool:
        """Удаление скрипта"""
        try:
            script_path = self.scripts_dir / script_name
            if script_path.exists():
                os.remove(script_path)
            return True
        except Exception as e:
            print(f"Ошибка удаления скрипта: {e}")
            return False
    
    def stop_script(self) -> bool:
        """Остановка выполнения скрипта"""
        if self.is_running:
            self.pm3.send_command("\x03")  # Ctrl+C
            self.is_running = False
            return True
        return False
    
    def get_builtin_scripts(self) -> List[Dict]:
        """Получение встроенных скриптов"""
        return [
            {
                'name': 'mf_default_keys.lua',
                'description': 'Проверка стандартных ключей Mifare',
                'author': 'Proxmark3 Team'
            },
            {
                'name': 'mf_nested_attack.lua',
                'description': 'Автоматическая Nested атака',
                'author': 'Proxmark3 Team'
            },
            {
                'name': 'htmldump.lua',
                'description': 'Создание HTML отчёта по дампу',
                'author': 'Proxmark3 Team'
            },
            {
                'name': 'keys_bruteforce.lua',
                'description': 'Брутфорс ключей по словарю',
                'author': 'Proxmark3 Team'
            },
            {
                'name': 'card_cloner.lua',
                'description': 'Автоматическое клонирование карты',
                'author': 'Proxmark3 Team'
            }
        ]
    
    def create_template(self, template_type: str = "basic") -> str:
        """Создание шаблона скрипта"""
        templates = {
            "basic": '''-- Basic Proxmark3 Lua Script
-- Generated by Proxmark3 Studio Pro

local pm3 = require('pm3')

function main()
    print("=== Script Started ===")
    
    -- Read card info
    local result = pm3.command('hf 14a reader')
    print(result)
    
    print("=== Script Finished ===")
    return 0
end

main()
''',
            "attack": '''-- Attack Script Template
-- Proxmark3 Studio Pro

local pm3 = require('pm3')

function nested_attack(known_key, sector)
    print("Starting nested attack on sector " .. sector)
    local cmd = "hf mf nested 1 0 " .. known_key .. " " .. sector .. " A t"
    return pm3.command(cmd)
end

function main()
    print("=== Attack Script Started ===")
    
    -- Add your attack logic here
    local known_key = "FFFFFFFFFFFF"
    local result = nested_attack(known_key, 0)
    print(result)
    
    print("=== Attack Script Finished ===")
    return 0
end

main()
''',
            "clone": '''-- Card Cloning Script
-- Proxmark3 Studio Pro

local pm3 = require('pm3')

function clone_card()
    print("Cloning card...")
    
    -- Read source card
    local uid = pm3.command('hf 14a reader')
    print("Source UID: " .. uid)
    
    -- Clone to target
    -- Add cloning logic here
    
    return true
end

function main()
    clone_card()
    return 0
end

main()
'''
        }
        
        return templates.get(template_type, templates["basic"])
    
    def validate_syntax(self, script_content: str) -> List[str]:
        """
        Валидация синтаксиса Lua скрипта (базовая)
        
        Returns:
            Список ошибок
        """
        errors = []
        
        # Проверка на наличие pm3
        if 'pm3' not in script_content and 'require' not in script_content:
            errors.append("Скрипт не содержит ссылок на pm3")
        
        # Проверка на функцию main
        if 'function main' not in script_content:
            errors.append("Скрипт не содержит функцию main()")
        
        # Проверка на незакрытые скобки
        if script_content.count('(') != script_content.count(')'):
            errors.append("Несоответствие количества открывающих и закрывающих скобок")
        
        return errors