# core/hardware_detector.py
"""
Определение версии и типа устройства Proxmark3
"""

import re
from typing import Dict, Optional, List
from dataclasses import dataclass
from enum import Enum


class ProxmarkModel(Enum):
    """Модели Proxmark3"""
    PM3_EASY = "Proxmark3 Easy"
    PM3_RDV4 = "Proxmark3 RDV4"
    PM3_RDV2 = "Proxmark3 RDV2"
    PM3_RDV1 = "Proxmark3 RDV1"
    PM3_BT = "Proxmark3 BT"
    UNKNOWN = "Unknown"


@dataclass
class HardwareInfo:
    """Информация об устройстве"""
    model: ProxmarkModel
    firmware_version: str
    firmware_commit: str
    firmware_date: str
    flash_size: int
    ram_size: int
    has_bluetooth: bool
    has_fpga: bool
    has_rfid: bool
    uptime: float


class HardwareDetector:
    """Детектор аппаратного обеспечения Proxmark3"""
    
    def __init__(self):
        self.hardware_info: Optional[HardwareInfo] = None
    
    def detect(self, pm3) -> HardwareInfo:
        """
        Определение информации об устройстве
        
        Args:
            pm3: Экземпляр PM3Client
        
        Returns:
            HardwareInfo с информацией об устройстве
        """
        # Получаем версию
        version_output = pm3.run_command("hw version")
        
        # Парсим вывод
        model = self._detect_model(version_output)
        fw_version = self._parse_firmware_version(version_output)
        fw_commit = self._parse_commit(version_output)
        fw_date = self._parse_build_date(version_output)
        
        # Получаем статус
        status_output = pm3.run_command("hw status")
        
        flash_size = self._parse_flash_size(status_output)
        ram_size = self._parse_ram_size(status_output)
        uptime = self._parse_uptime(status_output)
        
        # Определяем наличие опций
        has_bluetooth = "BT" in version_output.upper() or "Bluetooth" in version_output
        has_fpga = "FPGA" in version_output.upper()
        has_rfid = True  # Все Proxmark имеют RFID
        
        self.hardware_info = HardwareInfo(
            model=model,
            firmware_version=fw_version,
            firmware_commit=fw_commit,
            firmware_date=fw_date,
            flash_size=flash_size,
            ram_size=ram_size,
            has_bluetooth=has_bluetooth,
            has_fpga=has_fpga,
            has_rfid=has_rfid,
            uptime=uptime
        )
        
        return self.hardware_info
    
    def _detect_model(self, output: str) -> ProxmarkModel:
        """Определение модели Proxmark3"""
        output_upper = output.upper()
        
        if "RDV4" in output_upper:
            return ProxmarkModel.PM3_RDV4
        elif "EASY" in output_upper:
            return ProxmarkModel.PM3_EASY
        elif "BT" in output_upper:
            return ProxmarkModel.PM3_BT
        elif "RDV2" in output_upper:
            return ProxmarkModel.PM3_RDV2
        elif "RDV1" in output_upper:
            return ProxmarkModel.PM3_RDV1
        else:
            return ProxmarkModel.UNKNOWN
    
    def _parse_firmware_version(self, output: str) -> str:
        """Парсинг версии прошивки"""
        match = re.search(r'v([\d.]+)', output, re.IGNORECASE)
        return match.group(1) if match else "Unknown"
    
    def _parse_commit(self, output: str) -> str:
        """Парсинг commit hash"""
        match = re.search(r'commit:\s*([a-f0-9]+)', output, re.IGNORECASE)
        return match.group(1) if match else "Unknown"
    
    def _parse_build_date(self, output: str) -> str:
        """Парсинг даты сборки"""
        match = re.search(r'built\s+(\d{4}-\d{2}-\d{2})', output, re.IGNORECASE)
        return match.group(1) if match else "Unknown"
    
    def _parse_flash_size(self, output: str) -> int:
        """Парсинг размера flash"""
        match = re.search(r'Flash:\s*(\d+)\s*KB', output, re.IGNORECASE)
        return int(match.group(1)) if match else 0
    
    def _parse_ram_size(self, output: str) -> int:
        """Парсинг размера RAM"""
        match = re.search(r'RAM:\s*(\d+)\s*KB', output, re.IGNORECASE)
        return int(match.group(1)) if match else 0
    
    def _parse_uptime(self, output: str) -> float:
        """Парсинг времени работы"""
        match = re.search(r'Uptime:\s*(\d+)\s*seconds', output, re.IGNORECASE)
        return float(match.group(1)) if match else 0
    
    def is_rdv4(self) -> bool:
        """Проверка, является ли устройство RDV4"""
        return self.hardware_info and self.hardware_info.model == ProxmarkModel.PM3_RDV4
    
    def get_supported_frequencies(self) -> List[str]:
        """Получение списка поддерживаемых частот"""
        return ["LF (125kHz)", "HF (13.56MHz)"]  # Все модели поддерживают LF и HF
    
    def get_recommended_settings(self) -> Dict:
        """Рекомендованные настройки для текущего устройства"""
        if self.is_rdv4():
            return {
                'baudrate': 921600,
                'timeout': 5,
                'max_power': True,
                'bt_supported': True
            }
        else:
            return {
                'baudrate': 115200,
                'timeout': 3,
                'max_power': False,
                'bt_supported': False
            }