# core/pm3_client.py
"""
Клиент для работы с Proxmark3 через последовательный порт
"""

import serial
import serial.tools.list_ports
import time
import re
from typing import Optional, List, Dict
from PySide6.QtCore import QObject, Signal


class PM3Client(QObject):
    """Клиент для взаимодействия с Proxmark3"""
    
    # Сигналы для обновления UI
    status_changed = Signal(bool)
    progress_changed = Signal(int, str)
    data_received = Signal(str)
    
    def __init__(self):
        super().__init__()
        self.serial_connection: Optional[serial.Serial] = None
        self.is_connected = False
        self.baudrate = 115200
        self.timeout = 5
        self.port = None
    
    def connect(self, port: str = None, baudrate: int = 115200) -> bool:
        """
        Подключение к Proxmark3
        
        Args:
            port: COM-порт или устройство (например, COM3, /dev/ttyACM0)
            baudrate: Скорость (по умолчанию 115200)
        
        Returns:
            True при успешном подключении
        """
        if port is None:
            ports = self.list_ports()
            if not ports:
                return False
            port = ports[0]
        
        try:
            self.serial_connection = serial.Serial(
                port=port,
                baudrate=baudrate,
                timeout=self.timeout,
                write_timeout=self.timeout
            )
            # Небольшая пауза для инициализации
            time.sleep(0.5)
            self.serial_connection.flushInput()
            self.serial_connection.flushOutput()
            
            # Проверяем связь через команду hw version
            response = self._send_raw_cmd("hw version")
            if response and ("proxmark" in response.lower() or "PM3" in response):
                self.is_connected = True
                self.port = port
                self.baudrate = baudrate
                self.status_changed.emit(True)
                return True
            else:
                self.disconnect()
                return False
                
        except Exception as e:
            print(f"Ошибка подключения: {e}")
            self.disconnect()
            return False
    
    def disconnect(self):
        """Отключение от Proxmark3"""
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
        self.serial_connection = None
        self.is_connected = False
        self.status_changed.emit(False)
    
    def list_ports(self) -> List[str]:
        """Список доступных COM-портов"""
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]
    
    def _send_raw_cmd(self, cmd: str, wait_for_prompt: bool = True) -> str:
        """
        Отправка сырой команды и получение ответа
        
        Args:
            cmd: Команда (без перевода строки)
            wait_for_prompt: Ожидать приглашение pm3-->
        
        Returns:
            Вывод команды
        """
        if not self.serial_connection or not self.serial_connection.is_open:
            return "ERROR: Not connected"
        
        try:
            # Очищаем буферы
            self.serial_connection.reset_input_buffer()
            self.serial_connection.reset_output_buffer()
            
            # Отправляем команду
            command = cmd.strip() + "\n"
            self.serial_connection.write(command.encode())
            
            # Ждем ответ
            response_lines = []
            timeout_start = time.time()
            
            while True:
                if self.serial_connection.in_waiting:
                    line = self.serial_connection.readline().decode('utf-8', errors='replace').rstrip('\r\n')
                    response_lines.append(line)
                    
                    # Если ждем приглашение и получили его - выходим
                    if wait_for_prompt and ("pm3-->" in line or "> " in line):
                        break
                
                if time.time() - timeout_start > self.timeout:
                    response_lines.append("ERROR: Timeout")
                    break
                
                time.sleep(0.01)
            
            return "\n".join(response_lines)
            
        except Exception as e:
            return f"ERROR: {str(e)}"
    
    def run_command(self, cmd: str) -> str:
        """
        Выполнение команды Proxmark3 с автоматическим парсингом
        
        Args:
            cmd: Команда (например, "hf 14a reader")
        
        Returns:
            Вывод команды
        """
        if not self.is_connected:
            return "ERROR: Device not connected"
        
        # Отправляем команду и получаем ответ
        response = self._send_raw_cmd(cmd)
        
        # Убираем лишние приглашения
        lines = response.split('\n')
        cleaned = []
        for line in lines:
            if "pm3-->" not in line and not line.startswith("> "):
                cleaned.append(line)
        
        result = "\n".join(cleaned).strip()
        
        # Эмитируем сигнал о получении данных
        self.data_received.emit(result)
        
        return result
    
    def send_command(self, cmd: str) -> None:
        """Отправка команды без ожидания ответа (для интерактивных режимов)"""
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.write((cmd + "\n").encode())
    
    def get_hardware_info(self) -> Dict[str, str]:
        """Получение информации об устройстве"""
        if not self.is_connected:
            return {}
        
        output = self.run_command("hw version")
        info = {}
        
        # Парсим модель
        if "Proxmark3 Easy" in output:
            info['device'] = 'Proxmark3 Easy'
        elif "RDV4" in output:
            info['device'] = 'Proxmark3 RDV4'
        else:
            info['device'] = 'Proxmark3'
        
        # Версия
        match = re.search(r'v([\d.]+)', output)
        if match:
            info['version'] = match.group(1)
        
        # Commit
        match = re.search(r'commit:\s*([a-f0-9]+)', output, re.IGNORECASE)
        if match:
            info['commit'] = match.group(1)
        
        return info