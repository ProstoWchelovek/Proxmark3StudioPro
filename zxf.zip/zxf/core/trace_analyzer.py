# core/trace_analyzer.py
"""
Анализ трассировки протоколов Proxmark3
Анализ обмена между ридером и картой, экспорт в Wireshark
"""

import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class TraceDirection(Enum):
    """Направление трассировки"""
    READER_TO_CARD = "Reader -> Card"
    CARD_TO_READER = "Card -> Reader"
    UNKNOWN = "Unknown"


@dataclass
class TraceEntry:
    """Одна запись трассировки"""
    timestamp: float
    direction: TraceDirection
    data: bytes
    protocol: str
    decoded: Optional[str] = None


@dataclass
class TraceAnalysis:
    """Результаты анализа трассировки"""
    total_entries: int
    duration: float
    commands: List[Dict]
    responses: List[Dict]
    errors: List[str]
    protocol: str
    summary: str


class TraceAnalyzer:
    """Анализатор трассировки протоколов"""
    
    def __init__(self):
        self.trace_entries: List[TraceEntry] = []
    
    def parse_trace(self, trace_output: str) -> List[TraceEntry]:
        """
        Парсинг вывода команды trace list
        
        Args:
            trace_output: Вывод Proxmark3 команды trace list
        
        Returns:
            Список записей трассировки
        """
        entries = []
        
        lines = trace_output.split('\n')
        
        for line in lines:
            entry = self._parse_line(line)
            if entry:
                entries.append(entry)
        
        self.trace_entries = entries
        return entries
    
    def _parse_line(self, line: str) -> Optional[TraceEntry]:
        """Парсинг одной строки трассировки"""
        # Формат: [123.45] RDR->CARD: 00 A4 04 00 08 ...
        pattern = r'\[?([\d.]+)\]?\s*([Rr][Dd][Rr]|[Cc][Aa][Rr][Dd])\s*[-=]>\s*([Rr][Dd][Rr]|[Cc][Aa][Rr][Dd])?:\s*([0-9A-Fa-f\s]+)'
        
        match = re.search(pattern, line)
        if not match:
            return None
        
        timestamp = float(match.group(1))
        direction_str = match.group(2).upper()
        
        if direction_str == "RDR" or "READER" in direction_str:
            direction = TraceDirection.READER_TO_CARD
        elif direction_str == "CARD":
            direction = TraceDirection.CARD_TO_READER
        else:
            direction = TraceDirection.UNKNOWN
        
        # Парсим данные
        data_hex = re.sub(r'\s+', '', match.group(4))
        data = bytes.fromhex(data_hex) if data_hex else b''
        
        # Определяем протокол
        protocol = self._detect_protocol(data)
        
        # Декодируем если возможно
        decoded = self._decode_data(data, protocol)
        
        return TraceEntry(
            timestamp=timestamp,
            direction=direction,
            data=data,
            protocol=protocol,
            decoded=decoded
        )
    
    def _detect_protocol(self, data: bytes) -> str:
        """Определение протокола по данным"""
        if len(data) < 2:
            return "Unknown"
        
        # ISO14443-4 APDU
        if data[0] in [0x00, 0x80, 0x84, 0xCA]:
            if data[1] in [0xA4, 0xB0, 0xC0, 0xD0]:
                return "ISO14443-4 APDU"
        
        # Mifare Classic
        if len(data) >= 4:
            if data[0] == 0x60:  # auth
                return "Mifare Classic Auth"
            elif data[0] == 0x30:  # read
                return "Mifare Classic Read"
            elif data[0] == 0xA0:  # write
                return "Mifare Classic Write"
        
        # ISO15693
        if len(data) >= 2 and data[0] in [0x01, 0x02, 0x20, 0x21, 0x22, 0x24]:
            return "ISO15693"
        
        # FeliCa
        if len(data) >= 2 and data[0] == 0x00 and data[1] == 0x00:
            return "FeliCa"
        
        return "Unknown Protocol"
    
    def _decode_data(self, data: bytes, protocol: str) -> Optional[str]:
        """Декодирование данных в зависимости от протокола"""
        if protocol == "ISO14443-4 APDU":
            return self._decode_apdu(data)
        elif protocol == "Mifare Classic Read":
            return f"Read block {data[1]}"
        elif protocol == "Mifare Classic Write":
            return f"Write block {data[1]}"
        else:
            return data.hex().upper()
    
    def _decode_apdu(self, data: bytes) -> str:
        """Декодирование APDU команды/ответа"""
        if len(data) < 4:
            return data.hex()
        
        cla = data[0]
        ins = data[1]
        p1 = data[2]
        p2 = data[3]
        
        apdu_commands = {
            0xA4: "SELECT",
            0xB0: "READ BINARY",
            0xC0: "GET RESPONSE",
            0xCA: "GET DATA",
            0xD0: "WRITE BINARY",
            0xDA: "PUT DATA",
            0x84: "GET CHALLENGE",
            0x82: "EXTERNAL AUTH",
        }
        
        command_name = apdu_commands.get(ins, f"INS:{ins:02X}")
        
        if len(data) > 4:
            return f"{command_name} P1:{p1:02X} P2:{p2:02X} Data:{data[4:].hex()}"
        else:
            return f"{command_name} P1:{p1:02X} P2:{p2:02X}"
    
    def analyze(self, trace_entries: List[TraceEntry] = None) -> TraceAnalysis:
        """
        Анализ трассировки
        
        Returns:
            TraceAnalysis с результатами
        """
        if trace_entries is None:
            trace_entries = self.trace_entries
        
        if not trace_entries:
            return TraceAnalysis(
                total_entries=0,
                duration=0,
                commands=[],
                responses=[],
                errors=[],
                protocol="Unknown",
                summary="Нет данных"
            )
        
        commands = []
        responses = []
        errors = []
        
        for entry in trace_entries:
            if entry.direction == TraceDirection.READER_TO_CARD:
                commands.append({
                    'time': entry.timestamp,
                    'data': entry.data.hex(),
                    'decoded': entry.decoded,
                    'protocol': entry.protocol
                })
            else:
                responses.append({
                    'time': entry.timestamp,
                    'data': entry.data.hex(),
                    'decoded': entry.decoded,
                    'protocol': entry.protocol
                })
            
            # Поиск ошибок
            if entry.data and entry.data[0] in [0x6A, 0x6D, 0x6E]:
                errors.append(f"Error at {entry.timestamp}: {entry.data.hex()}")
        
        duration = trace_entries[-1].timestamp - trace_entries[0].timestamp if len(trace_entries) > 1 else 0
        
        # Определение основного протокола
        protocols = set(e.protocol for e in trace_entries if e.protocol != "Unknown")
        main_protocol = protocols.pop() if protocols else "Unknown"
        
        # Сводка
        summary = (
            f"Всего записей: {len(trace_entries)}\n"
            f"Длительность: {duration:.3f} сек\n"
            f"Команд: {len(commands)}\n"
            f"Ответов: {len(responses)}\n"
            f"Ошибок: {len(errors)}"
        )
        
        return TraceAnalysis(
            total_entries=len(trace_entries),
            duration=duration,
            commands=commands,
            responses=responses,
            errors=errors,
            protocol=main_protocol,
            summary=summary
        )
    
    def export_to_wireshark(self, filename: str, trace_entries: List[TraceEntry] = None) -> bool:
        """
        Экспорт трассировки в формат для Wireshark (pcap)
        
        Args:
            filename: Путь для сохранения файла
            trace_entries: Список записей (если None, использует текущий)
        
        Returns:
            True если успешно
        """
        if trace_entries is None:
            trace_entries = self.trace_entries
        
        if not trace_entries:
            return False
        
        try:
            import struct
            
            with open(filename, 'wb') as f:
                # PCAP заголовок
                # magic_number, version_major, version_minor, thiszone, sigfigs, snaplen, network
                pcap_header = struct.pack('IHHIIII', 0xA1B2C3D4, 2, 4, 0, 0, 65535, 185)  # 185 = ISO14443
                f.write(pcap_header)
                
                prev_time = trace_entries[0].timestamp
                
                for entry in trace_entries:
                    # PCAP пакетный заголовок
                    ts_sec = int(entry.timestamp)
                    ts_usec = int((entry.timestamp - ts_sec) * 1000000)
                    incl_len = len(entry.data)
                    orig_len = incl_len
                    
                    packet_header = struct.pack('IIII', ts_sec, ts_usec, incl_len, orig_len)
                    f.write(packet_header)
                    f.write(entry.data)
                    
                    prev_time = entry.timestamp
            
            return True
            
        except Exception as e:
            print(f"Ошибка экспорта в Wireshark: {e}")
            return False
    
    def find_patterns(self, trace_entries: List[TraceEntry] = None) -> Dict:
        """Поиск паттернов в трассировке"""
        if trace_entries is None:
            trace_entries = self.trace_entries
        
        patterns = {
            'repeating_commands': [],
            'long_responses': [],
            'suspicious_packets': []
        }
        
        # Поиск повторяющихся команд
        cmd_data = {}
        for entry in trace_entries:
            if entry.direction == TraceDirection.READER_TO_CARD:
                key = entry.data.hex()
                if key not in cmd_data:
                    cmd_data[key] = []
                cmd_data[key].append(entry.timestamp)
        
        for cmd, times in cmd_data.items():
            if len(times) > 3:
                patterns['repeating_commands'].append({
                    'command': cmd,
                    'count': len(times),
                    'first': times[0],
                    'last': times[-1]
                })
        
        # Поиск длинных ответов
        for entry in trace_entries:
            if entry.direction == TraceDirection.CARD_TO_READER and len(entry.data) > 50:
                patterns['long_responses'].append({
                    'time': entry.timestamp,
                    'length': len(entry.data),
                    'data': entry.data.hex()[:50] + "..."
                })
        
        return patterns
    
    def get_statistics(self) -> Dict:
        """Получение статистики по трассировке"""
        if not self.trace_entries:
            return {}
        
        stats = {
            'total_packets': len(self.trace_entries),
            'reader_to_card': sum(1 for e in self.trace_entries if e.direction == TraceDirection.READER_TO_CARD),
            'card_to_reader': sum(1 for e in self.trace_entries if e.direction == TraceDirection.CARD_TO_READER),
            'protocols': {},
            'avg_packet_size': 0,
            'max_packet_size': 0,
            'min_packet_size': float('inf')
        }
        
        total_size = 0
        
        for entry in self.trace_entries:
            # Протоколы
            if entry.protocol not in stats['protocols']:
                stats['protocols'][entry.protocol] = 0
            stats['protocols'][entry.protocol] += 1
            
            # Размеры пакетов
            size = len(entry.data)
            total_size += size
            stats['max_packet_size'] = max(stats['max_packet_size'], size)
            stats['min_packet_size'] = min(stats['min_packet_size'], size)
        
        stats['avg_packet_size'] = total_size / len(self.trace_entries) if self.trace_entries else 0
        
        return stats