# core/protocol_detector.py
"""
Определение протоколов RFID/NFC карт
Автоматическое распознавание типа метки по ответу
"""

import re
from typing import Dict, Optional, List, Tuple
from enum import Enum
from dataclasses import dataclass


class ProtocolFamily(Enum):
    """Семейства протоколов"""
    LF = "LF"
    HF = "HF"
    UHF = "UHF"
    UNKNOWN = "Unknown"


@dataclass
class ProtocolInfo:
    """Информация о протоколе"""
    name: str
    family: ProtocolFamily
    frequency: float
    description: str
    detection_patterns: List[str]
    manufacturer: str
    commands: List[str] = None
    
    def __post_init__(self):
        if self.commands is None:
            self.commands = []


class ProtocolDetector:
    """Детектор протоколов RFID/NFC карт"""
    
    def __init__(self):
        self.protocols = self._init_protocols()
    
    def _init_protocols(self) -> Dict[str, ProtocolInfo]:
        """Инициализация базы протоколов"""
        return {
            # ==================== LF ПРОТОКОЛЫ ====================
            "EM4100": ProtocolInfo(
                name="EM4100",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="EM Microelectronic 125kHz RFID tag",
                detection_patterns=["EM410", "EM4100", "EM4102", "ID:"],
                manufacturer="EM Microelectronic",
                commands=["lf em 410x read", "lf em 410x clone", "lf em 410x sim"]
            ),
            "EM4x50": ProtocolInfo(
                name="EM4x50",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="EM Microelectronic 4x50 series",
                detection_patterns=["EM4x50", "EM4450", "EM4469"],
                manufacturer="EM Microelectronic",
                commands=["lf em 4x50 read", "lf em 4x50 write"]
            ),
            "HID Prox": ProtocolInfo(
                name="HID Prox",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="HID Proximity card 125kHz",
                detection_patterns=["HID", "Prox", "FC:", "CN:"],
                manufacturer="HID Global",
                commands=["lf hid read", "lf hid clone", "lf hid sim"]
            ),
            "HID Corporate": ProtocolInfo(
                name="HID Corporate",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="HID Corporate 1000",
                detection_patterns=["Corporate", "HID 1000"],
                manufacturer="HID Global",
                commands=["lf hid read --corporate"]
            ),
            "Indala": ProtocolInfo(
                name="Indala",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Indala RFID tag",
                detection_patterns=["Indala", "Motorola"],
                manufacturer="Motorola/Indala",
                commands=["lf indala read", "lf indala clone", "lf indala sim"]
            ),
            "AWID": ProtocolInfo(
                name="AWID",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="AWID proximity card",
                detection_patterns=["AWID"],
                manufacturer="AWID",
                commands=["lf awid read", "lf awid clone", "lf awid sim"]
            ),
            "T55x7": ProtocolInfo(
                name="T55x7",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Atmel T55x7 configurable tag",
                detection_patterns=["T55", "T55x7", "T5557", "T5567"],
                manufacturer="Atmel/Microchip",
                commands=["lf t55xx read", "lf t55xx write", "lf t55xx dump"]
            ),
            "EM4305": ProtocolInfo(
                name="EM4305",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="EM4305 configurable tag",
                detection_patterns=["EM4305"],
                manufacturer="EM Microelectronic",
                commands=["lf em4305 read", "lf em4305 write", "lf em4305 dump"]
            ),
            "FDX-B": ProtocolInfo(
                name="FDX-B",
                family=ProtocolFamily.LF,
                frequency=134200,
                description="ISO11784/5 animal ID tag",
                detection_patterns=["FDX", "ISO11784", "Animal"],
                manufacturer="Various",
                commands=["lf fdx read", "lf fdx clone", "lf fdx sim"]
            ),
            "HDX": ProtocolInfo(
                name="HDX",
                family=ProtocolFamily.LF,
                frequency=134200,
                description="HDX animal ID tag",
                detection_patterns=["HDX"],
                manufacturer="Various",
                commands=["lf hdx read"]
            ),
            "Hitag 1": ProtocolInfo(
                name="Hitag 1",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="NXP Hitag 1 transponder",
                detection_patterns=["Hitag 1", "Hitag1"],
                manufacturer="NXP",
                commands=["lf hitag read --tag1"]
            ),
            "Hitag 2": ProtocolInfo(
                name="Hitag 2",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="NXP Hitag 2 transponder",
                detection_patterns=["Hitag 2", "Hitag2"],
                manufacturer="NXP",
                commands=["lf hitag read --tag2"]
            ),
            "Hitag S": ProtocolInfo(
                name="Hitag S",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="NXP Hitag S transponder",
                detection_patterns=["Hitag S", "HitagS"],
                manufacturer="NXP",
                commands=["lf hitag read --tags"]
            ),
            "PCF7931": ProtocolInfo(
                name="PCF7931",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="NXP PCF7931 transponder",
                detection_patterns=["PCF7931"],
                manufacturer="NXP",
                commands=["lf pcf7931 read"]
            ),
            "PCF7936": ProtocolInfo(
                name="PCF7936",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="NXP PCF7936 transponder",
                detection_patterns=["PCF7936"],
                manufacturer="NXP",
                commands=["lf pcf7936 read"]
            ),
            "Viking": ProtocolInfo(
                name="Viking",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Viking format",
                detection_patterns=["Viking"],
                manufacturer="Viking",
                commands=["lf viking read", "lf viking clone", "lf viking sim"]
            ),
            "Nexwatch": ProtocolInfo(
                name="Nexwatch",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Nexwatch proximity card",
                detection_patterns=["Nexwatch"],
                manufacturer="Nexwatch",
                commands=["lf nexwatch read"]
            ),
            "Keri": ProtocolInfo(
                name="Keri",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Keri MS series",
                detection_patterns=["Keri"],
                manufacturer="Keri",
                commands=["lf keri read"]
            ),
            "PAC/Stanley": ProtocolInfo(
                name="PAC/Stanley",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="PAC/Stanley format",
                detection_patterns=["PAC", "Stanley"],
                manufacturer="Stanley",
                commands=["lf pac read"]
            ),
            "Presco": ProtocolInfo(
                name="Presco",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Presco format",
                detection_patterns=["Presco"],
                manufacturer="Presco",
                commands=["lf presco read"]
            ),
            "IO Prox": ProtocolInfo(
                name="IO Prox",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="IO Prox",
                detection_patterns=["IO Prox"],
                manufacturer="IO",
                commands=["lf io read"]
            ),
            "Gallagher": ProtocolInfo(
                name="Gallagher",
                family=ProtocolFamily.LF,
                frequency=125000,
                description="Gallagher format",
                detection_patterns=["Gallagher"],
                manufacturer="Gallagher",
                commands=["lf gallagher read"]
            ),
            
            # ==================== HF ПРОТОКОЛЫ ====================
            "Mifare Classic": ProtocolInfo(
                name="Mifare Classic",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="NXP Mifare Classic 1K/4K",
                detection_patterns=["Mifare Classic", "MF Classic", "SAK: 08", "SAK: 18", "ATQA: 00 04"],
                manufacturer="NXP",
                commands=["hf mf rdsc", "hf mf dump", "hf mf nested", "hf mf hardnested"]
            ),
            "Mifare Ultralight": ProtocolInfo(
                name="Mifare Ultralight",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="NXP Mifare Ultralight/NTAG",
                detection_patterns=["Ultralight", "NTAG", "UL", "SAK: 00", "ATQA: 00 44"],
                manufacturer="NXP",
                commands=["hf mfu dump", "hf mfu read", "hf mfu info", "hf mfu auth"]
            ),
            "Mifare DESFire": ProtocolInfo(
                name="Mifare DESFire",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="NXP Mifare DESFire EV1/EV2/EV3",
                detection_patterns=["DESFire", "EV1", "EV2", "EV3", "SAK: 20", "ATQA: 03 44"],
                manufacturer="NXP",
                commands=["hf desfire info", "hf desfire apps", "hf desfire create_app"]
            ),
            "iClass": ProtocolInfo(
                name="iClass",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="HID iClass credential",
                detection_patterns=["iClass", "ICLASS", "CSN:", "HID iClass"],
                manufacturer="HID Global",
                commands=["hf iclass read", "hf iclass dump", "hf iclass sim", "hf iclass clone"]
            ),
            "ISO15693": ProtocolInfo(
                name="ISO15693",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="ISO15693 vicinity card",
                detection_patterns=["ISO15693", "ICODE", "SLIX", "Tag-it"],
                manufacturer="Various",
                commands=["hf 15 reader", "hf 15 dump", "hf 15 readblock", "hf 15 writeblock"]
            ),
            "ISO14443-4": ProtocolInfo(
                name="ISO14443-4",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="ISO14443-4 smart card",
                detection_patterns=["ISO14443-4", "APDU", "T=CL"],
                manufacturer="Various",
                commands=["hf 14a apdu", "hf 14a reader"]
            ),
            "FeliCa": ProtocolInfo(
                name="FeliCa",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="Sony FeliCa card",
                detection_patterns=["FeliCa", "IDm:", "PMm:"],
                manufacturer="Sony",
                commands=["hf felica reader", "hf felica dump", "hf felica sim"]
            ),
            "LEGIC": ProtocolInfo(
                name="LEGIC",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="LEGIC advant/mobile",
                detection_patterns=["LEGIC", "LEGIC prime"],
                manufacturer="LEGIC",
                commands=["hf legic reader"]
            ),
            "NTAG21x": ProtocolInfo(
                name="NTAG21x",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="NXP NTAG21x series",
                detection_patterns=["NTAG210", "NTAG212", "NTAG213", "NTAG215", "NTAG216"],
                manufacturer="NXP",
                commands=["hf mfu info", "hf mfu dump", "hf mfu auth"]
            ),
            "NTAG424": ProtocolInfo(
                name="NTAG424",
                family=ProtocolFamily.HF,
                frequency=13560000,
                description="NXP NTAG424 DNA",
                detection_patterns=["NTAG424"],
                manufacturer="NXP",
                commands=["hf mfu info", "hf mfu auth", "hf mfu cmd"]
            ),
        }
    
    def detect(self, pm3_output: str) -> List[ProtocolInfo]:
        """
        Определение протокола по выводу Proxmark3
        
        Args:
            pm3_output: Вывод команды (например, lf search или hf 14a reader)
        
        Returns:
            Список обнаруженных протоколов
        """
        detected = []
        output_lower = pm3_output.lower()
        
        for protocol_name, protocol_info in self.protocols.items():
            for pattern in protocol_info.detection_patterns:
                if re.search(pattern.lower(), output_lower):
                    detected.append(protocol_info)
                    break
        
        return detected
    
    def detect_from_reader(self, pm3) -> List[ProtocolInfo]:
        """
        Определение протокола путём активного опроса
        
        Args:
            pm3: Экземпляр PM3Client
        
        Returns:
            Список обнаруженных протоколов
        """
        detected = []
        
        # LF поиск
        lf_output = pm3.run_command("lf search")
        detected.extend(self.detect(lf_output))
        
        # HF поиск
        hf_output = pm3.run_command("hf 14a reader")
        detected.extend(self.detect(hf_output))
        
        # ISO15693 поиск
        iso_output = pm3.run_command("hf 15 reader")
        detected.extend(self.detect(iso_output))
        
        # iClass поиск
        iclass_output = pm3.run_command("hf iclass read")
        detected.extend(self.detect(iclass_output))
        
        # FeliCa поиск
        felica_output = pm3.run_command("hf felica reader")
        detected.extend(self.detect(felica_output))
        
        # Удаляем дубликаты
        unique = []
        seen = set()
        for p in detected:
            if p.name not in seen:
                seen.add(p.name)
                unique.append(p)
        
        return unique
    
    def detect_from_uid(self, uid: str) -> Optional[ProtocolInfo]:
        """
        Определение протокола по UID
        
        Args:
            uid: UID метки (HEX строка)
        
        Returns:
            Информация о протоколе или None
        """
        uid_upper = uid.upper()
        
        # HF протоколы имеют определённые префиксы
        if len(uid_upper) >= 2:
            prefix = uid_upper[:2]
            
            # NXP префиксы
            if prefix in ["04", "08", "44"]:
                if len(uid_upper) >= 8:
                    sak_byte = uid_upper[6:8] if len(uid_upper) >= 8 else ""
                    if sak_byte in ["08", "18"]:
                        return self.protocols.get("Mifare Classic")
                    elif sak_byte == "00":
                        return self.protocols.get("Mifare Ultralight")
                    elif sak_byte == "20":
                        return self.protocols.get("Mifare DESFire")
                return self.protocols.get("Mifare Classic")
            
            # Другие производители
            if prefix == "28":
                return self.protocols.get("Mifare Classic")
        
        # LF протоколы (обычно 8-10 символов)
        if len(uid_upper) in [8, 10]:
            return self.protocols.get("EM4100")
        
        return None
    
    def get_protocol_info(self, name: str) -> Optional[ProtocolInfo]:
        """Получение информации о протоколе по имени"""
        return self.protocols.get(name)
    
    def get_all_protocols(self) -> List[ProtocolInfo]:
        """Получение списка всех поддерживаемых протоколов"""
        return list(self.protocols.values())
    
    def get_lf_protocols(self) -> List[ProtocolInfo]:
        """Получение LF протоколов"""
        return [p for p in self.protocols.values() if p.family == ProtocolFamily.LF]
    
    def get_hf_protocols(self) -> List[ProtocolInfo]:
        """Получение HF протоколов"""
        return [p for p in self.protocols.values() if p.family == ProtocolFamily.HF]
    
    def get_protocols_by_family(self, family: ProtocolFamily) -> List[ProtocolInfo]:
        """Получение протоколов по семейству"""
        return [p for p in self.protocols.values() if p.family == family]
    
    def suggest_commands(self, protocol_name: str) -> List[str]:
        """Предложение команд для работы с протоколом"""
        protocol = self.get_protocol_info(protocol_name)
        if protocol:
            return protocol.commands
        return ["hf 14a reader", "lf search"]
    
    def get_manufacturer(self, uid_prefix: str) -> str:
        """
        Определение производителя по префиксу UID
        
        Args:
            uid_prefix: Первые 2 символа UID (HEX)
        
        Returns:
            Название производителя
        """
        manufacturers = {
            "04": "NXP Semiconductors",
            "08": "NXP Semiconductors",
            "44": "NXP Semiconductors (Ultralight C)",
            "28": "Infineon Technologies",
            "30": "Gemalto",
            "33": "STMicroelectronics",
            "D2": "JCB",
            "D3": "MasterCard",
            "D4": "Visa",
            "D5": "Amex",
        }
        return manufacturers.get(uid_prefix.upper(), "Unknown")
    
    def analyze_card(self, pm3) -> Dict:
        """
        Полный анализ карты: определение протокола, извлечение информации
        
        Args:
            pm3: Экземпляр PM3Client
        
        Returns:
            Словарь с информацией о карте
        """
        result = {
            'protocols': [],
            'uid': None,
            'manufacturer': None,
            'type': None,
            'size': None,
            'frequency': None,
            'raw_output': {}
        }
        
        # HF анализ
        hf_output = pm3.run_command("hf 14a reader")
        result['raw_output']['hf'] = hf_output
        
        hf_protocols = self.detect(hf_output)
        result['protocols'].extend(hf_protocols)
        
        # Извлечение UID
        uid_match = re.search(r"UID:\s*([0-9A-F\s]+)", hf_output, re.IGNORECASE)
        if uid_match:
            uid = uid_match.group(1).replace(" ", "")
            result['uid'] = uid
            if len(uid) >= 2:
                result['manufacturer'] = self.get_manufacturer(uid[:2])
        
        # Определение типа и размера
        sak_match = re.search(r"SAK:\s*([0-9A-F]{2})", hf_output, re.IGNORECASE)
        if sak_match:
            sak = sak_match.group(1)
            if sak == "08":
                result['type'] = "Mifare Classic 1K"
                result['size'] = 1024
            elif sak == "18":
                result['type'] = "Mifare Classic 4K"
                result['size'] = 4096
            elif sak == "00":
                result['type'] = "Mifare Ultralight"
                result['size'] = 64
            elif sak == "20":
                result['type'] = "Mifare DESFire"
                result['size'] = 4096
        
        # LF анализ
        lf_output = pm3.run_command("lf search")
        result['raw_output']['lf'] = lf_output
        
        lf_protocols = self.detect(lf_output)
        for p in lf_protocols:
            if p not in result['protocols']:
                result['protocols'].append(p)
        
        return result