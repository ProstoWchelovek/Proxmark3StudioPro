# core/command_executor.py
"""
Асинхронное выполнение команд Proxmark3 с поддержкой прогресса и отмены
"""

from PySide6.QtCore import QObject, Signal, QThread
import time
import re
from typing import Optional, Callable, List, Dict


class CommandExecutor(QObject):
    """Класс для асинхронного выполнения команд с обратной связью"""
    
    # Сигналы
    command_started = Signal(str)
    command_progress = Signal(int, str)
    command_output = Signal(str)
    command_finished = Signal(bool, str)
    
    def __init__(self, pm3_client):
        super().__init__()
        self.pm3 = pm3_client
        self.current_thread: Optional[CommandThread] = None
        self.is_running = False
    
    def execute(self, command: str, timeout: int = 30, 
                progress_callback: Optional[Callable] = None,
                output_callback: Optional[Callable] = None) -> None:
        """
        Асинхронное выполнение команды
        
        Args:
            command: Команда для выполнения
            timeout: Таймаут в секундах
            progress_callback: Функция обратного вызова для прогресса (value, message)
            output_callback: Функция обратного вызова для вывода
        """
        if self.is_running:
            self.command_output.emit("ERROR: Another command is already running")
            return
        
        self.command_started.emit(command)
        
        self.current_thread = CommandThread(self.pm3, command, timeout)
        
        if progress_callback:
            self.command_progress.connect(progress_callback)
        if output_callback:
            self.command_output.connect(output_callback)
        
        self.current_thread.progress.connect(self.command_progress)
        self.current_thread.output.connect(self.command_output)
        self.current_thread.finished.connect(self._on_finished)
        
        self.current_thread.start()
        self.is_running = True
    
    def _on_finished(self, success: bool, result: str):
        """Обработка завершения команды"""
        self.is_running = False
        self.command_finished.emit(success, result)
        self.current_thread = None
    
    def cancel(self) -> bool:
        """Отмена текущей команды"""
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.cancel()
            return True
        return False
    
    def build_lf_command(self, protocol: str, action: str, **params) -> str:
        """Построение команды для LF диапазона"""
        cmd_parts = [f"lf {protocol} {action}"]
        
        for key, value in params.items():
            if value is not None:
                cmd_parts.append(f"--{key} {value}")
        
        return " ".join(cmd_parts)
    
    def build_hf_command(self, protocol: str, action: str, **params) -> str:
        """Построение команды для HF диапазона"""
        cmd_parts = [f"hf {protocol} {action}"]
        
        for key, value in params.items():
            if value is not None:
                cmd_parts.append(f"--{key} {value}")
        
        return " ".join(cmd_parts)
    
    def build_mifare_command(self, action: str, **params) -> str:
        """Построение команды для Mifare"""
        return self.build_hf_command("mf", action, **params)
    
    def build_apdu_command(self, apdu: str) -> str:
        """Построение APDU команды"""
        return f"hf 14a apdu --apdu {apdu}"
    
    def execute_nested_attack(self, known_key: str, sector: int, key_type: str = "A",
                              target_sectors: str = None) -> None:
        """Запуск Nested атаки"""
        cmd = f"hf mf nested 1 0 {known_key} {sector} {key_type} t"
        if target_sectors:
            cmd += f" {target_sectors}"
        self.execute(cmd, timeout=300)
    
    def execute_hardnested_attack(self, known_key: str, sector: int = 0,
                                   key_type: str = "A", target_sector: int = None,
                                   threads: int = 4) -> None:
        """Запуск Hardnested атаки"""
        cmd = f"hf mf hardnested --key {known_key} --sector {sector} --keytype {key_type} --threads {threads}"
        if target_sector is not None:
            cmd += f" --targsec {target_sector}"
        self.execute(cmd, timeout=600)
    
    def execute_darkside_attack(self) -> None:
        """Запуск Darkside атаки"""
        self.execute("hf mf darkside", timeout=120)
    
    def execute_sniff(self) -> None:
        """Запуск перехвата"""
        self.execute("hf mf sniff", timeout=60)
    
    def execute_dictionary_attack(self, dict_file: str, sectors: str = None) -> None:
        """Запуск словарной атаки"""
        cmd = f"hf mf chk --dict {dict_file}"
        if sectors:
            cmd += f" --sectors {sectors}"
        self.execute(cmd, timeout=300)
    
    def execute_dump(self, card_type: str, filename: str, use_keys: bool = True) -> None:
        """Создание дампа карты"""
        if card_type == "mifare_classic":
            cmd = f"hf mf dump --file {filename}"
            if not use_keys:
                cmd += " --no-keys"
        elif card_type == "mifare_ultralight":
            cmd = f"hf mfu dump --file {filename}"
        elif card_type == "iclass":
            cmd = f"hf iclass dump --file {filename}"
        else:
            cmd = f"hf 14a reader --dump --file {filename}"
        
        self.execute(cmd, timeout=120)
    
    def execute_restore(self, card_type: str, filename: str) -> None:
        """Восстановление карты из дампа"""
        if card_type == "mifare_classic":
            cmd = f"hf mf restore --file {filename}"
        elif card_type == "mifare_ultralight":
            cmd = f"hf mfu restore --file {filename}"
        elif card_type == "iclass":
            cmd = f"hf iclass clone --file {filename}"
        else:
            cmd = f"hf 14a write --file {filename}"
        
        self.execute(cmd, timeout=120)
    
    def execute_lf_search(self) -> None:
        """Поиск LF меток"""
        self.execute("lf search", timeout=30)
    
    def execute_lf_clone(self, protocol: str, data: str, config: str = None, 
                          password: str = None, lock: bool = False) -> None:
        """Клонирование LF метки на T55x7"""
        if protocol.lower() == "em4100":
            cmd = f"lf em 410x clone --uid {data}"
        elif protocol.lower() == "hid":
            if ":" in data:
                fc, cn = data.split(":")
                cmd = f"lf hid clone --fc {fc} --cn {cn}"
            else:
                cmd = f"lf hid clone --raw {data}"
        elif protocol.lower() == "indala":
            cmd = f"lf indala clone --id {data}"
        else:
            cmd = f"lf t55xx write --data {data}"
        
        if config:
            cmd += f" --config {config}"
        if password:
            cmd += f" --password {password}"
        if lock:
            cmd += " --lock"
        
        self.execute(cmd, timeout=60)
    
    def execute_lf_emulation(self, protocol: str, data: str, gap: int = 0, repeat: int = 0) -> None:
        """Эмуляция LF метки"""
        if protocol.lower() == "em4100":
            cmd = f"lf em 410x sim --id {data}"
        elif protocol.lower() == "hid":
            if ":" in data:
                fc, cn = data.split(":")
                cmd = f"lf hid sim --fc {fc} --cn {cn}"
            else:
                cmd = f"lf hid sim --raw {data}"
        else:
            cmd = f"lf {protocol.lower()} sim --data {data}"
        
        if gap > 0:
            cmd += f" --gap {gap}"
        if repeat > 0:
            cmd += f" --repeat {repeat}"
        
        self.execute(cmd, timeout=0)  # Без таймаута для эмуляции
    
    def execute_t55xx_read_config(self, password: str = None) -> None:
        """Чтение конфигурации T55x7"""
        cmd = "lf t55xx read"
        if password:
            cmd += f" --password {password}"
        self.execute(cmd, timeout=30)
    
    def execute_t55xx_write_config(self, config: str, password: str = None) -> None:
        """Запись конфигурации T55x7"""
        cmd = f"lf t55xx write --config {config}"
        if password:
            cmd += f" --password {password}"
        self.execute(cmd, timeout=30)
    
    def execute_t55xx_dump(self, filename: str, password: str = None) -> None:
        """Дамп T55x7"""
        cmd = f"lf t55xx dump --file {filename}"
        if password:
            cmd += f" --password {password}"
        self.execute(cmd, timeout=60)
    
    def execute_script(self, script_path: str) -> None:
        """Выполнение Lua скрипта"""
        cmd = f"script run {script_path}"
        self.execute(cmd, timeout=300)
    
    def execute_hw_test(self) -> None:
        """Тестирование оборудования"""
        self.execute("hw test", timeout=60)
    
    def execute_hw_tune(self) -> None:
        """Настройка антенны"""
        self.execute("hw tune", timeout=30)
    
    def execute_hw_version(self) -> None:
        """Информация о версии"""
        self.execute("hw version", timeout=10)
    
    def execute_hw_reset(self) -> None:
        """Сброс устройства"""
        self.execute("hw reset", timeout=30)


class CommandThread(QThread):
    """Поток для выполнения команды с поддержкой прогресса"""
    
    progress = Signal(int, str)
    output = Signal(str)
    finished = Signal(bool, str)
    
    def __init__(self, pm3_client, command: str, timeout: int = 30):
        super().__init__()
        self.pm3 = pm3_client
        self.command = command
        self.timeout = timeout
        self._is_cancelled = False
    
    def run(self):
        try:
            self.progress.emit(10, f"Выполнение: {self.command}")
            
            # Эмулируем прогресс для длительных операций
            # В реальности нужно парсить вывод в реальном времени
            result = self.pm3.run_command(self.command)
            
            if self._is_cancelled:
                self.output.emit("Команда отменена")
                self.finished.emit(False, "Cancelled")
                return
            
            self.progress.emit(100, "Завершено")
            
            # Анализ результата на наличие ошибок
            if "failed" in result.lower() or "error" in result.lower():
                self.finished.emit(False, result)
            else:
                self.finished.emit(True, result)
                
        except Exception as e:
            self.output.emit(f"Ошибка: {str(e)}")
            self.finished.emit(False, str(e))
    
    def cancel(self):
        """Отмена выполнения"""
        self._is_cancelled = True
        self.pm3.send_command("\x03")  # Ctrl+C для остановки