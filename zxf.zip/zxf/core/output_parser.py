# core/output_parser.py
"""
Парсинг вывода команд Proxmark3 для извлечения структурированных данных
"""

import re
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum


class CardType(Enum):
    """Типы карт"""
    UNKNOWN = "unknown"
    MIFARE_CLASSIC_1K = "mifare_classic_1k"
    MIFARE_CLASSIC_4K = "mifare_classic_4k"
    MIFARE_ULTRALIGHT = "mifare_ultralight"
    MIFARE_DESFIRE = "mifare_desfire"
    ICLASS = "iclass"
    ISO15693 = "iso15693"
    FELICA = "felica"
    LEGIC = "legic"
    EM4100 = "em4100"
    HID = "hid"
    INDALA = "indala"
    AWID = "awid"
    T55XX = "t55xx"


@dataclass
class CardInfo:
    """Информация о карте"""
    uid: str
    type: CardType
    atqa: Optional[str] = None
    sak: Optional[str] = None
    manufacturer: Optional[str] = None
    size: Optional[int] = None
    frequency: Optional[int] = None
    raw_data: Optional[str] = None


@dataclass
class KeyInfo:
    """Информация о ключе"""
    sector: int
    key_a: str
    key_b: str
    found_by: Optional[str] = None


@dataclass
class AttackResult:
    """Результат атаки"""
    success: bool
    keys_found: List[KeyInfo]
    message: str


class OutputParser:
    """Парсинг вывода команд Proxmark3"""
    
    # Регулярные выражения для разных типов данных
    PATTERNS = {
        'uid': re.compile(r'UID:\s*([0-9A-F\s]+)', re.IGNORECASE),
        'atqa': re.compile(r'ATQA:\s*([0-9A-F]{4})', re.IGNORECASE),
        'sak': re.compile(r'SAK:\s*([0-9A-F]{2})', re.IGNORECASE),
        'em4100_id': re.compile(r'ID:\s*([0-9A-F]{10})', re.IGNORECASE),
        'hid_fc': re.compile(r'FC:\s*(\d+)', re.IGNORECASE),
        'hid_cn': re.compile(r'CN:\s*(\d+)', re.IGNORECASE),
        'indala_id': re.compile(r'ID:\s*([0-9A-F]+)', re.IGNORECASE),
        'key_found': re.compile(r'Found\s+key:\s*([0-9A-F]{12})', re.IGNORECASE),
        'nested_sector': re.compile(r'Sector\s+(\d+).*?Key A:\s*([0-9A-F?]+).*?Key B:\s*([0-9A-F?]+)', re.DOTALL),
        'hardnested_key': re.compile(r'Key\s+found:\s+sector\s+(\d+),\s+key\s+([AB]):\s*([0-9A-F]{12})', re.IGNORECASE),
        'desfire_uid': re.compile(r'UID:\s*([0-9A-F]{14})', re.IGNORECASE),
        'iclass_csn': re.compile(r'CSN:\s*([0-9A-F]{16})', re.IGNORECASE),
        'iso15693_uid': re.compile(r'UID:\s*([0-9A-F]{16})', re.IGNORECASE),
        'felica_idm': re.compile(r'IDm:\s*([0-9A-F]{16})', re.IGNORECASE),
        'error': re.compile(r'(!|\[!\]|ERROR|failed)', re.IGNORECASE),
        'success': re.compile(r'(\[+\]|OK|success|found)', re.IGNORECASE),
    }
    
    def __init__(self):
        self.last_output = ""
    
    def parse_mifare_info(self, output: str) -> CardInfo:
        """Парсинг информации о Mifare карте"""
        uid = self._extract_uid(output)
        atqa = self._extract_atqa(output)
        sak = self._extract_sak(output)
        
        # Определение типа карты
        if sak == "08":
            card_type = CardType.MIFARE_CLASSIC_1K
            size = 1024
        elif sak == "18":
            card_type = CardType.MIFARE_CLASSIC_4K
            size = 4096
        elif sak == "00" or sak == "20":
            card_type = CardType.MIFARE_ULTRALIGHT
            size = 64
        elif sak == "28":
            card_type = CardType.MIFARE_DESFIRE
            size = 4096
        else:
            card_type = CardType.UNKNOWN
            size = None
        
        # Производитель по UID
        manufacturer = self._get_manufacturer(uid[:2] if uid else "")
        
        return CardInfo(
            uid=uid,
            type=card_type,
            atqa=atqa,
            sak=sak,
            manufacturer=manufacturer,
            size=size,
            frequency=13560000,
            raw_data=output
        )
    
    def parse_em4100(self, output: str) -> Optional[CardInfo]:
        """Парсинг EM4100 метки"""
        match = self.PATTERNS['em4100_id'].search(output)
        if not match:
            return None
        
        uid = match.group(1)
        
        return CardInfo(
            uid=uid,
            type=CardType.EM4100,
            manufacturer="EM Microelectronic",
            frequency=125000,
            raw_data=output
        )
    
    def parse_hid(self, output: str) -> Optional[CardInfo]:
        """Парсинг HID метки"""
        fc_match = self.PATTERNS['hid_fc'].search(output)
        cn_match = self.PATTERNS['hid_cn'].search(output)
        
        if not fc_match or not cn_match:
            return None
        
        fc = fc_match.group(1)
        cn = cn_match.group(1)
        uid = f"{fc}:{cn}"
        
        return CardInfo(
            uid=uid,
            type=CardType.HID,
            manufacturer="HID Global",
            frequency=125000,
            raw_data=output
        )
    
    def parse_indala(self, output: str) -> Optional[CardInfo]:
        """Парсинг Indala метки"""
        match = self.PATTERNS['indala_id'].search(output)
        if not match:
            return None
        
        uid = match.group(1)
        
        return CardInfo(
            uid=uid,
            type=CardType.INDALA,
            manufacturer="Motorola/Indala",
            frequency=125000,
            raw_data=output
        )
    
    def parse_desfire(self, output: str) -> CardInfo:
        """Парсинг DESFire карты"""
        uid = self._extract_uid(output)
        
        return CardInfo(
            uid=uid,
            type=CardType.MIFARE_DESFIRE,
            manufacturer="NXP",
            frequency=13560000,
            raw_data=output
        )
    
    def parse_iclass(self, output: str) -> Optional[CardInfo]:
        """Парсинг iClass карты"""
        match = self.PATTERNS['iclass_csn'].search(output)
        if not match:
            return None
        
        uid = match.group(1)
        
        return CardInfo(
            uid=uid,
            type=CardType.ICLASS,
            manufacturer="HID Global",
            frequency=13560000,
            raw_data=output
        )
    
    def parse_iso15693(self, output: str) -> Optional[CardInfo]:
        """Парсинг ISO15693 карты"""
        match = self.PATTERNS['iso15693_uid'].search(output)
        if not match:
            return None
        
        uid = match.group(1)
        
        return CardInfo(
            uid=uid,
            type=CardType.ISO15693,
            manufacturer="Various",
            frequency=13560000,
            raw_data=output
        )
    
    def parse_nested_attack(self, output: str) -> AttackResult:
        """Парсинг результата Nested атаки"""
        keys = []
        
        matches = self.PATTERNS['nested_sector'].findall(output)
        for match in matches:
            sector = int(match[0])
            key_a = match[1].strip()
            key_b = match[2].strip()
            
            if key_a != "????????????":
                keys.append(KeyInfo(sector=sector, key_a=key_a, key_b="?", found_by="nested"))
            if key_b != "????????????" and key_b != "?":
                keys.append(KeyInfo(sector=sector, key_a="?", key_b=key_b, found_by="nested"))
        
        success = len(keys) > 0
        message = f"Found {len(keys)} keys" if success else "No keys found"
        
        return AttackResult(success=success, keys_found=keys, message=message)
    
    def parse_hardnested_attack(self, output: str) -> AttackResult:
        """Парсинг результата Hardnested атаки"""
        keys = []
        
        matches = self.PATTERNS['hardnested_key'].findall(output)
        for match in matches:
            sector = int(match[0])
            key_type = match[1]
            key = match[2]
            
            if key_type == 'A':
                keys.append(KeyInfo(sector=sector, key_a=key, key_b="?", found_by="hardnested"))
            else:
                keys.append(KeyInfo(sector=sector, key_a="?", key_b=key, found_by="hardnested"))
        
        # Также ищем ключи в формате "Found key: XXXXXX"
        key_matches = self.PATTERNS['key_found'].findall(output)
        for key in key_matches:
            # Если ключ не привязан к сектору
            if not any(k.key_a == key or k.key_b == key for k in keys):
                keys.append(KeyInfo(sector=0, key_a=key, key_b="?", found_by="hardnested"))
        
        success = len(keys) > 0
        message = f"Found {len(keys)} keys" if success else "No keys found"
        
        return AttackResult(success=success, keys_found=keys, message=message)
    
    def parse_darkside_attack(self, output: str) -> AttackResult:
        """Парсинг результата Darkside атаки"""
        match = self.PATTERNS['key_found'].search(output)
        
        if match:
            key = match.group(1)
            keys = [KeyInfo(sector=0, key_a=key, key_b="?", found_by="darkside")]
            return AttackResult(success=True, keys_found=keys, message=f"Found key: {key}")
        
        return AttackResult(success=False, keys_found=[], message="No key found")
    
    def parse_dump(self, output: str) -> Dict[str, Any]:
        """Парсинг результата дампа"""
        result = {
            'success': False,
            'sectors': [],
            'keys_found': [],
            'error': None
        }
        
        # Проверка на ошибку
        if self.PATTERNS['error'].search(output):
            result['error'] = "Error during dump"
            return result
        
        # Ищем сектора с ключами
        sector_pattern = re.compile(r'Sector\s+(\d+)\s+\((\d+)\s+bytes\)')
        sectors = sector_pattern.findall(output)
        result['sectors'] = [int(s[0]) for s in sectors]
        
        # Ищем найденные ключи
        keys = self.PATTERNS['nested_sector'].findall(output)
        for match in keys:
            sector = int(match[0])
            key_a = match[1].strip()
            key_b = match[2].strip()
            
            if key_a != "????????????":
                result['keys_found'].append({'sector': sector, 'key': key_a, 'type': 'A'})
            if key_b != "????????????" and key_b != "?":
                result['keys_found'].append({'sector': sector, 'key': key_b, 'type': 'B'})
        
        result['success'] = len(result['sectors']) > 0 or len(result['keys_found']) > 0
        
        return result
    
    def parse_lf_search(self, output: str) -> Dict[str, Any]:
        """Парсинг результата поиска LF меток"""
        result = {
            'found': False,
            'type': None,
            'uid': None,
            'details': {}
        }
        
        # EM4100
        em_match = self.PATTERNS['em4100_id'].search(output)
        if em_match:
            result['found'] = True
            result['type'] = 'EM4100'
            result['uid'] = em_match.group(1)
            return result
        
        # HID
        fc_match = self.PATTERNS['hid_fc'].search(output)
        cn_match = self.PATTERNS['hid_cn'].search(output)
        if fc_match and cn_match:
            result['found'] = True
            result['type'] = 'HID'
            result['uid'] = f"{fc_match.group(1)}:{cn_match.group(1)}"
            result['details'] = {'fc': fc_match.group(1), 'cn': cn_match.group(1)}
            return result
        
        # Indala
        ind_match = self.PATTERNS['indala_id'].search(output)
        if ind_match:
            result['found'] = True
            result['type'] = 'Indala'
            result['uid'] = ind_match.group(1)
            return result
        
        # AWID
        if "AWID" in output.upper():
            result['found'] = True
            result['type'] = 'AWID'
        
        # FDX-B
        if "FDX" in output.upper() or "Animal" in output:
            result['found'] = True
            result['type'] = 'FDX-B'
        
        return result
    
    def parse_t55xx_read(self, output: str) -> Dict[str, Any]:
        """Парсинг результата чтения T55x7"""
        result = {
            'success': False,
            'config': None,
            'blocks': {},
            'error': None
        }
        
        # Поиск конфигурации (Block 0)
        config_match = re.search(r'Block\s+0:\s*([0-9A-F]{8})', output, re.IGNORECASE)
        if config_match:
            result['config'] = config_match.group(1)
        
        # Поиск всех блоков
        block_pattern = re.compile(r'Block\s+(\d+):\s*([0-9A-F]{8})', re.IGNORECASE)
        blocks = block_pattern.findall(output)
        for block_num, block_data in blocks:
            result['blocks'][int(block_num)] = block_data
        
        result['success'] = result['config'] is not None or len(result['blocks']) > 0
        
        return result
    
    def parse_apdu_response(self, output: str) -> Dict[str, Any]:
        """Парсинг ответа APDU команды"""
        result = {
            'success': False,
            'data': None,
            'sw1': None,
            'sw2': None,
            'status': None
        }
        
        # Ищем ответ в формате: [data] SW1 SW2
        apdu_match = re.search(r'([0-9A-F]*)\s*([0-9A-F]{2})\s*([0-9A-F]{2})', output, re.IGNORECASE)
        if apdu_match:
            result['data'] = apdu_match.group(1) if apdu_match.group(1) else None
            result['sw1'] = apdu_match.group(2)
            result['sw2'] = apdu_match.group(3)
            result['success'] = (result['sw1'] == '90' and result['sw2'] == '00')
            
            # Декодируем статус
            result['status'] = self._decode_apdu_status(result['sw1'], result['sw2'])
        
        return result
    
    def parse_hardware_info(self, output: str) -> Dict[str, str]:
        """Парсинг информации об устройстве"""
        info = {}
        
        # Модель
        if "Proxmark3 Easy" in output:
            info['model'] = "Proxmark3 Easy"
        elif "RDV4" in output:
            info['model'] = "Proxmark3 RDV4"
        else:
            info['model'] = "Proxmark3"
        
        # Версия
        version_match = re.search(r'v([\d.]+)', output)
        if version_match:
            info['version'] = version_match.group(1)
        
        # Commit
        commit_match = re.search(r'commit:\s*([a-f0-9]+)', output, re.IGNORECASE)
        if commit_match:
            info['commit'] = commit_match.group(1)
        
        # Дата сборки
        date_match = re.search(r'built\s+(\d{4}-\d{2}-\d{2})', output, re.IGNORECASE)
        if date_match:
            info['build_date'] = date_match.group(1)
        
        return info
    
    def parse_trace_list(self, output: str) -> List[Dict[str, Any]]:
        """Парсинг вывода trace list"""
        traces = []
        
        # Формат: [123.45] RDR->CARD: 00 A4 04 00 08 ...
        trace_pattern = re.compile(r'\[?([\d.]+)\]?\s*([Rr][Dd][Rr]|[Cc][Aa][Rr][Dd])\s*[-=]>\s*([Rr][Dd][Rr]|[Cc][Aa][Rr][Dd])?:\s*([0-9A-Fa-f\s]+)')
        
        for match in trace_pattern.finditer(output):
            timestamp = float(match.group(1))
            direction = "reader_to_card" if "RDR" in match.group(2).upper() else "card_to_reader"
            data_hex = re.sub(r'\s+', '', match.group(4))
            
            traces.append({
                'timestamp': timestamp,
                'direction': direction,
                'data': data_hex,
                'data_bytes': len(data_hex) // 2 if data_hex else 0
            })
        
        return traces
    
    def has_error(self, output: str) -> bool:
        """Проверка наличия ошибки в выводе"""
        return bool(self.PATTERNS['error'].search(output))
    
    def has_success(self, output: str) -> bool:
        """Проверка наличия успешного выполнения"""
        return bool(self.PATTERNS['success'].search(output))
    
    def extract_all_keys(self, output: str) -> List[str]:
        """Извлечение всех HEX ключей из вывода"""
        keys = set()
        
        # 12-символьные ключи
        for match in re.finditer(r'\b([0-9A-F]{12})\b', output, re.IGNORECASE):
            key = match.group(1).upper()
            if key != "FFFFFFFFFFFF":
                keys.add(key)
        
        # 16-символьные ключи
        for match in re.finditer(r'\b([0-9A-F]{16})\b', output, re.IGNORECASE):
            key = match.group(1).upper()
            keys.add(key)
        
        return list(keys)
    
    def _extract_uid(self, output: str) -> str:
        """Извлечение UID из вывода"""
        match = self.PATTERNS['uid'].search(output)
        if match:
            return match.group(1).replace(" ", "")
        return ""
    
    def _extract_atqa(self, output: str) -> Optional[str]:
        """Извлечение ATQA"""
        match = self.PATTERNS['atqa'].search(output)
        return match.group(1) if match else None
    
    def _extract_sak(self, output: str) -> Optional[str]:
        """Извлечение SAK"""
        match = self.PATTERNS['sak'].search(output)
        return match.group(1) if match else None
    
    def _get_manufacturer(self, uid_prefix: str) -> str:
        """Определение производителя по префиксу UID"""
        manufacturers = {
            "04": "NXP Semiconductors",
            "08": "NXP Semiconductors",
            "44": "NXP Semiconductors (Ultralight C)",
            "28": "Infineon Technologies",
            "30": "Gemalto",
        }
        return manufacturers.get(uid_prefix, "Unknown")
    
    def _decode_apdu_status(self, sw1: str, sw2: str) -> str:
        """Декодирование статуса APDU"""
        status_map = {
            ("90", "00"): "Успешно",
            ("61", None): f"Данные доступны, Le={int(sw2, 16)}",
            ("62", "00"): "Информация не возвращена",
            ("63", "C0"): f"Осталось попыток: {int(sw2, 16)}",
            ("64", "00"): "Ошибка выполнения",
            ("67", "00"): "Неправильная длина",
            ("68", "00"): "Неправильный CLA",
            ("69", "82"): "Небезопасный статус",
            ("69", "85"): "Условия не выполнены",
            ("6A", "81"): "Функция не поддерживается",
            ("6A", "82"): "Файл/приложение не найдены",
            ("6D", "00"): "Неизвестная команда",
            ("6E", "00"): "Неправильный CLA",
        }
        
        for (s1, s2), msg in status_map.items():
            if sw1 == s1 and (s2 is None or sw2 == s2):
                return msg
        
        return f"Неизвестный статус: {sw1}{sw2}"