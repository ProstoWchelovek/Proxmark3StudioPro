# utils/network_utils.py
"""
Сетевые утилиты
"""

import socket
import requests
from typing import Optional, Dict
from urllib.parse import urlparse


class NetworkUtils:
    """Сетевые функции"""
    
    @staticmethod
    def check_internet() -> bool:
        """Проверка наличия интернета"""
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    @staticmethod
    def download_file(url: str, dest_path: str, timeout: int = 30) -> bool:
        """Скачивание файла"""
        try:
            response = requests.get(url, timeout=timeout, stream=True)
            response.raise_for_status()
            
            with open(dest_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            return True
        except Exception:
            return False
    
    @staticmethod
    def get_github_releases(repo: str) -> Optional[list]:
        """Получение списка релизов с GitHub"""
        try:
            url = f"https://api.github.com/repos/{repo}/releases"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception:
            return None
    
    @staticmethod
    def check_for_updates(current_version: str, repo: str) -> Optional[Dict]:
        """Проверка обновлений"""
        releases = NetworkUtils.get_github_releases(repo)
        if releases:
            latest = releases[0]
            latest_version = latest['tag_name'].lstrip('v')
            if latest_version != current_version:
                return {
                    'version': latest_version,
                    'url': latest['html_url'],
                    'date': latest['published_at'][:10],
                    'body': latest['body'][:500]
                }
        return None
    
    @staticmethod
    def is_valid_url(url: str) -> bool:
        """Проверка валидности URL"""
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except Exception:
            return False
    
    @staticmethod
    def get_ip() -> Optional[str]:
        """Получение локального IP"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return None