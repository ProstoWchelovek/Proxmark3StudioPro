# utils/hex_utils.py
"""
Утилиты для работы с HEX данными
"""

import re
from typing import Optional, List


class HexUtils:
    """HEX утилиты"""
    
    @staticmethod
    def validate(hex_str: str) -> bool:
        """Проверка валидности HEX строки"""
        hex_str = hex_str.replace(' ', '').replace('-', '').replace(':', '')
        return bool(re.match(r'^[0-9A-Fa-f]+$', hex_str))
    
    @staticmethod
    def clean(hex_str: str) -> str:
        """Очистка HEX строки от разделителей"""
        return re.sub(r'[^0-9A-Fa-f]', '', hex_str).upper()
    
    @staticmethod
    def format(hex_str: str, group_size: int = 2, separator: str = ' ') -> str:
        """Форматирование HEX строки"""
        cleaned = HexUtils.clean(hex_str)
        groups = [cleaned[i:i+group_size] for i in range(0, len(cleaned), group_size)]
        return separator.join(groups)
    
    @staticmethod
    def to_bytes(hex_str: str) -> Optional[bytes]:
        """Конвертация HEX в байты"""
        cleaned = HexUtils.clean(hex_str)
        try:
            return bytes.fromhex(cleaned)
        except ValueError:
            return None
    
    @staticmethod
    def from_bytes(data: bytes, separator: str = ' ') -> str:
        """Конвертация байт в HEX"""
        return separator.join(f"{b:02X}" for b in data)
    
    @staticmethod
    def to_binary(hex_str: str) -> str:
        """Конвертация HEX в бинарную строку"""
        cleaned = HexUtils.clean(hex_str)
        bits = ''
        for c in cleaned:
            val = int(c, 16)
            bits += f'{val:04b}'
        return bits
    
    @staticmethod
    def from_binary(bits: str) -> str:
        """Конвертация бинарной строки в HEX"""
        hex_str = ''
        for i in range(0, len(bits), 4):
            byte = bits[i:i+4]
            if len(byte) == 4:
                hex_str += f'{int(byte, 2):X}'
        return hex_str
    
    @staticmethod
    def xor(hex1: str, hex2: str) -> Optional[str]:
        """XOR двух HEX строк"""
        bytes1 = HexUtils.to_bytes(hex1)
        bytes2 = HexUtils.to_bytes(hex2)
        if bytes1 and bytes2:
            result = bytes(a ^ b for a, b in zip(bytes1, bytes2))
            return HexUtils.from_bytes(result, '')
        return None
    
    @staticmethod
    def find_pattern(hex_str: str, pattern: str) -> List[int]:
        """Поиск паттерна в HEX строке"""
        cleaned = HexUtils.clean(hex_str)
        pattern_cleaned = HexUtils.clean(pattern)
        positions = []
        pos = 0
        while True:
            pos = cleaned.find(pattern_cleaned, pos)
            if pos == -1:
                break
            positions.append(pos // 2)
            pos += 1
        return positions