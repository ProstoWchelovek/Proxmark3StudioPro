# utils/file_utils.py
"""
Утилиты для работы с файлами
"""

import os
import json
import pickle
from pathlib import Path
from typing import Any, Dict, Optional


class FileUtils:
    """Функции для работы с файлами"""
    
    @staticmethod
    def ensure_dir(path: str) -> None:
        """Создание директории если не существует"""
        Path(path).mkdir(parents=True, exist_ok=True)
    
    @staticmethod
    def read_text(filepath: str) -> Optional[str]:
        """Чтение текстового файла"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception:
            return None
    
    @staticmethod
    def write_text(filepath: str, content: str) -> bool:
        """Запись текстового файла"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception:
            return False
    
    @staticmethod
    def read_binary(filepath: str) -> Optional[bytes]:
        """Чтение бинарного файла"""
        try:
            with open(filepath, 'rb') as f:
                return f.read()
        except Exception:
            return None
    
    @staticmethod
    def write_binary(filepath: str, data: bytes) -> bool:
        """Запись бинарного файла"""
        try:
            with open(filepath, 'wb') as f:
                f.write(data)
            return True
        except Exception:
            return False
    
    @staticmethod
    def read_json(filepath: str) -> Optional[Dict]:
        """Чтение JSON файла"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None
    
    @staticmethod
    def write_json(filepath: str, data: Dict) -> bool:
        """Запись JSON файла"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception:
            return False
    
    @staticmethod
    def read_pickle(filepath: str) -> Optional[Any]:
        """Чтение pickle файла"""
        try:
            with open(filepath, 'rb') as f:
                return pickle.load(f)
        except Exception:
            return None
    
    @staticmethod
    def write_pickle(filepath: str, data: Any) -> bool:
        """Запись pickle файла"""
        try:
            with open(filepath, 'wb') as f:
                pickle.dump(data, f)
            return True
        except Exception:
            return False
    
    @staticmethod
    def get_file_size(filepath: str) -> int:
        """Размер файла в байтах"""
        try:
            return os.path.getsize(filepath)
        except Exception:
            return 0
    
    @staticmethod
    def get_file_list(directory: str, extensions: list = None) -> list:
        """Список файлов в директории"""
        files = []
        try:
            for file in os.listdir(directory):
                if extensions:
                    if any(file.endswith(ext) for ext in extensions):
                        files.append(os.path.join(directory, file))
                else:
                    files.append(os.path.join(directory, file))
        except Exception:
            pass
        return sorted(files)