# utils/config_utils.py
"""
Утилиты для работы с конфигурацией
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional


class ConfigManager:
    """Менеджер конфигурации"""
    
    DEFAULT_CONFIG = {
        "port": {
            "device": "",
            "baud": 115200,
            "timeout": 5
        },
        "appearance": {
            "theme": "dark",
            "font": "Courier New, 10pt",
            "language": "ru"
        },
        "paths": {
            "dumps": "",
            "scripts": "",
            "dictionaries": ""
        },
        "attacks": {
            "timeout": 300,
            "threads": 4,
            "save_keys": True
        },
        "keys": {
            "auto_import": False,
            "default_dict": ""
        },
        "updates": {
            "check_on_start": True,
            "auto_update": False
        }
    }
    
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = Path.home() / ".proxmark3_studio" / "config.json"
        self.config_path = Path(config_path)
        self.config = self.load()
    
    def load(self) -> Dict:
        """Загрузка конфигурации"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    config = self.DEFAULT_CONFIG.copy()
                    self._deep_update(config, user_config)
                    return config
            except Exception:
                pass
        return self.DEFAULT_CONFIG.copy()
    
    def save(self) -> bool:
        """Сохранение конфигурации"""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            return True
        except Exception:
            return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """Получение значения по ключу"""
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def set(self, key: str, value: Any) -> None:
        """Установка значения по ключу"""
        keys = key.split('.')
        target = self.config
        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        target[keys[-1]] = value
    
    def reset(self) -> None:
        """Сброс к дефолтной конфигурации"""
        self.config = self.DEFAULT_CONFIG.copy()
    
    def _deep_update(self, target: Dict, source: Dict) -> None:
        """Глубокое обновление словаря"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value


# Алиас для обратной совместимости
ConfigUtils = ConfigManager