# utils/logging_utils.py
"""
Утилиты для логирования
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


class LoggerSetup:
    """Настройка логирования"""
    
    @staticmethod
    def setup(level: int = logging.INFO, log_file: Optional[str] = None) -> logging.Logger:
        """Настройка логгера"""
        logger = logging.getLogger('Proxmark3Studio')
        logger.setLevel(level)
        
        # Форматтер
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Консольный обработчик
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # Файловый обработчик
        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        return logger
    
    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        """Получение логгера по имени"""
        return logging.getLogger(f'Proxmark3Studio.{name}')


class LogManager:
    """Менеджер логов"""
    
    def __init__(self, log_dir: str = None):
        if log_dir is None:
            log_dir = Path.home() / ".proxmark3_studio" / "logs"
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def get_log_files(self) -> list:
        """Список файлов логов"""
        return sorted(self.log_dir.glob("*.log"), reverse=True)
    
    def get_log_content(self, filename: str) -> Optional[str]:
        """Содержимое лог-файла"""
        log_path = self.log_dir / filename
        if log_path.exists():
            return log_path.read_text(encoding='utf-8')
        return None
    
    def rotate_logs(self, max_files: int = 10) -> None:
        """Ротация лог-файлов"""
        logs = self.get_log_files()
        for log in logs[max_files:]:
            log.unlink()
    
    def clear_logs(self) -> None:
        """Очистка всех логов"""
        for log in self.get_log_files():
            log.unlink()
    
    def create_session_log(self, session_name: str = None) -> Path:
        """Создание лога сессии"""
        if session_name is None:
            session_name = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = self.log_dir / f"session_{session_name}.log"
        return log_path


# Алиас для обратной совместимости
LoggingUtils = LogManager